#!/usr/bin/env python3
"""
ArrelMedia.py - Native Audio/Media Player for ArrelOS
Lightweight, production-ready music player for retro 32-bit systems.
Uses VLC backend via python-vlc for robust playback of MP3, WAV, OGG.
Requires: VLC media player and the python-vlc package installed on the system.

Optimised for 512 MB RAM, runs on Debian i386 and Raspberry Pi OS Lite (armhf).
"""

import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import vlc

# ----------------------------------------------------------------------
# Styling Constants (macOS retro Aqua / brushed platinum)
# ----------------------------------------------------------------------
BG_MAIN = "#ececec"
BG_FRAME = "#d4d0c8"
FG_TEXT = "#000000"
LCD_BG = "#3a3a3a"
LCD_FG = "#e0e0e0"
BUTTON_BG = "#d4d0c8"
FONT_LCD = ("Lucida Grande", 12, "bold")
FONT_SMALL = ("Lucida Grande", 10)
FONT_BUTTON = ("Lucida Grande", 11)

# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
def format_time(seconds):
    """Convert integer seconds to MM:SS string."""
    if seconds < 0:
        return "--:--"
    mins, secs = divmod(int(seconds), 60)
    return f"{mins:02d}:{secs:02d}"

# ----------------------------------------------------------------------
# Application Class
# ----------------------------------------------------------------------
class ArrelMedia(tk.Tk):
    def __init__(self):
        super().__init__()

        # Window setup
        self.title("ArrelMedia")
        self.geometry("700x500")
        self.minsize(600, 400)
        self.configure(bg=BG_MAIN)
        self.resizable(True, True)

        # Initialise VLC
        try:
            # '--no-xlib' avoids headless issues on some minimal systems
            self.vlc_instance = vlc.Instance("--quiet", "--no-xlib")
            self.player = self.vlc_instance.media_player_new()
        except Exception as e:
            messagebox.showerror("Fatal Error", f"Cannot initialise VLC:\n{e}")
            self.destroy()
            return

        # Playlist data: list of file paths
        self.playlist = []
        self.current_track_index = -1  # no track loaded

        # UI state variables
        self.progress_var = tk.DoubleVar(value=0)  # seconds
        self.volume_var = tk.IntVar(value=70)       # 0–100
        self.track_time_var = tk.StringVar(value="--:-- / --:--")
        self.track_name_var = tk.StringVar(value="No Track")
        self.dragging_slider = False

        # Play button icon state
        self.is_playing = False

        # Build GUI
        self._create_display()
        self._create_controls()
        self._create_progress_bar()
        self._create_playlist()

        # Restore volume
        self.player.audio_set_volume(self.volume_var.get())

        # Start the periodic UI updater
        self._update_ui()

        # Clean up VLC on close
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------------------------------------------------
    # GUI Construction
    # ------------------------------------------------------------------
    def _create_display(self):
        """Top LCD-like panel showing track name and time."""
        display_frame = tk.Frame(self, bg=BG_MAIN, padx=10, pady=5)
        display_frame.pack(fill=tk.X)

        # LCD area
        lcd = tk.Frame(display_frame, bg=LCD_BG, highlightbackground="#666",
                       highlightthickness=1, relief="ridge")
        lcd.pack(fill=tk.X, ipady=4)

        self.lbl_track = tk.Label(lcd, textvariable=self.track_name_var,
                                  bg=LCD_BG, fg=LCD_FG, font=FONT_LCD,
                                  anchor="w", padx=8)
        self.lbl_track.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.lbl_time = tk.Label(lcd, textvariable=self.track_time_var,
                                 bg=LCD_BG, fg=LCD_FG, font=FONT_LCD,
                                 anchor="e", padx=8)
        self.lbl_time.pack(side=tk.RIGHT)

    def _create_controls(self):
        """Playback buttons, volume slider, and Add Files button."""
        ctrl_frame = tk.Frame(self, bg=BG_MAIN, pady=5)
        ctrl_frame.pack(fill=tk.X, padx=10)

        # Button frame for centred controls
        btn_frame = tk.Frame(ctrl_frame, bg=BG_MAIN)
        btn_frame.pack(side=tk.LEFT, expand=True)

        # Previous
        self.btn_prev = tk.Button(btn_frame, text="⏮", font=FONT_BUTTON,
                                  bg=BUTTON_BG, relief="raised", width=4,
                                  command=self.prev_track)
        self.btn_prev.pack(side=tk.LEFT, padx=2)

        # Play/Pause (toggles)
        self.btn_play = tk.Button(btn_frame, text="▶", font=FONT_BUTTON,
                                  bg=BUTTON_BG, relief="raised", width=4,
                                  command=self.play_pause)
        self.btn_play.pack(side=tk.LEFT, padx=2)

        # Stop
        self.btn_stop = tk.Button(btn_frame, text="⏹", font=FONT_BUTTON,
                                  bg=BUTTON_BG, relief="raised", width=4,
                                  command=self.stop)
        self.btn_stop.pack(side=tk.LEFT, padx=2)

        # Next
        self.btn_next = tk.Button(btn_frame, text="⏭", font=FONT_BUTTON,
                                  bg=BUTTON_BG, relief="raised", width=4,
                                  command=self.next_track)
        self.btn_next.pack(side=tk.LEFT, padx=2)

        # Volume section on the right
        vol_frame = tk.Frame(ctrl_frame, bg=BG_MAIN)
        vol_frame.pack(side=tk.RIGHT, padx=(10, 0))

        tk.Label(vol_frame, text="🔊", bg=BG_MAIN, font=FONT_SMALL).pack(side=tk.LEFT)
        self.vol_scale = ttk.Scale(vol_frame, from_=0, to=100, variable=self.volume_var,
                                   orient=tk.HORIZONTAL, length=120,
                                   command=self._on_volume_change)
        self.vol_scale.pack(side=tk.LEFT, padx=4)

    def _create_progress_bar(self):
        """Seekable progress bar with time display."""
        prog_frame = tk.Frame(self, bg=BG_MAIN, padx=10)
        prog_frame.pack(fill=tk.X, pady=(0, 5))

        self.prog_scale = ttk.Scale(prog_frame, from_=0, to=100,  # max set dynamically
                                    variable=self.progress_var,
                                    orient=tk.HORIZONTAL,
                                    command=self._on_progress_move)
        self.prog_scale.pack(fill=tk.X, side=tk.LEFT, expand=True)

        # Prevent automatic slider updates while user drags
        self.prog_scale.bind("<Button-1>", self._on_slider_press)
        self.prog_scale.bind("<ButtonRelease-1>", self._on_slider_release)

    def _create_playlist(self):
        """Treeview playlist area and Add Files button."""
        pl_frame = tk.Frame(self, bg=BG_MAIN, padx=10, pady=(0, 10))
        pl_frame.pack(fill=tk.BOTH, expand=True)

        # Button above playlist
        btn_add = tk.Button(pl_frame, text="Add Files", font=FONT_BUTTON,
                            bg=BUTTON_BG, relief="raised",
                            command=self.add_files)
        btn_add.pack(anchor="w", pady=(0, 4))

        # Treeview with scrollbars
        tree_container = tk.Frame(pl_frame, bg=BG_MAIN)
        tree_container.pack(fill=tk.BOTH, expand=True)

        self.playlist_tree = ttk.Treeview(tree_container,
                                          columns=("Track", "Duration"),
                                          show="headings",
                                          selectmode="browse")
        self.playlist_tree.heading("Track", text="Track", anchor="w")
        self.playlist_tree.heading("Duration", text="Duration", anchor="e")
        self.playlist_tree.column("Track", width=400, stretch=True)
        self.playlist_tree.column("Duration", width=80, anchor="e", stretch=False)

        vsb = ttk.Scrollbar(tree_container, orient="vertical",
                            command=self.playlist_tree.yview)
        self.playlist_tree.configure(yscrollcommand=vsb.set)

        self.playlist_tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        tree_container.rowconfigure(0, weight=1)
        tree_container.columnconfigure(0, weight=1)

        # Double-click to play
        self.playlist_tree.bind("<Double-1>", self._on_playlist_doubleclick)

    # ------------------------------------------------------------------
    # Playback Logic
    # ------------------------------------------------------------------
    def load_track(self, index):
        """Stop current playback, load and play track at playlist index."""
        if not self.playlist or index < 0 or index >= len(self.playlist):
            return
        try:
            path = self.playlist[index]
            media = self.vlc_instance.media_new(path)
            self.player.set_media(media)
            self.player.play()
            self.current_track_index = index
            self.is_playing = True
            self._update_play_button()
            self._update_track_display(index)
        except Exception as e:
            messagebox.showerror("Playback Error", f"Failed to play:\n{path}\n\n{e}")
            self.is_playing = False
            self._update_play_button()

    def play_pause(self):
        """Toggle play/pause state."""
        if self.player.get_state() == vlc.State.Playing:
            try:
                self.player.pause()
                self.is_playing = False
            except Exception as e:
                messagebox.showerror("Error", f"Pause failed:\n{e}")
        else:
            # If stopped or paused, try to resume or start from first track
            if self.current_track_index < 0 and self.playlist:
                self.load_track(0)
            else:
                try:
                    self.player.play()
                    self.is_playing = True
                except Exception as e:
                    messagebox.showerror("Error", f"Play failed:\n{e}")
        self._update_play_button()

    def stop(self):
        """Stop playback and reset progress."""
        try:
            self.player.stop()
            self.is_playing = False
            self.progress_var.set(0)
            self.track_time_var.set("--:-- / --:--")
            self.track_name_var.set("Stopped")
            self._update_play_button()
        except Exception as e:
            messagebox.showerror("Error", f"Stop failed:\n{e}")

    def next_track(self):
        """Play next track in playlist (cyclic)."""
        if not self.playlist:
            return
        next_idx = (self.current_track_index + 1) % len(self.playlist)
        self.load_track(next_idx)

    def prev_track(self):
        """Play previous track in playlist (cyclic)."""
        if not self.playlist:
            return
        prev_idx = (self.current_track_index - 1) % len(self.playlist)
        self.load_track(prev_idx)

    def _on_volume_change(self, value):
        """Update VLC volume when slider is moved."""
        try:
            vol = int(float(value))
            self.player.audio_set_volume(vol)
        except Exception:
            pass  # VLC may not be initialised

    # ------------------------------------------------------------------
    # Playlist Management
    # ------------------------------------------------------------------
    def add_files(self):
        """Open file dialog and add audio files to the playlist."""
        files = filedialog.askopenfilenames(
            title="Select Audio Files",
            filetypes=[("Audio Files", "*.mp3 *.wav *.ogg"), ("All Files", "*.*")]
        )
        if not files:
            return

        for file in files:
            if file not in self.playlist:  # avoid duplicates
                self.playlist.append(file)
                name = os.path.basename(file)
                # Insert into Treeview with unknown duration initially
                self.playlist_tree.insert("", tk.END, values=(name, "?"))

    def _on_playlist_doubleclick(self, event):
        """Double-click a playlist item to play it immediately."""
        item = self.playlist_tree.focus()
        if not item:
            return
        # Find index from Treeview item position
        children = self.playlist_tree.get_children()
        index = children.index(item)
        if 0 <= index < len(self.playlist):
            self.load_track(index)

    def _update_track_display(self, index):
        """Refresh track name, duration display, and progress max."""
        path = self.playlist[index]
        name = os.path.basename(path)
        self.track_name_var.set(name)
        # Get duration (seconds) – may be 0 if VLC hasn't parsed yet
        duration = 0
        try:
            media = self.player.get_media()
            if media:
                # parse may be needed, but VLC often sets duration quickly after play
                duration = media.get_duration() // 1000  # ms to s
        except Exception:
            duration = 0
        if duration <= 0:
            duration = 0
        # Update progress slider range
        self.prog_scale.configure(to=max(duration, 1))
        # Update the duration column in the playlist for this track
        dur_str = format_time(duration) if duration > 0 else "?"
        children = self.playlist_tree.get_children()
        if index < len(children):
            self.playlist_tree.item(children[index], values=(name, dur_str))
        self.track_time_var.set(f"00:00 / {format_time(duration)}")

    # ------------------------------------------------------------------
    # Real-time UI Updater (called by .after())
    # ------------------------------------------------------------------
    def _update_ui(self):
        """Periodic update of progress bar and time label."""
        try:
            state = self.player.get_state()

            # Auto-advance if track ended
            if state == vlc.State.Ended:
                self.next_track()
            elif state == vlc.State.Playing:
                if not self.dragging_slider:
                    # Get current position in seconds
                    current_time = self.player.get_time() // 1000
                    self.progress_var.set(current_time)

                    # Get total duration (might have updated)
                    duration = self.player.get_length() // 1000
                    if duration > 0:
                        self.prog_scale.configure(to=duration)
                        # Update playlist duration if previously unknown
                        if self.current_track_index >= 0:
                            children = self.playlist_tree.get_children()
                            if self.current_track_index < len(children):
                                item = children[self.current_track_index]
                                curr_vals = self.playlist_tree.item(item, "values")
                                if curr_vals[1] == "?":
                                    self.playlist_tree.item(item, values=(curr_vals[0], format_time(duration)))

                    # Time string
                    elapsed = format_time(current_time)
                    total = format_time(duration) if duration > 0 else "--:--"
                    self.track_time_var.set(f"{elapsed} / {total}")
                # Update play button icon in case it got out of sync
                if not self.is_playing:
                    self.is_playing = True
                    self._update_play_button()
            elif state in (vlc.State.Paused, vlc.State.Stopped):
                if self.is_playing:
                    self.is_playing = False
                    self._update_play_button()
        except Exception:
            pass  # ignore transient errors during shutdown

        # Schedule next update
        self.after(500, self._update_ui)

    # ------------------------------------------------------------------
    # Progress Slider Interaction (seeking)
    # ------------------------------------------------------------------
    def _on_slider_press(self, event):
        """User starts dragging the progress slider."""
        self.dragging_slider = True

    def _on_slider_release(self, event):
        """User releases slider; seek to that position."""
        self.dragging_slider = False
        try:
            seconds = int(self.progress_var.get())
            self.player.set_time(seconds * 1000)  # VLC expects milliseconds
        except Exception as e:
            messagebox.showerror("Seek Error", f"Could not seek:\n{e}")

    def _on_progress_move(self, value):
        """Called while slider is dragged; we do nothing special here."""
        pass

    # ------------------------------------------------------------------
    # UI Helpers
    # ------------------------------------------------------------------
    def _update_play_button(self):
        """Change play button symbol based on is_playing."""
        self.btn_play.configure(text="⏸" if self.is_playing else "▶")

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------
    def _on_close(self):
        """Release VLC resources and destroy window."""
        try:
            self.player.stop()
            self.player.release()
        except Exception:
            pass
        self.destroy()


# ----------------------------------------------------------------------
# Entry Point
# ----------------------------------------------------------------------
if __name__ == "__main__":
    app = ArrelMedia()
    app.mainloop()