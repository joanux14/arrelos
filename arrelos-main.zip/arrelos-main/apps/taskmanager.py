#!/usr/bin/env python3
"""
ArrelMonitor.py - Intelligent Task Manager & System Optimizer for ArrelOS
Ultra-lightweight real-time process monitor for 32-bit systems with 512 MB RAM.
Uses psutil for process data and a platinum-themed tkinter interface.
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import psutil
import time
import threading
import math

# ----------------------------------------------------------------------
# Platinum color palette
# ----------------------------------------------------------------------
BG_MAIN = "#ececec"
BG_TOOLBAR = "#d4d0c8"
FG_DARK = "#000000"
PLATINUM_HIGHLIGHT = "#c0d2e0"

# ----------------------------------------------------------------------
# Critical system processes that must not be terminated
# ----------------------------------------------------------------------
CRITICAL_PROCESSES = [
    "systemd", "init", "xorg", "xfce4-session", "xfdesktop",
    "xfwm4", "python3", "python", "psutil", "dbus-daemon",
    "polkitd", "login", "bash", "sh", "sshd", "agetty", "udevd"
]

# ----------------------------------------------------------------------
# Lightweight monitoring logic
# ----------------------------------------------------------------------
def get_memory_usage():
    """Return (used_mb, total_mb, percent)."""
    mem = psutil.virtual_memory()
    return (mem.used // (1024*1024), mem.total // (1024*1024), mem.percent)

# ----------------------------------------------------------------------
# Main Application
# ----------------------------------------------------------------------
class ArrelMonitor(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ArrelMonitor - Gestor de Processos")
        self.geometry("850x600")
        self.minsize(700, 500)
        self.configure(bg=BG_MAIN)

        # Style
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook", background=BG_MAIN, borderwidth=0)
        style.configure("TNotebook.Tab", background=BG_TOOLBAR, foreground=FG_DARK,
                        font=("Lucida Grande", 10, "bold"))
        style.map("TNotebook.Tab", background=[("selected", BG_MAIN)])
        style.configure("Treeview", font=("Lucida Grande", 9), rowheight=22)
        style.configure("Treeview.Heading", font=("Lucida Grande", 9, "bold"))
        style.configure("TLabel", background=BG_MAIN, font=("Lucida Grande", 10))
        style.configure("TButton", background=BG_TOOLBAR, font=("Lucida Grande", 10))

        # Main notebook
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

        # Build tabs
        self._build_overview_tab()
        self._build_performance_tab()
        self._build_process_tab()   # third tab (Processos i Optimització)

        # Start periodic update for the process list only (others use their own loops)
        self.after(3000, self._update_process_list)

        # Clean exit
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------------------------------------------------
    # Tab 1: System Overview (minimal but fully functional)
    # ------------------------------------------------------------------
    def _build_overview_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Visió General")
        
        info_frame = ttk.LabelFrame(tab, text="Informació del Sistema", padding=10)
        info_frame.pack(fill=tk.X, padx=10, pady=10)

        # Static labels that will be updated periodically
        self.lbl_hostname = ttk.Label(info_frame, text="Nom de l'equip: ...")
        self.lbl_hostname.grid(row=0, column=0, sticky="w", padx=5, pady=2)
        self.lbl_kernel = ttk.Label(info_frame, text="Kernel: ...")
        self.lbl_kernel.grid(row=1, column=0, sticky="w", padx=5, pady=2)
        self.lbl_cpu = ttk.Label(info_frame, text="CPU: ...")
        self.lbl_cpu.grid(row=0, column=1, sticky="w", padx=5, pady=2)
        self.lbl_mem = ttk.Label(info_frame, text="RAM: ...")
        self.lbl_mem.grid(row=1, column=1, sticky="w", padx=5, pady=2)
        
        # Load static data once (doesn't change during runtime)
        try:
            self.lbl_hostname.config(text=f"Nom de l'equip: {psutil.Process().as_dict()['name']}")  # just a placeholder
            # Better:
            import os
            hostname = os.uname().nodename
            kernel = os.uname().release
            cpu_model = os.uname().machine
            self.lbl_hostname.config(text=f"Nom: {hostname}")
            self.lbl_kernel.config(text=f"Kernel: {kernel}")
            self.lbl_cpu.config(text=f"Arquitectura: {cpu_model}")
        except:
            pass

        # Dynamic update for RAM
        def update_overview():
            mem = psutil.virtual_memory()
            self.lbl_mem.config(text=f"RAM: {mem.total//(1024*1024)} MB total, {mem.available//(1024*1024)} MB disponible")
            self.after(5000, update_overview)
        update_overview()

    # ------------------------------------------------------------------
    # Tab 2: Performance Graphs (simple Canvas-based)
    # ------------------------------------------------------------------
    def _build_performance_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Rendiment")
        
        # CPU graph
        cpu_frame = ttk.LabelFrame(tab, text="Ús de CPU (%)", padding=5)
        cpu_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        self.cpu_canvas = tk.Canvas(cpu_frame, bg="white", height=100, highlightthickness=0)
        self.cpu_canvas.pack(fill=tk.X, pady=5)
        
        # Memory graph
        mem_frame = ttk.LabelFrame(tab, text="Ús de RAM (%)", padding=5)
        mem_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        self.mem_canvas = tk.Canvas(mem_frame, bg="white", height=100, highlightthickness=0)
        self.mem_canvas.pack(fill=tk.X, pady=5)

        # Data storage for graphs (circular buffer)
        self.cpu_history = [0] * 60
        self.mem_history = [0] * 60
        self.graph_width = 600  # will be adjusted on resize

        # Start graph update loop
        self._update_graphs()

    def _update_graphs(self):
        """Redraw CPU and memory usage graphs."""
        try:
            cpu = psutil.cpu_percent()
            mem = psutil.virtual_memory().percent
        except:
            cpu, mem = 0, 0
        
        self.cpu_history.append(cpu)
        self.cpu_history = self.cpu_history[-60:]
        self.mem_history.append(mem)
        self.mem_history = self.mem_history[-60:]
        
        w = self.cpu_canvas.winfo_width() if self.cpu_canvas.winfo_width() > 1 else 600
        h = 100
        self.cpu_canvas.delete("all")
        self.mem_canvas.delete("all")
        
        # Draw CPU graph
        if len(self.cpu_history) > 1:
            step = w / (len(self.cpu_history)-1)
            points = []
            for i, val in enumerate(self.cpu_history):
                x = i * step
                y = h - (val / 100.0 * h)
                points.extend([x, y])
            if len(points) >= 4:
                self.cpu_canvas.create_line(points, fill="red", width=1.5)
        
        # Draw memory graph
        if len(self.mem_history) > 1:
            step = w / (len(self.mem_history)-1)
            points = []
            for i, val in enumerate(self.mem_history):
                x = i * step
                y = h - (val / 100.0 * h)
                points.extend([x, y])
            if len(points) >= 4:
                self.mem_canvas.create_line(points, fill="blue", width=1.5)
        
        self.after(1000, self._update_graphs)

    # ------------------------------------------------------------------
    # Tab 3: Processos i Optimització (Core of the task)
    # ------------------------------------------------------------------
    def _build_process_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Processos i Optimització")
        
        # Main horizontal split: left = process list + kill button, right = advice box
        main_pw = tk.PanedWindow(tab, orient=tk.HORIZONTAL, bg=BG_MAIN, sashwidth=4)
        main_pw.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left pane: process Treeview and controls
        left_frame = ttk.Frame(main_pw)
        main_pw.add(left_frame, weight=3)
        
        # Treeview
        tree_container = ttk.Frame(left_frame)
        tree_container.pack(fill=tk.BOTH, expand=True, pady=(0, 5))
        
        self.process_tree = ttk.Treeview(tree_container,
                                         columns=("PID", "Nom", "RAM (MB)", "CPU (%)", "Estat"),
                                         show="headings", selectmode="browse")
        self.process_tree.heading("PID", text="PID", anchor="w")
        self.process_tree.heading("Nom", text="Nom", anchor="w")
        self.process_tree.heading("RAM (MB)", text="RAM (MB)", anchor="e")
        self.process_tree.heading("CPU (%)", text="CPU (%)", anchor="e")
        self.process_tree.heading("Estat", text="Estat", anchor="w")
        
        self.process_tree.column("PID", width=60, anchor="w")
        self.process_tree.column("Nom", width=150, anchor="w")
        self.process_tree.column("RAM (MB)", width=80, anchor="e")
        self.process_tree.column("CPU (%)", width=70, anchor="e")
        self.process_tree.column("Estat", width=80, anchor="w")
        
        # Scrollbars
        vsb = ttk.Scrollbar(tree_container, orient=tk.VERTICAL, command=self.process_tree.yview)
        hsb = ttk.Scrollbar(tree_container, orient=tk.HORIZONTAL, command=self.process_tree.xview)
        self.process_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        self.process_tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        tree_container.rowconfigure(0, weight=1)
        tree_container.columnconfigure(0, weight=1)
        
        # Kill button
        btn_kill = tk.Button(left_frame, text="Finalitzar Procés", font=("Lucida Grande", 11, "bold"),
                             bg="#b02020", fg="white", activebackground="#e04040",
                             relief=tk.RAISED, padx=10, pady=4,
                             command=self._kill_selected_process)
        btn_kill.pack(pady=(5, 0), anchor="e")
        
        # Right pane: Optimization advice
        right_frame = ttk.LabelFrame(main_pw, text="Consells d'Optimització d'ArrelOS", padding=5)
        main_pw.add(right_frame, weight=1)
        
        self.advice_text = scrolledtext.ScrolledText(right_frame, wrap=tk.WORD,
                                                     font=("Lucida Grande", 9),
                                                     bg="#fff8e0", state=tk.DISABLED,
                                                     height=15)
        self.advice_text.pack(fill=tk.BOTH, expand=True)

    def _update_process_list(self):
        """Fetch real processes and populate the Treeview every 3 seconds."""
        # Clear existing items
        for item in self.process_tree.get_children():
            self.process_tree.delete(item)
        
        try:
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'memory_info', 'cpu_percent', 'status']):
                try:
                    pinfo = proc.info
                    pid = pinfo['pid']
                    name = pinfo['name'] or "?"
                    mem_bytes = pinfo.get('memory_info')
                    if mem_bytes is not None:
                        rss_mb = mem_bytes.rss / (1024 * 1024)
                    else:
                        rss_mb = 0.0
                    cpu = pinfo.get('cpu_percent') or 0.0
                    status = pinfo.get('status', '?')
                    processes.append((pid, name, rss_mb, cpu, status))
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    # Skip processes that disappear or are inaccessible
                    pass
            
            # Sort by RAM usage descending (highest first)
            processes.sort(key=lambda x: x[2], reverse=True)
            
            for pid, name, rss_mb, cpu, status in processes:
                # Insert into tree
                item_id = self.process_tree.insert("", tk.END,
                                                   values=(pid, name, f"{rss_mb:.1f}", f"{cpu:.1f}", status))
                # Highlight critical/system processes with a colour tag (grey background)
                if name.lower() in [c.lower() for c in CRITICAL_PROCESSES]:
                    self.process_tree.item(item_id, tags=("critical",))
                # Highlight heavy processes that might be recommended to close
                if rss_mb > 30 and name.lower() not in [c.lower() for c in CRITICAL_PROCESSES]:
                    self.process_tree.item(item_id, tags=("heavy",))
            
            # Configure tag styles
            self.process_tree.tag_configure("critical", background="#d4d0c8")  # subtle platinum
            self.process_tree.tag_configure("heavy", background="#ffe0e0")    # light red
            
        except Exception as e:
            # If something fails, don't crash
            pass
        
        # Update optimization advice
        self._update_advice()
        
        # Schedule next update
        self.after(3000, self._update_process_list)

    def _update_advice(self):
        """Evaluate memory pressure and generate optimization advice."""
        try:
            total_mem = psutil.virtual_memory().total // (1024*1024)
            used_mem = psutil.virtual_memory().used // (1024*1024)
            mem_percent = psutil.virtual_memory().percent
            swap = psutil.swap_memory()
            swap_used_mb = swap.used // (1024*1024) if swap.total > 0 else 0
        except:
            return

        advice_lines = []
        advice_lines.append(f"RAM total: {total_mem} MB")
        advice_lines.append(f"RAM utilitzada: {used_mem} MB ({mem_percent}%)")
        if swap.total > 0:
            advice_lines.append(f"Swap utilitzada: {swap_used_mb} MB\n")
        
        # Critical memory warning
        if mem_percent > 85:
            advice_lines.append("⚠️ ALERTA: Memòria RAM per sobre del 85%!")
            advice_lines.append("   Es recomana alliberar memòria immediatament.")
        
        # Find heavy non-critical processes from our current list
        heavy_procs = []
        for item in self.process_tree.get_children():
            values = self.process_tree.item(item, "values")
            try:
                pid = int(values[0])
                name = values[1]
                rss_mb = float(values[2])
            except:
                continue
            if name.lower() not in [c.lower() for c in CRITICAL_PROCESSES] and rss_mb > 20:
                heavy_procs.append((name, pid, rss_mb))
        
        if heavy_procs:
            advice_lines.append("\nProcessos pesants detectats:")
            for name, pid, rss in sorted(heavy_procs, key=lambda x: x[2], reverse=True)[:5]:
                advice_lines.append(f"   • {name} (PID {pid}) - {rss:.1f} MB")
                # Add recommendation to close if memory is tight
                if mem_percent > 75:
                    advice_lines.append(f"      → Recomanat tancar per guanyar {rss:.1f} MB")
        
        # Check for known bloatware
        bloat_names = ["cupsd", "bluetoothd", "snapd", "tracker-miner", "evolution", "chrome", "firefox"]
        running_bloat = []
        for item in self.process_tree.get_children():
            values = self.process_tree.item(item, "values")
            name = values[1].lower()
            if any(b in name for b in bloat_names):
                running_bloat.append((values[1], values[0]))
        if running_bloat:
            advice_lines.append("\nServeis no essencials en marxa:")
            for name, pid in running_bloat:
                advice_lines.append(f"   • {name} (PID {pid}) - possible estalvi de RAM si es tanca")
        
        if not advice_lines:
            advice_lines.append("Sistema estable. Memòria sota control.")
        
        # Update the text widget
        self.advice_text.config(state=tk.NORMAL)
        self.advice_text.delete(1.0, tk.END)
        self.advice_text.insert(tk.END, "\n".join(advice_lines))
        self.advice_text.config(state=tk.DISABLED)

    def _kill_selected_process(self):
        """Safely terminate the selected process, with protections for critical processes."""
        sel = self.process_tree.selection()
        if not sel:
            messagebox.showinfo("Selecció necessària",
                                "Si us plau, seleccioneu un procés de la llista.")
            return
        
        item = sel[0]
        values = self.process_tree.item(item, "values")
        if not values:
            return
        try:
            pid = int(values[0])
            name = values[1]
        except:
            messagebox.showerror("Error", "No s'ha pogut llegir el PID del procés seleccionat.")
            return
        
        # Critical process check
        if name.lower() in [c.lower() for c in CRITICAL_PROCESSES]:
            messagebox.showwarning("Acció protegida",
                                   f"Acció protegida: '{name}' (PID {pid}) és un procés vital per a ArrelOS.\n"
                                   "No es pot finalitzar.")
            return
        
        # Confirm termination
        if not messagebox.askyesno("Confirmar finalització",
                                   f"Esteu segur que voleu finalitzar '{name}' (PID {pid})?"):
            return
        
        try:
            proc = psutil.Process(pid)
            proc.terminate()
            # Wait briefly to see if it stopped
            gone, still_alive = psutil.wait_procs([proc], timeout=2)
            if still_alive:
                # Force kill if still alive
                proc.kill()
            messagebox.showinfo("Fet", f"El procés '{name}' ha estat finalitzat.")
        except psutil.NoSuchProcess:
            messagebox.showwarning("Ja no existeix",
                                   "Aquest procés ja ha desaparegut.")
        except psutil.AccessDenied:
            messagebox.showerror("Permís denegat",
                                 "No teniu permís per finalitzar aquest procés.\n"
                                 "Pot ser propietat d'un altre usuari o del sistema.")
        except Exception as e:
            messagebox.showerror("Error", f"No s'ha pogut finalitzar: {str(e)}")
        finally:
            # Refresh list immediately
            self._update_process_list()

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------
    def _on_close(self):
        self.destroy()

# ----------------------------------------------------------------------
# Entry Point
# ----------------------------------------------------------------------
if __name__ == "__main__":
    # Check for psutil availability
    try:
        import psutil
    except ImportError:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Error de dependència",
                             "El mòdul 'psutil' no està instal·lat.\n"
                             "Instal·leu-lo amb: pip install psutil")
        root.destroy()
        exit(1)
    app = ArrelMonitor()
    app.mainloop()