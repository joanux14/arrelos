#!/usr/bin/env python3
"""
ArrelBrowser – Mini-navegador minimalista per a ArrelOS (Raspberry Pi Zero 2 W)
Utilitza PyQt6 i QWebEngineView. Característiques:
  - Màxim 3 pestanyes simultànies
  - Llista blanca de dominis permesos
  - Neteja de memòria en tancar pestanyes
  - Interfície senzilla estil macOS
  - Preparat per ser compilat amb PyInstaller
"""

import sys
import os
from PyQt6.QtCore import QUrl, Qt, QTimer
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QTabWidget, QToolBar, QLineEdit,
    QPushButton, QMenu, QAction, QMessageBox, QInputDialog, QDialog,
    QVBoxLayout, QLabel, QListWidget, QDialogButtonBox, QWidget
)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineProfile, QWebEngineSettings

# ----------------------------------------------------------------------
# Configuració
# ----------------------------------------------------------------------
HOME_URL = "https://arrelos.neocities.org"
MAX_TABS = 3

# Llista blanca de dominis permesos (es pot modificar des del menú)
DEFAULT_WHITELIST = [
    "arrelos.neocities.org",
    "neocities.org",
    "duckduckgo.com",
    "wikipedia.org",
    "github.com",
    "copilot.microsoft.com",
    "debian.org",
    "python.org",
    "archive.org",
    "regio7.cat",
    "bbc.com/news/text",
    "ccma.cat/324/",
    "youtube.com"
]

# ----------------------------------------------------------------------
# Classe principal del navegador
# ----------------------------------------------------------------------
class MiniBrowser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ArrelBrowser")
        self.resize(1024, 600)  # Mida inicial adequada per a pantalles petites

        # Llista blanca (carregada o per defecte)
        self.whitelist = DEFAULT_WHITELIST.copy()

        # Emmagatzematge temporal de l'historial (per netejar)
        self.history = []

        # Pestanyes
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self._tancar_pestanya)
        self.tabs.currentChanged.connect(self._canvi_pestanya)
        self.setCentralWidget(self.tabs)

        # Crear la primera pestanya amb la pàgina d'inici
        self._nova_pestanya(HOME_URL)

        # Barra de navegació
        self._crear_barra_navegacio()

        # Menú de configuració
        self._crear_menu_configuracio()

        # Timer per alliberar memòria periòdicament
        self._memory_timer = QTimer()
        self._memory_timer.timeout.connect(self._netejar_memoria)
        self._memory_timer.start(60000)  # cada 60 segons

    # ------------------------------------------------------------------
    # Barra de navegació (estil macOS pla)
    # ------------------------------------------------------------------
    def _crear_barra_navegacio(self):
        toolbar = QToolBar("Navegació")
        toolbar.setMovable(False)
        toolbar.setStyleSheet("""
            QToolBar { background-color: #e0e0e0; spacing: 4px; padding: 2px; }
            QPushButton { background-color: #d0d0d0; border: none; border-radius: 4px; padding: 4px 8px; }
            QPushButton:hover { background-color: #c0c0c0; }
            QLineEdit { border: 1px solid #a0a0a0; border-radius: 4px; padding: 2px 6px; }
        """)
        self.addToolBar(toolbar)

        # Botó Enrere
        btn_back = QPushButton("◀")
        btn_back.clicked.connect(self._enrere)
        toolbar.addWidget(btn_back)

        # Botó Endavant
        btn_forward = QPushButton("▶")
        btn_forward.clicked.connect(self._endavant)
        toolbar.addWidget(btn_forward)

        # Botó Recarregar
        btn_reload = QPushButton("↻")
        btn_reload.clicked.connect(self._recarregar)
        toolbar.addWidget(btn_reload)

        # Barra d'adreces
        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self._navegar_url)
        toolbar.addWidget(self.url_bar)

        # Botó Configuració
        btn_config = QPushButton("⚙")
        btn_config.clicked.connect(self._obrir_configuracio)
        toolbar.addWidget(btn_config)

    # ------------------------------------------------------------------
    # Menú de configuració (acció principal)
    # ------------------------------------------------------------------
    def _crear_menu_configuracio(self):
        menu = self.menuBar().addMenu("Configuració")

        # Netejar Cache
        action_cache = QAction("Netejar Cache", self)
        action_cache.triggered.connect(self._netejar_cache)
        menu.addAction(action_cache)

        # Esborrar Historial
        action_hist = QAction("Esborrar Historial", self)
        action_hist.triggered.connect(self._esborrar_historial)
        menu.addAction(action_hist)

        # Gestionar Llista Blanca
        action_whitelist = QAction("Gestionar Llista Blanca", self)
        action_whitelist.triggered.connect(self._gestionar_whitelist)
        menu.addAction(action_whitelist)

    # ------------------------------------------------------------------
    # Gestió de pestanyes
    # ------------------------------------------------------------------
    def _nova_pestanya(self, url=None):
        """Crea una nova pestanya si no s'ha superat el límit."""
        if self.tabs.count() >= MAX_TABS:
            QMessageBox.warning(self, "Límit de pestanyes",
                                f"Només es permeten {MAX_TABS} pestanyes simultànies.\nTanqueu una pestanya abans d'obrir-ne una altra.")
            return None

        if url is None:
            url = HOME_URL

        browser = QWebEngineView()
        # Configuració del perfil per a la pestanya
        profile = browser.page().profile()
        profile.setHttpCacheType(QWebEngineProfile.HttpCacheType.DiskHttpCache)
        # La memòria s'allibera en eliminar la vista

        browser.setUrl(QUrl(url))
        browser.urlChanged.connect(self._actualitzar_url_bar)
        browser.titleChanged.connect(lambda title, idx=self.tabs.count(): self._actualitzar_titol(idx, title))

        idx = self.tabs.addTab(browser, "Carregant...")
        self.tabs.setCurrentIndex(idx)

        # Guardar referència (no és necessari, el tab widget ho gestiona)
        return browser

    def _tancar_pestanya(self, index):
        """Tanca una pestanya i allibera la memòria immediatament."""
        if self.tabs.count() <= 1:
            return  # Sempre mantenir almenys una pestanya

        widget = self.tabs.widget(index)
        self.tabs.removeTab(index)
        # Forçar l'alliberament del widget
        widget.deleteLater()
        # Netejar la memòria del procés
        self._netejar_memoria()

    def _canvi_pestanya(self, index):
        """Quan es canvia de pestanya, actualitzar la barra d'adreces."""
        if index >= 0:
            browser = self.tabs.currentWidget()
            if browser:
                self.url_bar.setText(browser.url().toString())

    # ------------------------------------------------------------------
    # Navegació
    # ------------------------------------------------------------------
    def _enrere(self):
        browser = self.tabs.currentWidget()
        if browser:
            browser.back()

    def _endavant(self):
        browser = self.tabs.currentWidget()
        if browser:
            browser.forward()

    def _recarregar(self):
        browser = self.tabs.currentWidget()
        if browser:
            browser.reload()

    def _navegar_url(self):
        """Processa l'URL introduït i comprova la llista blanca."""
        text = self.url_bar.text().strip()
        if not text:
            return

        # Afegir esquema si falta
        if not text.startswith("http://") and not text.startswith("https://"):
            text = "https://" + text

        # Comprovar la llista blanca
        if not self._es_permes(text):
            QMessageBox.warning(self, "Accés bloquejat",
                                f"El domini d'aquesta URL no està a la llista blanca.\n"
                                f"URL: {text}\n"
                                f"Contacteu amb l'administrador si creieu que hauria d'estar permès.")
            return

        browser = self.tabs.currentWidget()
        if browser:
            browser.setUrl(QUrl(text))

    def _es_permes(self, url_str):
        """Retorna True si el domini de la URL està a la llista blanca."""
        from urllib.parse import urlparse
        hostname = urlparse(url_str).hostname
        if not hostname:
            return False
        # Comprovar si el hostname o el domini principal està a la llista
        for domain in self.whitelist:
            if hostname == domain or hostname.endswith("." + domain):
                return True
        return False

    # ------------------------------------------------------------------
    # Actualitzacions de la barra d'adreces i títol
    # ------------------------------------------------------------------
    def _actualitzar_url_bar(self, url):
        """Actualitza la barra d'adreces amb l'URL actual de la pestanya activa."""
        browser = self.tabs.currentWidget()
        if browser and browser.url() == url:
            self.url_bar.setText(url.toString())

    def _actualitzar_titol(self, index, title):
        """Canvia el títol de la pestanya."""
        self.tabs.setTabText(index, title[:25] if len(title) > 25 else title)

    # ------------------------------------------------------------------
    # Configuració
    # ------------------------------------------------------------------
    def _netejar_cache(self):
        """Esborra la memòria cau de totes les pestanyes i del perfil global."""
        profile = QWebEngineProfile.defaultProfile()
        profile.clearHttpCache()
        QMessageBox.information(self, "Cache netejada", "La memòria cau del navegador s'ha esborrat correctament.")

    def _esborrar_historial(self):
        """Neteja l'historial (local) i el del perfil."""
        self.history.clear()
        QMessageBox.information(self, "Historial esborrat", "L'historial de navegació s'ha eliminat.")

    def _gestionar_whitelist(self):
        """Obre un diàleg per afegir o eliminar dominis de la llista blanca."""
        dialog = QDialog(self)
        dialog.setWindowTitle("Gestionar Llista Blanca")
        dialog.resize(400, 300)
        layout = QVBoxLayout(dialog)

        layout.addWidget(QLabel("Dominis permesos (un per línia):"))

        list_widget = QListWidget()
        for domain in self.whitelist:
            list_widget.addItem(domain)
        layout.addWidget(list_widget)

        btn_layout = QDialogButtonBox()
        btn_ok = btn_layout.addButton("Desar", QDialogButtonBox.ButtonRole.AcceptRole)
        btn_cancel = btn_layout.addButton("Cancel·lar", QDialogButtonBox.ButtonRole.RejectRole)
        layout.addWidget(btn_layout)

        btn_ok.clicked.connect(dialog.accept)
        btn_cancel.clicked.connect(dialog.reject)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            # Recollir els nous valors
            new_whitelist = []
            for i in range(list_widget.count()):
                item = list_widget.item(i)
                domain = item.text().strip()
                if domain:
                    new_whitelist.append(domain)
            self.whitelist = new_whitelist
            QMessageBox.information(self, "Llista Blanca", "La llista blanca s'ha actualitzat.")

    # ------------------------------------------------------------------
    # Alliberament de memòria
    # ------------------------------------------------------------------
    def _netejar_memoria(self):
        """Força l'alliberament de memòria no utilitzada pel procés."""
        import gc
        gc.collect()
        # També es pot forçar un trim de la memòria del sistema
        try:
            import ctypes
            libc = ctypes.CDLL("libc.so.6")
            libc.malloc_trim(0)
        except:
            pass  # No disponible en totes les plataformes

    def closeEvent(self, event):
        """Quan es tanca la finestra, netejar l'historial i la memòria."""
        self._esborrar_historial()
        self._netejar_cache()
        event.accept()

# ----------------------------------------------------------------------
# Punt d'entrada
# ----------------------------------------------------------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")  # Estil net i consistent

    # Estil global estil macOS (colors neutres)
    app.setStyleSheet("""
        QMainWindow { background-color: #e8e8e8; }
        QTabWidget::pane { border: 1px solid #c0c0c0; background-color: #f0f0f0; }
        QTabBar::tab { background-color: #d0d0d0; padding: 4px 10px; border-top-left-radius: 4px; border-top-right-radius: 4px; }
        QTabBar::tab:selected { background-color: #f0f0f0; }
    """)

    browser = MiniBrowser()
    browser.show()
    sys.exit(app.exec())
