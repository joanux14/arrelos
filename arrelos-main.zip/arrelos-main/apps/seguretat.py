#!/usr/bin/env python3
"""
Seguretat_Arrel.py – Suite d'Administració i Hardening per a ArrelOS
Control local del tallafocs, blindatge de xarxa i terminal SSH remota.
Requereix: pip install paramiko
Executar amb permisos de sudo configurats sense contrasenya per a les ordres de sistema.
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import subprocess
import threading
import time
import os

# ----------------------------------------------------------------------
# Intenta importar paramiko, avisa si manca
# ----------------------------------------------------------------------
try:
    import paramiko
    PARAMIKO_OK = True
except ImportError:
    PARAMIKO_OK = False
    messagebox.showwarning("Paràmetre mancant",
                           "El mòdul paramiko no està instal·lat.\n"
                           "Executeu: pip install paramiko\n"
                           "La funcionalitat SSH romandrà desactivada.")

# ----------------------------------------------------------------------
# Constants de la paleta platí
# ----------------------------------------------------------------------
BG_MAIN = "#ececec"
BG_TOOL = "#d4d0c8"
FG_DARK = "#000000"
BTN_ACTIVE = "#a0e0a0"   # verd clar per actiu
BTN_INACTIVE = "#e0a0a0" # vermell clar per inactiu

# ----------------------------------------------------------------------
# Classe principal
# ----------------------------------------------------------------------
class SeguretatArrel(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Seguretat ArrelOS – Centre de Control")
        self.geometry("800x550")
        self.minsize(700, 450)
        self.configure(bg=BG_MAIN)

        # Estats dels controls (es guarden en memòria)
        self.ufw_enabled = False
        self.whitelist_enabled = False
        self.block_telnet = False
        self.block_ftp = False
        self.tty_locked = False

        # Per al terminal SSH
        self.ssh_client = None
        self.ssh_channel = None
        self.ssh_connected = False

        # Crear la interfície
        self._crear_columnes()
        self._crear_seccio_firewall()
        self._crear_seccio_whitelist()
        self._crear_seccio_protocols()
        self._crear_seccio_tty()
        self._crear_seccio_ssh()

        # Actualitzar estats inicials comprovant el sistema
        self._comprovar_estat_inicial()

    # ------------------------------------------------------------------
    # Estructura de dues columnes
    # ------------------------------------------------------------------
    def _crear_columnes(self):
        # PanedWindow horitzontal per dividir
        self.paned = tk.PanedWindow(self, orient=tk.HORIZONTAL, bg=BG_MAIN, sashwidth=4)
        self.paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Columna esquerra (Local)
        self.frame_esquerra = tk.Frame(self.paned, bg=BG_MAIN, relief=tk.RAISED, borderwidth=1)
        self.paned.add(self.frame_esquerra, width=380)

        # Columna dreta (SSH)
        self.frame_dreta = tk.Frame(self.paned, bg=BG_MAIN, relief=tk.RAISED, borderwidth=1)
        self.paned.add(self.frame_dreta, width=400)

    # ------------------------------------------------------------------
    # Secció Tallafocs (UFW)
    # ------------------------------------------------------------------
    def _crear_seccio_firewall(self):
        frame = tk.LabelFrame(self.frame_esquerra, text="Tallafocs (UFW)", bg=BG_MAIN,
                              font=("Lucida Grande", 10, "bold"), padx=5, pady=5)
        frame.pack(fill=tk.X, padx=5, pady=5)

        self.btn_ufw = tk.Button(frame, text="UFW: Desactivat", font=("Lucida Grande", 10),
                                 bg=BTN_INACTIVE, relief=tk.RAISED, width=25,
                                 command=self._toggle_ufw)
        self.btn_ufw.pack(pady=2)

    def _toggle_ufw(self):
        if self.ufw_enabled:
            self._executar_ordre("sudo ufw disable", "Tallafocs desactivat.")
            self.ufw_enabled = False
            self.btn_ufw.config(text="UFW: Desactivat", bg=BTN_INACTIVE)
        else:
            self._executar_ordre("sudo ufw enable", "Tallafocs activat.")
            self.ufw_enabled = True
            self.btn_ufw.config(text="UFW: Activat", bg=BTN_ACTIVE)

    # ------------------------------------------------------------------
    # Secció Llista Blanca d'IPs
    # ------------------------------------------------------------------
    def _crear_seccio_whitelist(self):
        frame = tk.LabelFrame(self.frame_esquerra, text="Llista Blanca d'IPs Segures", bg=BG_MAIN,
                              font=("Lucida Grande", 10, "bold"), padx=5, pady=5)
        frame.pack(fill=tk.X, padx=5, pady=5)

        tk.Label(frame, text="IP o rang (ex: 192.168.1.0/24):", bg=BG_MAIN).pack(anchor="w")
        self.entry_whitelist = tk.Entry(frame, width=30, font=("Lucida Grande", 10))
        self.entry_whitelist.pack(pady=2)

        self.btn_whitelist = tk.Button(frame, text="Aplicar Whitelist", font=("Lucida Grande", 10),
                                       bg=BTN_INACTIVE, relief=tk.RAISED, command=self._aplicar_whitelist)
        self.btn_whitelist.pack(pady=2)

    def _aplicar_whitelist(self):
        ip = self.entry_whitelist.get().strip()
        if not ip:
            messagebox.showwarning("IP buida", "Introduïu una IP o rang vàlid.")
            return

        # Confirmació per evitar bloquejar-se un mateix
        if not messagebox.askyesno("Confirmar Whitelist",
                                   "Aquesta acció tancarà totes les connexions entrants excepte la IP especificada.\n"
                                   "Assegureu-vos que no perdeu l'accés. Continuar?"):
            return

        # Apliquem regles iptables restrictives
        ordres = [
            "sudo iptables -F INPUT",
            "sudo iptables -P INPUT DROP",
            f"sudo iptables -A INPUT -s {ip} -j ACCEPT",
            "sudo iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT"
        ]
        for ordre in ordres:
            self._executar_ordre(ordre, "")

        self.whitelist_enabled = True
        self.btn_whitelist.config(bg=BTN_ACTIVE, text="Whitelist Activa")

    # ------------------------------------------------------------------
    # Secció Bloqueig de Protocols (Telnet, FTP)
    # ------------------------------------------------------------------
    def _crear_seccio_protocols(self):
        frame = tk.LabelFrame(self.frame_esquerra, text="Protocols No Segurs", bg=BG_MAIN,
                              font=("Lucida Grande", 10, "bold"), padx=5, pady=5)
        frame.pack(fill=tk.X, padx=5, pady=5)

        # Telnet
        self.btn_telnet = tk.Button(frame, text="Telnet (23): Permès", font=("Lucida Grande", 10),
                                    bg=BTN_INACTIVE, relief=tk.RAISED, width=25,
                                    command=self._toggle_telnet)
        self.btn_telnet.pack(pady=2)

        # FTP
        self.btn_ftp = tk.Button(frame, text="FTP (21): Permès", font=("Lucida Grande", 10),
                                 bg=BTN_INACTIVE, relief=tk.RAISED, width=25,
                                 command=self._toggle_ftp)
        self.btn_ftp.pack(pady=2)

    def _toggle_telnet(self):
        if self.block_telnet:
            ordre = "sudo iptables -D INPUT -p tcp --dport 23 -j DROP"
            self._executar_ordre(ordre, "Telnet desbloquejat.")
            self.block_telnet = False
            self.btn_telnet.config(text="Telnet (23): Permès", bg=BTN_INACTIVE)
        else:
            ordre = "sudo iptables -A INPUT -p tcp --dport 23 -j DROP"
            self._executar_ordre(ordre, "Telnet bloquejat.")
            self.block_telnet = True
            self.btn_telnet.config(text="Telnet (23): Bloquejat", bg=BTN_ACTIVE)

    def _toggle_ftp(self):
        if self.block_ftp:
            ordre = "sudo iptables -D INPUT -p tcp --dport 21 -j DROP"
            self._executar_ordre(ordre, "FTP desbloquejat.")
            self.block_ftp = False
            self.btn_ftp.config(text="FTP (21): Permès", bg=BTN_INACTIVE)
        else:
            ordre = "sudo iptables -A INPUT -p tcp --dport 21 -j DROP"
            self._executar_ordre(ordre, "FTP bloquejat.")
            self.block_ftp = True
            self.btn_ftp.config(text="FTP (21): Bloquejat", bg=BTN_ACTIVE)

    # ------------------------------------------------------------------
    # Secció Blindatge TTY
    # ------------------------------------------------------------------
    def _crear_seccio_tty(self):
        frame = tk.LabelFrame(self.frame_esquerra, text="Blindatge de Consola TTY", bg=BG_MAIN,
                              font=("Lucida Grande", 10, "bold"), padx=5, pady=5)
        frame.pack(fill=tk.X, padx=5, pady=5)

        self.btn_tty = tk.Button(frame, text="TTY Lock: Desactivat", font=("Lucida Grande", 10),
                                 bg=BTN_INACTIVE, relief=tk.RAISED, width=25,
                                 command=self._toggle_tty)
        self.btn_tty.pack(pady=2)

    def _toggle_tty(self):
        fitxer = "/etc/X11/xorg.conf.d/10-dontvtswitch.conf"
        if self.tty_locked:
            ordre = f"sudo rm -f {fitxer}"
            self._executar_ordre(ordre, "Blindatge TTY eliminat.")
            self.tty_locked = False
            self.btn_tty.config(text="TTY Lock: Desactivat", bg=BTN_INACTIVE)
        else:
            # Crear el fitxer amb la configuració
            contingut = 'Section "ServerFlags"\n    Option "DontVTSwitch" "true"\nEndSection\n'
            ordre = f"echo '{contingut}' | sudo tee {fitxer} > /dev/null"
            self._executar_ordre(ordre, "Blindatge TTY activat.")
            self.tty_locked = True
            self.btn_tty.config(text="TTY Lock: Activat", bg=BTN_ACTIVE)

    # ------------------------------------------------------------------
    # Secció Terminal SSH (Columna Dreta)
    # ------------------------------------------------------------------
    def _crear_seccio_ssh(self):
        frame = tk.LabelFrame(self.frame_dreta, text="Terminal de Connexió SSH Remota", bg=BG_MAIN,
                              font=("Lucida Grande", 10, "bold"), padx=5, pady=5)
        frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Barra superior: IP, Usuari, Contrasenya
        barra = tk.Frame(frame, bg=BG_MAIN)
        barra.pack(fill=tk.X, pady=2)

        tk.Label(barra, text="IP:", bg=BG_MAIN).grid(row=0, column=0, sticky="e")
        self.entry_ip = tk.Entry(barra, width=14, font=("Lucida Grande", 10))
        self.entry_ip.grid(row=0, column=1, padx=2)

        tk.Label(barra, text="Usuari:", bg=BG_MAIN).grid(row=0, column=2, sticky="e")
        self.entry_user = tk.Entry(barra, width=10, font=("Lucida Grande", 10))
        self.entry_user.grid(row=0, column=3, padx=2)

        tk.Label(barra, text="Contrasenya:", bg=BG_MAIN).grid(row=0, column=4, sticky="e")
        self.entry_pass = tk.Entry(barra, width=12, font=("Lucida Grande", 10), show="*")
        self.entry_pass.grid(row=0, column=5, padx=2)

        self.btn_connectar = tk.Button(barra, text="Connectar", font=("Lucida Grande", 10),
                                       bg=BG_TOOL, command=self._connectar_ssh)
        self.btn_connectar.grid(row=0, column=6, padx=4)

        # Àrea de text tipus terminal (negre amb verd)
        self.terminal = tk.Text(frame, bg="black", fg="#00ff00", insertbackground="#00ff00",
                                font=("Courier New", 11), wrap=tk.WORD, state=tk.DISABLED,
                                relief=tk.SUNKEN, borderwidth=2)
        self.terminal.pack(fill=tk.BOTH, expand=True, pady=5)

        # Scrollbar
        self.scroll_term = tk.Scrollbar(frame, command=self.terminal.yview)
        self.scroll_term.pack(side=tk.RIGHT, fill=tk.Y)
        self.terminal.config(yscrollcommand=self.scroll_term.set)

        # Quan estem connectats, les tecles s'envien al canal SSH
        self.terminal.bind("<Key>", self._on_key_ssh)

    def _on_key_ssh(self, event):
        """Envia la tecla premuda al canal SSH si està actiu."""
        if not self.ssh_connected or not self.ssh_channel:
            return
        # Caràcters especials
        if event.keysym == "Return":
            self.ssh_channel.send("\r")
        elif event.keysym == "BackSpace":
            self.ssh_channel.send("\x7f")
        elif event.keysym == "Tab":
            self.ssh_channel.send("\t")
        elif event.char and len(event.char) == 1:
            self.ssh_channel.send(event.char)
        # Evita que el Text processi la tecla (no volem escriure localment)
        return "break"

    def _connectar_ssh(self):
        """Inicia la connexió SSH amb Paramiko."""
        if not PARAMIKO_OK:
            messagebox.showerror("Error", "Paramiko no està instal·lat.")
            return

        ip = self.entry_ip.get().strip()
        user = self.entry_user.get().strip()
        password = self.entry_pass.get()

        if not ip or not user:
            messagebox.showerror("Dades mancants", "Introduïu IP i usuari.")
            return

        # Desconnectar si ja hi ha una connexió oberta
        if self.ssh_connected:
            self._desconnectar_ssh()

        # Iniciar la connexió en un fil separat per no bloquejar la GUI
        self.btn_connectar.config(state=tk.DISABLED, text="Connectant...")
        self.terminal.config(state=tk.NORMAL)
        self.terminal.delete(1.0, tk.END)
        self.terminal.insert(tk.END, f"Connectant a {user}@{ip}...\n")
        self.terminal.config(state=tk.DISABLED)

        fil = threading.Thread(target=self._fil_connexio_ssh, args=(ip, user, password), daemon=True)
        fil.start()

    def _fil_connexio_ssh(self, ip, user, password):
        """Executa la connexió SSH en un fil no bloquejant."""
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(hostname=ip, username=user, password=password, timeout=10)

            # Obrir un shell interactiu
            channel = client.invoke_shell(width=120, height=40)
            self.ssh_client = client
            self.ssh_channel = channel
            self.ssh_connected = True

            # Actualitzar la GUI des del fil principal
            self.after(0, self._ssh_connectat)
            # Iniciar la lectura asíncrona de la sortida
            self.after(100, self._llegir_sortida_ssh)

        except paramiko.AuthenticationException:
            self.after(0, self._error_ssh, "Autenticació fallida.")
        except paramiko.SSHException as e:
            self.after(0, self._error_ssh, f"Error SSH: {str(e)}")
        except Exception as e:
            self.after(0, self._error_ssh, f"Error de connexió: {str(e)}")

    def _ssh_connectat(self):
        """Actualitza la interfície quan la connexió SSH és exitosa."""
        self.btn_connectar.config(state=tk.NORMAL, text="Desconnectar")
        self.terminal.config(state=tk.NORMAL)
        self.terminal.insert(tk.END, "Connexió establerta. Podeu escriure directament.\n")
        self.terminal.config(state=tk.DISABLED)

    def _error_ssh(self, missatge):
        """Mostra un error a l'àrea del terminal."""
        self.btn_connectar.config(state=tk.NORMAL, text="Connectar")
        self.terminal.config(state=tk.NORMAL)
        self.terminal.insert(tk.END, f"\nERROR: {missatge}\n")
        self.terminal.config(state=tk.DISABLED)
        self.ssh_connected = False

    def _llegir_sortida_ssh(self):
        """Llegeix dades del canal SSH i les afegeix al terminal, sense bloquejar."""
        if not self.ssh_connected or self.ssh_channel is None:
            return

        try:
            if self.ssh_channel.recv_ready():
                data = self.ssh_channel.recv(4096).decode('utf-8', errors='replace')
                if data:
                    self.terminal.config(state=tk.NORMAL)
                    self.terminal.insert(tk.END, data)
                    self.terminal.see(tk.END)
                    self.terminal.config(state=tk.DISABLED)
            # Si el canal es tanca
            if self.ssh_channel.closed:
                self._desconnectar_ssh()
                return
        except Exception as e:
            self.terminal.config(state=tk.NORMAL)
            self.terminal.insert(tk.END, f"\nError de lectura: {e}\n")
            self.terminal.config(state=tk.DISABLED)

        # Tornar a cridar aquest mètode d'aquí a 100 ms
        self.after(100, self._llegir_sortida_ssh)

    def _desconnectar_ssh(self):
        """Tanca el canal i el client SSH."""
        if self.ssh_channel:
            try:
                self.ssh_channel.close()
            except:
                pass
            self.ssh_channel = None
        if self.ssh_client:
            try:
                self.ssh_client.close()
            except:
                pass
            self.ssh_client = None
        self.ssh_connected = False
        self.btn_connectar.config(text="Connectar", state=tk.NORMAL)
        self.terminal.config(state=tk.NORMAL)
        self.terminal.insert(tk.END, "\nDesconnectat.\n")
        self.terminal.config(state=tk.DISABLED)

    # ------------------------------------------------------------------
    # Mètode auxiliar per executar ordres del sistema
    # ------------------------------------------------------------------
    def _executar_ordre(self, ordre, missatge_ok):
        """Executa una ordre amb subprocess, capturant la sortida i errors."""
        try:
            proc = subprocess.run(ordre, shell=True, capture_output=True, text=True, timeout=10)
            if proc.returncode == 0:
                if missatge_ok:
                    messagebox.showinfo("OK", missatge_ok)
            else:
                error = proc.stderr.strip() or "Error desconegut"
                messagebox.showerror("Error", f"L'ordre ha fallat:\n{error}")
        except subprocess.TimeoutExpired:
            messagebox.showerror("Error", "L'ordre ha excedit el temps d'espera.")
        except PermissionError:
            messagebox.showerror("Permisos", "No teniu permisos per executar sudo.\n"
                                           "Configureu sudoers sense contrasenya.")
        except Exception as e:
            messagebox.showerror("Error", f"Excepció: {str(e)}")

    # ------------------------------------------------------------------
    # Comprovació d'estat inicial llegint el sistema
    # ------------------------------------------------------------------
    def _comprovar_estat_inicial(self):
        # UFW
        try:
            res = subprocess.run("sudo ufw status", shell=True, capture_output=True, text=True, timeout=5)
            if "Status: active" in res.stdout:
                self.ufw_enabled = True
                self.btn_ufw.config(text="UFW: Activat", bg=BTN_ACTIVE)
        except:
            pass

        # Telnet i FTP – comprovem si existeixen les regles iptables
        try:
            res = subprocess.run("sudo iptables -L INPUT -n", shell=True, capture_output=True, text=True, timeout=5)
            if "dpt:23" in res.stdout and "DROP" in res.stdout:
                self.block_telnet = True
                self.btn_telnet.config(text="Telnet (23): Bloquejat", bg=BTN_ACTIVE)
            if "dpt:21" in res.stdout and "DROP" in res.stdout:
                self.block_ftp = True
                self.btn_ftp.config(text="FTP (21): Bloquejat", bg=BTN_ACTIVE)
        except:
            pass

        # TTY Lock
        if os.path.exists("/etc/X11/xorg.conf.d/10-dontvtswitch.conf"):
            self.tty_locked = True
            self.btn_tty.config(text="TTY Lock: Activat", bg=BTN_ACTIVE)


# ----------------------------------------------------------------------
# Punt d'entrada
# ----------------------------------------------------------------------
if __name__ == "__main__":
    app = SeguretatArrel()
    app.mainloop()