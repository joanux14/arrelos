#!/usr/bin/env python3
"""
ArrelFiles.py - Native File Explorer for ArrelOS
Ultra-lightweight, production-ready file manager for retro 32-bit systems.
Designed for minimal XFCE/X.org environments on Debian and Raspberry Pi OS Lite.
Uses only Python 3 standard library: tkinter, ttk, os, shutil, pathlib, subprocess.
"""

import os
import shutil
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

# ----------------------------------------------------------------------
# Helper Functions
# ----------------------------------------------------------------------
def format_size(size_bytes):
    """Convert bytes into a human-readable string (e.g. 1.2 KB)."""
    if size_bytes < 0:
        return "Unknown"
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}" if unit != 'B' else f"{size_bytes} B"
        size_bytes /= 1024
    return f"{size_bytes:.1f} PB"


def get_icon_and_type(entry):
    """
    Return (unicode_icon, type_label) based on file/dir properties.
    Uses follow_symlinks=False to avoid circular link problems.
    """
    name = entry.name
    try:
        # is_dir with follow_symlinks=False treats symlinks as files
        if entry.is_dir(follow_symlinks=False):
            return "📁", "Folder"
        # Check file extension for Windows executables (for Wine)
        if name.lower().endswith('.exe'):
            return "⚙️", "Executable"
        # Default file
        return "📄", "File"
    except OSError:
        # Permission or broken symlink – treat as unknown
        return "❓", "Unknown"


def get_file_size(entry):
    """Return formatted size, '-' for directories, 'Unknown' on error."""
    try:
        if entry.is_dir(follow_symlinks=False):
            return "-"
        stat = entry.stat()
        return format_size(stat.st_size)
    except OSError:
        return "Unknown"


# ----------------------------------------------------------------------
# Main Application Class
# ----------------------------------------------------------------------
class ArrelFiles(tk.Tk):
    def __init__(self):
        super().__init__()

        # Window configuration
        self.title("ArrelFiles")
        self.geometry("800x600")
        self.minsize(600, 400)
        self.configure(bg="#ececec")
        self.resizable(True, True)

        # Aqua-inspired style
        self.style = ttk.Style()
        self.style.theme_use('clam')  # gives us more control over colours
        self.style.configure('TFrame', background='#ececec')
        self.style.configure('TLabel', background='#ececec', font=('Lucida Grande', 11))
        self.style.configure('TButton', font=('Lucida Grande', 10), padding=4)
        self.style.configure('Treeview', font=('Lucida Grande', 11),
                             background='white', fieldbackground='white')
        self.style.configure('Treeview.Heading', font=('Lucida Grande', 11, 'bold'))
        self.style.map('Treeview', background=[('selected', '#c0d2e0')])

        # Navigation state
        self.current_path = os.path.expanduser("~")
        self.back_stack = []     # stores previous paths
        self.forward_stack = []  # stores paths after going back
        self.tree_items = {}     # mapping: Treeview item ID -> full path

        # Build UI components
        self._create_toolbar()
        self._create_sidebar()
        self._create_file_area()

        # Load the starting directory
        self._refresh_file_list()
        self._update_path_entry()

    # ------------------------------------------------------------------
    # UI Construction
    # ------------------------------------------------------------------
    def _create_toolbar(self):
        """Top bar with navigation buttons and path entry."""
        toolbar = ttk.Frame(self)
        toolbar.pack(side=tk.TOP, fill=tk.X, padx=2, pady=2)

        # Navigation buttons using Unicode arrows
        self.btn_back = ttk.Button(toolbar, text="◀", width=3, command=self.go_back)
        self.btn_back.pack(side=tk.LEFT, padx=1)

        self.btn_forward = ttk.Button(toolbar, text="▶", width=3, command=self.go_forward)
        self.btn_forward.pack(side=tk.LEFT, padx=1)

        self.btn_up = ttk.Button(toolbar, text="⬆", width=3, command=self.go_up)
        self.btn_up.pack(side=tk.LEFT, padx=1)

        self.btn_refresh = ttk.Button(toolbar, text="🔄", width=3, command=self._refresh_file_list)
        self.btn_refresh.pack(side=tk.LEFT, padx=1)

        # Path entry bar
        self.path_var = tk.StringVar()
        self.path_entry = ttk.Entry(toolbar, textvariable=self.path_var, font=('Lucida Grande', 11))
        self.path_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(8, 0))
        self.path_entry.bind('<Return>', self._on_path_enter)

    def _create_sidebar(self):
        """Left sidebar with shortcut places."""
        sidebar = tk.Frame(self, bg='#d4d0c8', width=180)
        sidebar.pack(side=tk.LEFT, fill=tk.Y, padx=(2, 2), pady=2)
        sidebar.pack_propagate(False)  # keep width fixed

        # Places label
        lbl_places = tk.Label(sidebar, text="Places", bg='#d4d0c8',
                              font=('Lucida Grande', 12, 'bold'), anchor='w')
        lbl_places.pack(fill=tk.X, padx=8, pady=(8, 2))

        # Listbox for shortcuts
        self.shortcut_list = tk.Listbox(sidebar, bg='white', font=('Lucida Grande', 11),
                                        selectmode=tk.SINGLE, exportselection=False,
                                        highlightthickness=0, relief='flat')
        self.shortcut_list.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)

        # Define shortcuts: display name -> absolute path (using helper)
        self.shortcut_paths = []
        shortcuts = [
            ("Home", os.path.expanduser("~")),
            ("Root", "/"),
            ("Documents", os.path.join(os.path.expanduser("~"), "Documents")),
            ("Media", "/media")
        ]
        for display, path in shortcuts:
            self.shortcut_list.insert(tk.END, display)
            self.shortcut_paths.append(path)

        self.shortcut_list.bind('<<ListboxSelect>>', self._on_shortcut_select)

    def _create_file_area(self):
        """Main area with the file list Treeview and scrollbars."""
        main_frame = ttk.Frame(self)
        main_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=2, pady=2)

        # Treeview with columns: Name, Size, Type
        self.tree = ttk.Treeview(main_frame, columns=('Name', 'Size', 'Type'),
                                 show='headings', selectmode='browse')
        self.tree.heading('Name', text='Name', anchor='w')
        self.tree.heading('Size', text='Size', anchor='e')
        self.tree.heading('Type', text='Type', anchor='w')

        # Configure column widths
        self.tree.column('Name', width=300, stretch=True)
        self.tree.column('Size', width=80, anchor='e', stretch=False)
        self.tree.column('Type', width=100, anchor='w', stretch=False)

        # Scrollbars
        vsb = ttk.Scrollbar(main_frame, orient=tk.VERTICAL, command=self.tree.yview)
        hsb = ttk.Scrollbar(main_frame, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        # Grid layout for scrollable Treeview
        self.tree.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        main_frame.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)

        # Bind double-click to open/enter
        self.tree.bind('<Double-1>', self._on_tree_double_click)

    # ------------------------------------------------------------------
    # Navigation Logic
    # ------------------------------------------------------------------
    def navigate_to(self, new_path):
        """Navigate to a directory path, updating history and view."""
        # Avoid no-op navigation to same directory
        if new_path == self.current_path:
            return

        # Resolve to absolute path (handle relative inputs safely)
        if not os.path.isabs(new_path):
            new_path = os.path.join(self.current_path, new_path)
        new_path = os.path.abspath(new_path)

        # Validate
        if not os.path.exists(new_path):
            messagebox.showerror("Error", f"Path does not exist:\n{new_path}")
            return
        if not os.path.isdir(new_path):
            messagebox.showerror("Error", f"Not a directory:\n{new_path}")
            return

        # Update history
        self.back_stack.append(self.current_path)
        self.forward_stack.clear()

        # Change directory
        self.current_path = new_path
        self._refresh_file_list()
        self._update_path_entry()

    def go_back(self):
        if not self.back_stack:
            return
        # Move current to forward stack
        self.forward_stack.append(self.current_path)
        self.current_path = self.back_stack.pop()
        self._refresh_file_list()
        self._update_path_entry()

    def go_forward(self):
        if not self.forward_stack:
            return
        self.back_stack.append(self.current_path)
        self.current_path = self.forward_stack.pop()
        self._refresh_file_list()
        self._update_path_entry()

    def go_up(self):
        parent = os.path.dirname(self.current_path)
        if parent != self.current_path:   # root dir check
            self.navigate_to(parent)

    # ------------------------------------------------------------------
    # File Listing (Treeview population)
    # ------------------------------------------------------------------
    def _refresh_file_list(self):
        """Clear and reload the Treeview with content of current_path."""
        # Remove all existing items
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.tree_items.clear()

        # Gather directory entries
        entries = []
        try:
            with os.scandir(self.current_path) as scandir_it:
                for entry in scandir_it:
                    entries.append(entry)
        except PermissionError:
            messagebox.showwarning("Permission Denied",
                                   f"Cannot read directory:\n{self.current_path}")
            return
        except Exception as e:
            messagebox.showerror("Error", f"Unexpected error reading directory:\n{e}")
            return

        # Sort: directories first, then files, then alphabetical (case-insensitive)
        def sort_key(ent):
            is_dir = ent.is_dir(follow_symlinks=False) if not ent.is_symlink() else False
            return (not is_dir, ent.name.lower())

        entries.sort(key=sort_key)

        # Insert into Treeview
        for entry in entries:
            icon, typ = get_icon_and_type(entry)
            size_str = get_file_size(entry)
            display_name = f"{icon} {entry.name}"
            # Insert item and store full path
            item_id = self.tree.insert('', tk.END, values=(display_name, size_str, typ))
            self.tree_items[item_id] = entry.path

    # ------------------------------------------------------------------
    # Path Entry Handling
    # ------------------------------------------------------------------
    def _update_path_entry(self):
        """Sync the path entry bar with current_path."""
        self.path_var.set(self.current_path)
        # Place cursor at end for convenience
        self.path_entry.icursor(tk.END)

    def _on_path_enter(self, event=None):
        """User pressed Enter in the path entry; attempt navigation."""
        raw = self.path_var.get().strip()
        if not raw:
            return
        # Allow relative paths from current directory
        if not os.path.isabs(raw):
            raw = os.path.join(self.current_path, raw)
        target = os.path.abspath(raw)
        self.navigate_to(target)

    # ------------------------------------------------------------------
    # Sidebar Shortcuts
    # ------------------------------------------------------------------
    def _on_shortcut_select(self, event=None):
        """Navigate to the selected shortcut directory."""
        selection = self.shortcut_list.curselection()
        if not selection:
            return
        idx = selection[0]
        if idx < len(self.shortcut_paths):
            path = self.shortcut_paths[idx]
            self.navigate_to(path)

    # ------------------------------------------------------------------
    # Treeview Double-Click Handler (Open / Execute)
    # ------------------------------------------------------------------
    def _on_tree_double_click(self, event=None):
        """Handle double-click on a file/folder."""
        item_id = self.tree.focus()
        if not item_id:
            return
        full_path = self.tree_items.get(item_id)
        if not full_path:
            return

        # If directory: enter it
        if os.path.isdir(full_path):
            self.navigate_to(full_path)
        else:
            # It's a file -> open with appropriate handler
            self._open_file(full_path)

    def _open_file(self, file_path):
        """Open file using Wine for .exe, otherwise xdg-open."""
        try:
            if file_path.lower().endswith('.exe'):
                # Use Wine; wine should be in PATH on ArrelOS
                subprocess.Popen(['wine', file_path],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL,
                                 start_new_session=True)
            else:
                subprocess.Popen(['xdg-open', file_path],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL,
                                 start_new_session=True)
        except FileNotFoundError:
            messagebox.showerror("Error",
                                 f"Could not find required program to open:\n{file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open file:\n{e}")


# ----------------------------------------------------------------------
# Application Entry Point
# ----------------------------------------------------------------------
if __name__ == '__main__':
    app = ArrelFiles()
    app.mainloop()