#!/usr/bin/env python3
"""
ArrelWord.py - Flagship Word Processor for ArrelOS
Inspired by Microsoft Word 2000, built with tkinter.Text and rich tags.
Optimised for 32-bit retro systems with 512 MB RAM.
"""

import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, colorchooser

# ----------------------------------------------------------------------
# Colour and font constants (platinum / Office 2000 style)
# ----------------------------------------------------------------------
BG_MAIN = "#ececec"
BG_TOOLBAR = "#d4d0c8"
FG_DARK = "#000000"
PAGE_BG = "#ffffff"
ACCENT = "#7f7f7f"
FONT_UI = ("Lucida Grande", 10)
FONT_BUTTON = ("Lucida Grande", 10, "bold")

# Font families available (classic choices)
FONT_FAMILIES = ["Arial", "Times New Roman", "Courier"]
FONT_SIZES = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24]


# ----------------------------------------------------------------------
# Main Application
# ----------------------------------------------------------------------
class ArrelWord(tk.Tk):
    def __init__(self):
        super().__init__()

        # Window setup
        self.title("ArrelWord - Untitled")
        self.geometry("800x600")
        self.minsize(640, 480)
        self.configure(bg=BG_MAIN)

        # File variables
        self.current_file = None
        self.modified = False

        # Create the rich text editor widget
        self.text = tk.Text(
            self,
            wrap=tk.WORD,
            undo=False,                     # light memory footprint
            maxundo=0,
            font=("Arial", 12),
            bg=PAGE_BG,
            fg=FG_DARK,
            insertbackground=FG_DARK,
            selectbackground="#c0d2e0",
            relief=tk.FLAT,
            borderwidth=1,
            highlightthickness=0,
            padx=10,
            pady=10,
        )
        self.text.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))

        # Scrollbar
        self.scrollbar = ttk.Scrollbar(self, command=self.text.yview)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 5), pady=(0, 10))
        self.text.configure(yscrollcommand=self.scrollbar.set)

        # Define formatting tags
        self._init_tags()

        # Build the toolbars
        self._build_standard_toolbar()
        self._build_formatting_toolbar()

        # State variables for toggle buttons
        self.bold_active = False
        self.italic_active = False
        self.underline_active = False
        self.strikethrough_active = False
        self.align_var = tk.StringVar(value="left")  # left, center, right

        # Bind events for dynamic button state tracking
        self.text.bind("<<Selection>>", self._update_button_states)
        self.text.bind("<KeyRelease>", self._on_text_change)  # track unsaved changes
        self.text.bind("<ButtonRelease-1>", self._update_button_states)

        # Initial button state update
        self._update_button_states()

        # Status bar at bottom
        self.status_var = tk.StringVar(value="Ready")
        status_bar = tk.Label(self, textvariable=self.status_var,
                              anchor=tk.W, bg=BG_MAIN, font=("Lucida Grande", 9))
        status_bar.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=2)

        # Protocol for window close
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------------------------------------------------
    # Tag initialisation (all formatting styles)
    # ------------------------------------------------------------------
    def _init_tags(self):
        # Family tags
        for fam in FONT_FAMILIES:
            self.text.tag_configure(f"family_{fam.lower().replace(' ', '_')}",
                                    font=(fam, 12))
        # Size tags
        for size in FONT_SIZES:
            self.text.tag_configure(f"size_{size}", font=("Arial", size))
        # Style tags
        self.text.tag_configure("bold", font=("Arial", 12, "bold"))
        self.text.tag_configure("italic", font=("Arial", 12, "italic"))
        self.text.tag_configure("underline", underline=True)
        self.text.tag_configure("strikethrough", overstrike=True)
        # Colour tags (created on the fly)
        # Alignment tags
        self.text.tag_configure("align_left", justify=tk.LEFT)
        self.text.tag_configure("align_center", justify=tk.CENTER)
        self.text.tag_configure("align_right", justify=tk.RIGHT)

    # ------------------------------------------------------------------
    # Toolbars construction
    # ------------------------------------------------------------------
    def _build_standard_toolbar(self):
        """Standard toolbar: New, Open, Save, Print Preview, Cut, Copy, Paste."""
        toolbar = tk.Frame(self, bg=BG_TOOLBAR, relief=tk.RAISED, borderwidth=1)
        toolbar.pack(side=tk.TOP, fill=tk.X)

        buttons = [
            ("Nou", self.new_document),
            ("Obrir", self.open_document),
            ("Desar", self.save_document),
            ("Imprimir", self.print_preview),
            ("Retallar", self.cut_text),
            ("Copiar", self.copy_text),
            ("Enganxar", self.paste_text),
        ]
        for text, cmd in buttons:
            btn = tk.Button(toolbar, text=text, font=FONT_UI, bg=BG_TOOLBAR,
                            relief=tk.RAISED, padx=5, pady=1, command=cmd)
            btn.pack(side=tk.LEFT, padx=1, pady=2)

    def _build_formatting_toolbar(self):
        """Formatting toolbar: font, size, style toggles, alignment, colour."""
        toolbar = tk.Frame(self, bg=BG_TOOLBAR, relief=tk.RAISED, borderwidth=1)
        toolbar.pack(side=tk.TOP, fill=tk.X, pady=(0, 2))

        # Font family dropdown
        tk.Label(toolbar, text="Font:", bg=BG_TOOLBAR, font=FONT_UI).pack(side=tk.LEFT, padx=(5, 0))
        self.font_var = tk.StringVar(value=FONT_FAMILIES[0])
        font_combo = ttk.Combobox(toolbar, textvariable=self.font_var,
                                  values=FONT_FAMILIES, state="readonly",
                                  width=14, font=FONT_UI)
        font_combo.pack(side=tk.LEFT, padx=2)
        font_combo.bind("<<ComboboxSelected>>", self._on_font_change)

        # Font size dropdown
        tk.Label(toolbar, text="Size:", bg=BG_TOOLBAR, font=FONT_UI).pack(side=tk.LEFT, padx=(8, 0))
        self.size_var = tk.IntVar(value=12)
        size_combo = ttk.Combobox(toolbar, textvariable=self.size_var,
                                  values=FONT_SIZES, state="readonly",
                                  width=4, font=FONT_UI)
        size_combo.pack(side=tk.LEFT, padx=2)
        size_combo.bind("<<ComboboxSelected>>", self._on_size_change)

        # Style toggle buttons (Bold, Italic, Underline, Strikethrough)
        style_btns = [
            ("B", self.toggle_bold, "bold"),
            ("I", self.toggle_italic, "italic"),
            ("U", self.toggle_underline, "underline"),
            ("S", self.toggle_strikethrough, "strikethrough"),
        ]
        for text, cmd, _ in style_btns:
            btn = tk.Button(toolbar, text=text, font=("Lucida Grande", 10, "bold"),
                            width=3, bg=BG_TOOLBAR, relief=tk.RAISED,
                            command=cmd)
            btn.pack(side=tk.LEFT, padx=1, pady=1)
            setattr(self, f"btn_{text.lower()}", btn)  # store reference for later toggling

        # Separator
        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6, pady=2)

        # Alignment buttons (left, center, right)
        align_btns = [
            ("L", "left", self.align_left),
            ("C", "center", self.align_center),
            ("R", "right", self.align_right),
        ]
        for text, align, cmd in align_btns:
            btn = tk.Button(toolbar, text=text, font=("Lucida Grande", 10, "bold"),
                            width=2, bg=BG_TOOLBAR, relief=tk.RAISED,
                            command=cmd)
            btn.pack(side=tk.LEFT, padx=1, pady=1)
            setattr(self, f"btn_align_{align}", btn)

        # Separator
        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6, pady=2)

        # Text colour button
        self.color_btn = tk.Button(toolbar, text="🎨", font=FONT_UI, bg=BG_TOOLBAR,
                                   relief=tk.RAISED, padx=3, command=self.choose_color)
        self.color_btn.pack(side=tk.LEFT, padx=1, pady=1)

    # ------------------------------------------------------------------
    # Formatting application logic
    # ------------------------------------------------------------------
    def _apply_tag_to_selection(self, tag, remove_others=None, exclusive_family=None):
        """Apply a tag to selected text, optionally removing conflicting tags."""
        try:
            sel = self.text.tag_ranges(tk.SEL)
            if not sel:
                return
            start, end = sel
            # Remove conflicting tags if specified
            if remove_others:
                for otag in remove_others:
                    self.text.tag_remove(otag, start, end)
            # For exclusive families (like font families), remove all other family tags
            if exclusive_family:
                for fam in exclusive_family:
                    self.text.tag_remove(f"family_{fam.lower().replace(' ', '_')}", start, end)
            # Apply the tag
            self.text.tag_add(tag, start, end)
            self.modified = True
        except tk.TclError:
            pass  # no selection

    def _on_font_change(self, event=None):
        """Apply selected font family to current selection."""
        fam = self.font_var.get()
        tag = f"family_{fam.lower().replace(' ', '_')}"
        self._apply_tag_to_selection(tag, exclusive_family=FONT_FAMILIES)

    def _on_size_change(self, event=None):
        """Apply selected font size to current selection."""
        size = self.size_var.get()
        tag = f"size_{size}"
        # Remove other size tags from selection
        all_size_tags = [f"size_{s}" for s in FONT_SIZES]
        self._apply_tag_to_selection(tag, remove_others=all_size_tags)

    def toggle_bold(self):
        """Toggle bold on current selection (or cursor insertion point)."""
        self._toggle_style_tag("bold", self.bold_active)
        self.bold_active = not self.bold_active

    def toggle_italic(self):
        self._toggle_style_tag("italic", self.italic_active)
        self.italic_active = not self.italic_active

    def toggle_underline(self):
        self._toggle_style_tag("underline", self.underline_active)
        self.underline_active = not self.underline_active

    def toggle_strikethrough(self):
        self._toggle_style_tag("strikethrough", self.strikethrough_active)
        self.strikethrough_active = not self.strikethrough_active

    def _toggle_style_tag(self, tag, current_active):
        """Add or remove a style tag to selection."""
        try:
            sel = self.text.tag_ranges(tk.SEL)
            if not sel:
                return
            start, end = sel
            if current_active:
                self.text.tag_remove(tag, start, end)
            else:
                self.text.tag_add(tag, start, end)
            self.modified = True
            self._update_button_states()
        except tk.TclError:
            pass

    def align_left(self):
        self._apply_alignment("left")

    def align_center(self):
        self._apply_alignment("center")

    def align_right(self):
        self._apply_alignment("right")

    def _apply_alignment(self, align):
        """Apply alignment to the whole line(s) of current selection."""
        try:
            sel = self.text.tag_ranges(tk.SEL)
            if not sel:
                # If no selection, act on the line containing the cursor
                cursor = self.text.index(tk.INSERT)
                line_start = f"{cursor.split('.')[0]}.0"
                line_end = f"{cursor.split('.')[0]}.end"
                sel = (line_start, line_end)
            start, end = sel
            # Remove any existing alignment tags in this range
            for a_tag in ("align_left", "align_center", "align_right"):
                self.text.tag_remove(a_tag, start, end)
            # Apply selected alignment
            self.text.tag_add(f"align_{align}", start, end)
            self.align_var.set(align)
            self.modified = True
            self._update_alignment_buttons(align)
        except tk.TclError:
            pass

    def choose_color(self):
        """Open colour picker and apply selected colour to selection."""
        color = colorchooser.askcolor(title="Choose Text Colour")
        if color and color[1]:
            hex_color = color[1]
            # Create a unique tag for this colour if not exists
            tag_name = f"color_{hex_color.replace('#', '')}"
            if tag_name not in self.text.tag_names():
                self.text.tag_configure(tag_name, foreground=hex_color)
            # Apply to selection, remove other colour tags first
            try:
                sel = self.text.tag_ranges(tk.SEL)
                if sel:
                    start, end = sel
                    # Remove any existing colour tags
                    for t in self.text.tag_names():
                        if t.startswith("color_"):
                            self.text.tag_remove(t, start, end)
                    self.text.tag_add(tag_name, start, end)
                    self.modified = True
            except tk.TclError:
                pass

    # ------------------------------------------------------------------
    # Button state synchronisation based on cursor position
    # ------------------------------------------------------------------
    def _update_button_states(self, event=None):
        """Read current formatting tags at cursor position and update toolbar toggles."""
        try:
            cursor = self.text.index(tk.INSERT)
            tags = self.text.tag_names(cursor)

            # Style toggles
            bold = "bold" in tags
            italic = "italic" in tags
            underline = "underline" in tags
            strikethrough = "strikethrough" in tags

            self._set_toggle_button(self.btn_b, bold)
            self.bold_active = bold

            self._set_toggle_button(self.btn_i, italic)
            self.italic_active = italic

            self._set_toggle_button(self.btn_u, underline)
            self.underline_active = underline

            self._set_toggle_button(self.btn_s, strikethrough)
            self.strikethrough_active = strikethrough

            # Alignment detection (from tags)
            align = "left"
            if "align_center" in tags:
                align = "center"
            elif "align_right" in tags:
                align = "right"
            self._update_alignment_buttons(align)

            # Font family / size detection
            # Look for family and size tags; if none, use default
            fam_tag = None
            for fam in FONT_FAMILIES:
                tag_cand = f"family_{fam.lower().replace(' ', '_')}"
                if tag_cand in tags:
                    fam_tag = tag_cand
                    break
            if fam_tag:
                # Extract display name
                self.font_var.set(fam.replace('_', ' ').title())
            else:
                self.font_var.set(FONT_FAMILIES[0])

            size_tag = None
            for s in FONT_SIZES:
                tag_cand = f"size_{s}"
                if tag_cand in tags:
                    size_tag = tag_cand
                    break
            if size_tag:
                self.size_var.set(int(size_tag.split('_')[1]))
            else:
                self.size_var.set(12)

        except tk.TclError:
            pass

    def _set_toggle_button(self, btn, active):
        """Set a button's relief based on active state."""
        btn.configure(relief=tk.SUNKEN if active else tk.RAISED)

    def _update_alignment_buttons(self, active_align):
        """Set the three alignment buttons reliefs."""
        for align in ("left", "center", "right"):
            btn = getattr(self, f"btn_align_{align}")
            btn.configure(relief=tk.SUNKEN if align == active_align else tk.RAISED)

    def _on_text_change(self, event=None):
        """Mark document modified (for unsaved changes tracking)."""
        self.modified = True
        self.status_var.set("Modified")

    # ------------------------------------------------------------------
    # File operations: New, Open, Save
    # ------------------------------------------------------------------
    def new_document(self):
        """Create a new blank document after confirming unsaved changes."""
        if self.modified:
            if not messagebox.askyesno("Unsaved Changes",
                                       "Do you want to save the current document?"):
                pass
            else:
                self.save_document()
        self.text.delete("1.0", tk.END)
        self.current_file = None
        self.modified = False
        self.title("ArrelWord - Untitled")
        self.status_var.set("New document")

    def open_document(self):
        """Open an existing .arw or .txt file."""
        filename = filedialog.askopenfilename(
            title="Open Document",
            filetypes=[("ArrelWord files", "*.arw"), ("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not filename:
            return
        try:
            with open(filename, "r", encoding="utf-8") as f:
                # Check extension to decide method
                if filename.lower().endswith(".arw"):
                    # ArrelWord format: dump() style content
                    self.text.delete("1.0", tk.END)
                    # The dump format uses 'tcl' representation.
                    # We'll use load() if content is a valid dump output.
                    content = f.read()
                    # Reconstruct Tcl list from file string; dump() output can be loaded directly.
                    # For simplicity, we'll write the entire string as a Tcl command.
                    # Safer: use text.load() with a temporary file?
                    # We'll trust that dump output works if we call text.delete + text.insert with raw? No.
                    # Better approach: write the dump output to a temp string and use text.load with a list.
                    # We'll parse the file line by line as Tcl eval isn't trivial in Python.
                    # Instead, we'll store a simpler representation: we'll use text.dump() which returns a list.
                    # In Python, we can eval the content as a list literal? Dangerous.
                    # Simpler: use pickle of the dump list? Overkill.
                    # We'll adopt a robust method: dump() returns a list of tuples (action, position, tag/value).
                    # We'll store that as JSON? Not pure tkinter.
                    # Considering the requirement is production-ready, we'll implement save/load using the built-in
                    # tkinter Text serialisation via .dump() and .load(). However .load() requires a valid list of tuples.
                    # We can save that list as repr() and then load by eval() – unsafe but okay for a personal OS.
                    # To avoid eval, we can use a simple custom format: save as .txt with tags encoded? Too complex.
                    # Let's use a safe method: save as .arw by writing the repr of the dump list, and load by:
                    # reading file, then using ast.literal_eval() to convert back to list, then text.load().
                    # That is safe and standard.
                    import ast
                    try:
                        dump_list = ast.literal_eval(content)
                        self.text.delete("1.0", tk.END)
                        self.text.load(dump_list)
                    except (SyntaxError, ValueError, tk.TclError):
                        messagebox.showerror("Error", "Invalid .arw file format.")
                        return
                else:
                    # Plain text file
                    self.text.delete("1.0", tk.END)
                    self.text.insert("1.0", f.read())
            self.current_file = filename
            self.modified = False
            self.title(f"ArrelWord - {os.path.basename(filename)}")
            self.status_var.set("Document opened")
        except Exception as e:
            messagebox.showerror("Open Error", f"Could not open file:\n{e}")

    def save_document(self):
        """Save document in .arw format (preserves formatting) or .txt if plain."""
        if self.current_file:
            filename = self.current_file
        else:
            filename = filedialog.asksaveasfilename(
                title="Save Document",
                defaultextension=".arw",
                filetypes=[("ArrelWord files", "*.arw"), ("Text files", "*.txt"), ("All files", "*.*")]
            )
            if not filename:
                return

        try:
            if filename.lower().endswith(".arw"):
                # Save formatted dump
                dump_data = repr(self.text.dump("1.0", tk.END))
                with open(filename, "w", encoding="utf-8") as f:
                    f.write(dump_data)
            else:
                # Save as plain text
                content = self.text.get("1.0", "end-1c")  # exclude trailing newline
                with open(filename, "w", encoding="utf-8") as f:
                    f.write(content)

            self.current_file = filename
            self.modified = False
            self.title(f"ArrelWord - {os.path.basename(filename)}")
            self.status_var.set("Document saved")
        except Exception as e:
            messagebox.showerror("Save Error", f"Could not save file:\n{e}")

    # ------------------------------------------------------------------
    # Clipboard operations
    # ------------------------------------------------------------------
    def cut_text(self):
        self.text.event_generate("<<Cut>>")
        self.modified = True

    def copy_text(self):
        self.text.event_generate("<<Copy>>")

    def paste_text(self):
        self.text.event_generate("<<Paste>>")
        self.modified = True

    # ------------------------------------------------------------------
    # Print Preview (simulated page)
    # ------------------------------------------------------------------
    def print_preview(self):
        """Open a separate window showing a read-only page with current document."""
        preview_win = tk.Toplevel(self)
        preview_win.title("Print Preview - ArrelWord")
        preview_win.geometry("640x800")  # vertical page
        preview_win.configure(bg=BG_MAIN)

        # Canvas to simulate paper shadow
        canvas = tk.Canvas(preview_win, bg=BG_MAIN, highlightthickness=0)
        canvas.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        # Draw a white page rectangle
        canvas.create_rectangle(20, 20, 600, 760, fill=PAGE_BG, outline="#ccc", width=2)

        # Place a read-only text widget over the white rectangle
        preview_text = tk.Text(
            canvas,
            wrap=tk.WORD,
            font=("Arial", 12),
            bg=PAGE_BG,
            relief=tk.FLAT,
            borderwidth=0,
            padx=15,
            pady=15,
            state=tk.NORMAL,
        )
        # Copy current content with formatting using dump/load
        try:
            dump_data = self.text.dump("1.0", tk.END)
            preview_text.load(dump_data)
        except tk.TclError:
            # Fallback: just copy plain text
            preview_text.insert("1.0", self.text.get("1.0", "end-1c"))
        preview_text.configure(state=tk.DISABLED)

        # Place the text widget inside the canvas as a window object
        canvas.create_window(30, 30, anchor=tk.NW, window=preview_text)

        # Close button
        close_btn = tk.Button(preview_win, text="Close Preview", command=preview_win.destroy)
        close_btn.pack(pady=5)

    # ------------------------------------------------------------------
    # Clean shutdown
    # ------------------------------------------------------------------
    def _on_close(self):
        if self.modified:
            if messagebox.askyesno("Unsaved Changes",
                                   "You have unsaved changes. Save before closing?"):
                self.save_document()
        self.destroy()


# ----------------------------------------------------------------------
# Start the word processor
# ----------------------------------------------------------------------
if __name__ == "__main__":
    app = ArrelWord()
    app.mainloop()