#!/usr/bin/env python3
"""
ArrelShell.py – Terminal retro completa d'ArrelOS
Implementa totes les comandes de fitxers, sistema, processos, xarxa, Wi‑Fi,
execució, maquinari i ajuda.  Entorn visual tipus matrix (verd sobre negre).
Requereix Linux, python3, psutil, iwl nmcli per a les ordres de xarxa/Wi‑Fi.
"""

import os
import sys
import shutil
import subprocess
import datetime
import shlex
import threading
import time
import platform
import getpass
import signal
import re
import tkinter as tk
from tkinter import scrolledtext

# ----------------------------------------------------------------------
# Intents d'importar mòduls opcionals
# ----------------------------------------------------------------------
try:
    import psutil
    PSUTIL = True
except ImportError:
    PSUTIL = False

# ----------------------------------------------------------------------
# Constants del terminal
# ----------------------------------------------------------------------
BG = "black"
FG = "#00ff00"
FONT = ("Courier New", 11)
BLOCKED_TOKENS = {"sudo", "chmod", "chown", "apt-get", "apt", "pacman", "rm", "dd",
                  "mkfs", "fdisk", "parted", "reboot", "shutdown"}
BLOCKED_PATTERNS = ["rm -rf /", "rm -rf /*", "chmod 777", "> /dev/sda"]

# ----------------------------------------------------------------------
# Classe principal del terminal
# ----------------------------------------------------------------------
class ArrelShell(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ArrelOS Terminal")
        self.geometry("800x550")
        self.minsize(600, 400)
        self.configure(bg=BG)

        # Estat
        self.cwd = os.path.expanduser("~")
        os.chdir(self.cwd)
        self.username = getpass.getuser()
        self.os_name = f"ArrelOS v1.0 ({platform.machine()})"

        # Construcció de la interfície
        self.term = tk.Text(self, bg=BG, fg=FG, insertbackground=FG, font=FONT,
                            wrap=tk.WORD, undo=False, maxundo=0,
                            relief=tk.FLAT, borderwidth=0, highlightthickness=0,
                            padx=10, pady=10)
        scroll = tk.Scrollbar(self, command=self.term.yview)
        self.term.configure(yscrollcommand=scroll.set)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.term.pack(fill=tk.BOTH, expand=True)

        # Restriccions d'entrada
        self.term.bind("<Key>", self._key)
        self.term.bind("<Return>", self._enter)
        self.term.bind("<BackSpace>", self._backspace)
        self.term.bind("<Left>", self._left)
        self.term.bind("<Home>", self._left)
        self.term.bind("<Button-1>", self._click)
        self.term.bind("<Control-v>", self._paste)

        # Banderí inicial i primer prompt
        self._insert("ArrelOS Shell v1.0 – Guia completa de la terminal\n")
        self._insert("Escriviu 'help' o '?' per veure la llista de comandes.\n")
        self._new_prompt()
        self.term.focus_set()

    # ------------------------------------------------------------------
    # Gestió de sortida i prompt
    # ------------------------------------------------------------------
    def _insert(self, text):
        self.term.insert("end-1c", text)
        self.term.see("end-1c")

    def _new_prompt(self):
        prompt = f"\nArrelOS:{self.cwd}> "
        self.term.insert(tk.END, prompt)
        self.term.mark_set("input_start", "end-1c")
        self.term.mark_set(tk.INSERT, tk.END)
        self.term.see(tk.END)

    def _get_input(self):
        start = self.term.index("input_start")
        end = self.term.index("end-1c")
        return self.term.get(start, end).strip()

    # ------------------------------------------------------------------
    # Restriccions de teclat
    # ------------------------------------------------------------------
    def _key(self, event):
        if not event.char:
            return
        if self.term.compare(tk.INSERT, "<", "input_start"):
            self.term.mark_set(tk.INSERT, tk.END)
            self.term.insert(tk.INSERT, event.char)
            return "break"
        return None

    def _backspace(self, event):
        if self.term.compare(tk.INSERT, "<=", "input_start"):
            return "break"
        return None

    def _left(self, event):
        if self.term.compare("insert-1c", "<", "input_start"):
            return "break"
        return None

    def _click(self, event):
        self.term.mark_set(tk.INSERT, tk.END)
        return "break"

    def _paste(self, event):
        if self.term.compare(tk.INSERT, "<", "input_start"):
            self.term.mark_set(tk.INSERT, tk.END)
        return None

    # ------------------------------------------------------------------
    # Enter: processar línia
    # ------------------------------------------------------------------
    def _enter(self, event):
        raw = self._get_input()
        self.term.insert(tk.END, "\n")
        self.term.see(tk.END)
        if raw:
            self._execute(raw)
        self._new_prompt()
        return "break"

    # ------------------------------------------------------------------
    # Dispatcher central
    # ------------------------------------------------------------------
    def _execute(self, raw):
        # Verificacions de seguretat
        if any(p in raw.lower() for p in BLOCKED_PATTERNS):
            self._insert("Error de Sintaxi: Comanda bloquejada per la directiva de seguretat d'ArrelOS.\n")
            return
        try:
            tokens = shlex.split(raw)
        except ValueError as e:
            self._insert(f"Error de sintaxi: {e}\n")
            return
        if not tokens:
            return
        cmd = tokens[0].lower()
        args = tokens[1:]

        if cmd in BLOCKED_TOKENS:
            self._insert("Error de Sintaxi: Comanda bloquejada per la directiva de seguretat d'ArrelOS.\n")
            return

        # Taula de comandes
        try:
            if cmd in ("dir", "ls"):
                self._dir(args)
            elif cmd == "cd":
                self._cd(args)
            elif cmd == "pwd":
                self._insert(self.cwd + "\n")
            elif cmd == "mkdir":
                self._mkdir(args)
            elif cmd == "rmdir":
                self._rmdir(args)
            elif cmd in ("del", "rm"):
                self._del(args)
            elif cmd == "copy":
                self._copy(args)
            elif cmd == "move":
                self._move(args)
            elif cmd in ("type", "cat"):
                self._type(args)
            elif cmd == "echo":
                self._echo(args)
            elif cmd == "date":
                self._insert(datetime.datetime.now().strftime("%d/%m/%Y") + "\n")
            elif cmd == "time":
                self._insert(datetime.datetime.now().strftime("%H:%M:%S") + "\n")
            elif cmd == "sysinfo":
                self._sysinfo(args)
            elif cmd in ("clear", "cls"):
                self._clear()
            elif cmd == "tasklist":
                self._tasklist()
            elif cmd == "taskkill":
                self._taskkill(args)
            elif cmd == "ping":
                self._ping(args)
            elif cmd in ("ifconfig", "ip"):
                self._ifconfig(args)
            elif cmd == "curl":
                self._curl(args)
            elif cmd == "wget":
                self._wget(args)
            elif cmd == "nslookup":
                self._nslookup(args)
            elif cmd == "wifi":
                self._wifi(args)
            elif cmd == "execute":
                self._execute_program(args)
            elif cmd == "info":
                self._info_program(args)
            elif cmd == "check":
                self._check_program(args)
            elif cmd == "ram":
                self._ram()
            elif cmd == "cpu":
                self._cpu()
            elif cmd == "reboot":
                self._reboot()
            elif cmd == "poweroff":
                self._poweroff()
            elif cmd in ("help", "?"):
                self._help()
            elif cmd == "exit":
                self.destroy()
            else:
                self._insert(f"Comanda desconeguda: {cmd}. Escriviu 'help' per ajuda.\n")
        except Exception as e:
            self._insert(f"Error intern: {e}\n")

    # ------------------------------------------------------------------
    # Fitxers i directoris
    # ------------------------------------------------------------------
    def _dir(self, args):
        path = self.cwd
        show_hidden = False
        show_sizes = False
        for a in args:
            if a == "/h":
                show_hidden = True
            elif a == "/s":
                show_sizes = True
            elif not a.startswith("/"):
                path = os.path.join(self.cwd, a)
        try:
            with os.scandir(path) as it:
                for entry in sorted(it, key=lambda e: e.name.lower()):
                    if not show_hidden and entry.name.startswith("."):
                        continue
                    suffix = "/" if entry.is_dir() else ""
                    size_str = ""
                    if show_sizes and not entry.is_dir():
                        try:
                            sz = entry.stat().st_size
                            size_str = f" [{self._fmt(sz)}]"
                        except:
                            size_str = " [???]"
                    self._insert(f"  {entry.name}{suffix}{size_str}\n")
        except Exception as e:
            self._insert(f"Error: {e}\n")

    def _fmt(self, size):
        for u in ['B','KB','MB','GB']:
            if size < 1024:
                return f"{size:.1f}{u}"
            size /= 1024
        return f"{size:.1f}TB"

    def _cd(self, args):
        if not args:
            target = os.path.expanduser("~")
        else:
            target = args[0]
        if target == "~":
            target = os.path.expanduser("~")
        elif not os.path.isabs(target):
            target = os.path.join(self.cwd, target)
        target = os.path.normpath(target)
        try:
            os.chdir(target)
            self.cwd = os.getcwd()
        except Exception as e:
            self._insert(f"Error: {e}\n")

    def _mkdir(self, args):
        if not args:
            self._insert("Ús: mkdir <directori>\n")
            return
        path = os.path.join(self.cwd, args[0])
        try:
            os.mkdir(path)
            self._insert(f"Creat: {args[0]}\n")
        except Exception as e:
            self._insert(f"Error: {e}\n")

    def _rmdir(self, args):
        if not args:
            self._insert("Ús: rmdir <directori>\n")
            return
        path = os.path.join(self.cwd, args[0])
        try:
            os.rmdir(path)
            self._insert(f"Eliminat: {args[0]}\n")
        except Exception as e:
            self._insert(f"Error: {e}\n")

    def _del(self, args):
        force = False
        files = []
        for a in args:
            if a == "-f":
                force = True
            else:
                files.append(a)
        if not files:
            self._insert("Ús: del [-f] <fitxer...>\n")
            return
        for f in files:
            path = os.path.join(self.cwd, f)
            try:
                os.remove(path)
                self._insert(f"Eliminat: {f}\n")
            except Exception as e:
                self._insert(f"Error eliminant {f}: {e}\n")

    def _copy(self, args):
        if len(args) != 2:
            self._insert("Ús: copy <origen> <destí>\n")
            return
        src = os.path.join(self.cwd, args[0])
        dst = os.path.join(self.cwd, args[1])
        try:
            shutil.copy2(src, dst)
            self._insert(f"Copiat {args[0]} -> {args[1]}\n")
        except Exception as e:
            self._insert(f"Error: {e}\n")

    def _move(self, args):
        if len(args) != 2:
            self._insert("Ús: move <origen> <destí>\n")
            return
        src = os.path.join(self.cwd, args[0])
        dst = os.path.join(self.cwd, args[1])
        try:
            shutil.move(src, dst)
            self._insert(f"Mogut {args[0]} -> {args[1]}\n")
        except Exception as e:
            self._insert(f"Error: {e}\n")

    def _type(self, args):
        if not args:
            self._insert("Ús: type <fitxer>\n")
            return
        path = os.path.join(self.cwd, args[0])
        try:
            with open(path, "r") as f:
                self._insert(f.read())
        except Exception as e:
            self._insert(f"Error: {e}\n")

    # ------------------------------------------------------------------
    # Sistema
    # ------------------------------------------------------------------
    def _echo(self, args):
        text = " ".join(args)
        text = text.replace("%username%", self.username)
        text = text.replace("%os%", self.os_name)
        text = text.replace("%path%", self.cwd)
        self._insert(text + "\n")

    def _sysinfo(self, args):
        verbose = "/v" in args
        self._insert(f"Sistema: {self.os_name}\n")
        self._insert(f"Arquitectura: {platform.machine()}\n")
        if PSUTIL:
            mem = psutil.virtual_memory()
            self._insert(f"RAM total: {mem.total//(1024**2)} MB\n")
            self._insert(f"RAM lliure: {mem.available//(1024**2)} MB\n")
            if verbose:
                procs = len(list(psutil.process_iter()))
                self._insert(f"Processos actius: {procs}\n")
                disk = shutil.disk_usage("/")
                self._insert(f"Disc '/': {disk.free//(1024**2)} MB lliure de {disk.total//(1024**2)} MB\n")
                self._insert(f"Usuari: {self.username}\n")
        else:
            self._insert("(psutil no instal·lat)\n")

    def _clear(self):
        self.term.delete("1.0", tk.END)

    # ------------------------------------------------------------------
    # Processos
    # ------------------------------------------------------------------
    def _tasklist(self):
        if not PSUTIL:
            self._insert("psutil no instal·lat.\n")
            return
        self._insert(f"{'PID':>8} {'Nom':<25} {'RAM (MB)':>10}\n")
        self._insert("-"*48 + "\n")
        for p in psutil.process_iter(['pid','name','memory_info']):
            try:
                pid = p.info['pid']
                name = p.info['name'] or "?"
                rss = p.info['memory_info'].rss / (1024*1024) if p.info['memory_info'] else 0
                self._insert(f"{pid:>8} {name:<25} {rss:>9.1f}\n")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

    def _taskkill(self, args):
        if not PSUTIL:
            self._insert("psutil no instal·lat.\n")
            return
        pid = None
        im = None
        i = 0
        while i < len(args):
            if args[i] == "/pid" and i+1 < len(args):
                try:
                    pid = int(args[i+1])
                except:
                    self._insert("PID invàlid.\n")
                    return
                i += 2
            elif args[i] == "/im" and i+1 < len(args):
                im = args[i+1]
                i += 2
            else:
                i += 1
        if not pid and not im:
            self._insert("Ús: taskkill /pid <id> | /im <nom>\n")
            return
        critical = {"systemd","init","xorg","xfce4-session","python","python3",
                    "sshd","dbus-daemon","polkitd","xfdesktop","xfwm4"}
        try:
            if pid:
                proc = psutil.Process(pid)
                name = proc.name()
            else:
                found = False
                for p in psutil.process_iter(['pid','name']):
                    if p.info['name'] and p.info['name'].lower() == im.lower():
                        pid = p.info['pid']
                        name = p.info['name']
                        found = True
                        break
                if not found:
                    self._insert(f"No s'ha trobat procés '{im}'.\n")
                    return
                proc = psutil.Process(pid)
            if name.lower() in critical:
                self._insert(f"Accés denegat: '{name}' és un procés protegit.\n")
                return
            proc.terminate()
            self._insert(f"Procés {name} (PID {pid}) finalitzat.\n")
        except Exception as e:
            self._insert(f"Error: {e}\n")

    # ------------------------------------------------------------------
    # Xarxa
    # ------------------------------------------------------------------
    def _ping(self, args):
        if not args:
            self._insert("Ús: ping <host> [-c <comptador>]\n")
            return
        host = args[0]
        count = "4"
        if "-c" in args:
            idx = args.index("-c")
            if idx+1 < len(args):
                count = args[idx+1]
        try:
            subprocess.run(["ping", "-c", count, host], check=False, timeout=10,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            self._insert("Ping completat.\n")
        except Exception as e:
            self._insert(f"Error: {e}\n")

    def _ifconfig(self, args):
        try:
            out = subprocess.check_output(["ip", "a"], text=True, timeout=5)
            self._insert(out)
        except:
            try:
                out = subprocess.check_output(["ifconfig"], text=True, timeout=5)
                self._insert(out)
            except Exception as e:
                self._insert(f"No s'ha pogut obtenir info de xarxa: {e}\n")

    def _curl(self, args):
        if not args:
            self._insert("Ús: curl <URL> [-o fitxer]\n")
            return
        url = args[0]
        output = None
        if "-o" in args:
            idx = args.index("-o")
            if idx+1 < len(args):
                output = args[idx+1]
        cmd = ["curl", "-s", url]
        if output:
            cmd += ["-o", output]
        try:
            subprocess.run(cmd, check=False, timeout=15)
            self._insert("curl completat.\n")
        except Exception as e:
            self._insert(f"Error: {e}\n")

    def _wget(self, args):
        if not args:
            self._insert("Ús: wget <URL> [-O nom]\n")
            return
        url = args[0]
        output = None
        if "-O" in args:
            idx = args.index("-O")
            if idx+1 < len(args):
                output = args[idx+1]
        cmd = ["wget", url]
        if output:
            cmd += ["-O", output]
        try:
            subprocess.run(cmd, check=False, timeout=30)
            self._insert("wget completat.\n")
        except Exception as e:
            self._insert(f"Error: {e}\n")

    def _nslookup(self, args):
        if not args:
            self._insert("Ús: nslookup <domini>\n")
            return
        domain = args[0]
        try:
            out = subprocess.check_output(["nslookup", domain], text=True, timeout=5)
            self._insert(out)
        except:
            self._insert("nslookup no disponible.\n")

    # ------------------------------------------------------------------
    # Wi-Fi (mitjançant nmcli)
    # ------------------------------------------------------------------
    def _wifi(self, args):
        if not args:
            self._insert("Ús: wifi <list|connect|disconnect|show|config|edit>\n")
            return
        subcmd = args[0].lower()
        if subcmd == "list":
            try:
                out = subprocess.check_output(["nmcli", "-t", "-f", "SSID,BSSID,SIGNAL,SECURITY,CHAN", "dev", "wifi", "list"],
                                            text=True, timeout=10)
                self._insert(out)
            except Exception as e:
                self._insert(f"Error llistant Wi‑Fi: {e}\n")
        elif subcmd == "connect":
            # Parse args: wifi connect ssid="nom" password="clau" [--hidden]
            kwargs = {"hidden": False}
            i = 1
            while i < len(args):
                if args[i].startswith("ssid="):
                    kwargs["ssid"] = args[i][5:].strip('"')
                elif args[i].startswith("password="):
                    kwargs["password"] = args[i][9:].strip('"')
                elif args[i] == "--hidden":
                    kwargs["hidden"] = True
                i += 1
            if "ssid" not in kwargs or "password" not in kwargs:
                self._insert("Ús: wifi connect ssid=\"nom\" password=\"clau\" [--hidden]\n")
                return
            cmd = ["nmcli", "dev", "wifi", "connect", kwargs["ssid"], "password", kwargs["password"]]
            if kwargs["hidden"]:
                cmd.append("hidden")
                cmd.append("yes")
            try:
                subprocess.run(cmd, check=True, timeout=15)
                self._insert(f"Connectat a {kwargs['ssid']}.\n")
            except subprocess.CalledProcessError:
                self._insert("Error de connexió Wi‑Fi. Reviseu la contrasenya.\n")
            except Exception as e:
                self._insert(f"Error: {e}\n")
        elif subcmd == "disconnect":
            try:
                subprocess.run(["nmcli", "dev", "disconnect", "wlan0"], check=True, timeout=5)
                self._insert("Desconnectat de la xarxa Wi‑Fi.\n")
            except:
                self._insert("Error en desconnectar.\n")
        elif subcmd == "show":
            try:
                out = subprocess.check_output(["nmcli", "-t", "-f", "GENERAL,IP4", "dev", "show", "wlan0"],
                                            text=True, timeout=5)
                self._insert(out)
            except:
                self._insert("No s'ha pogut obtenir l'estat Wi‑Fi.\n")
        elif subcmd == "config":
            self._insert("Funció 'config' no implementada encara.\n")
        elif subcmd == "edit":
            if len(args) < 2:
                self._insert("Ús: wifi edit <ssid>\n")
                return
            ssid = args[1]
            # Obrir amb editor (nano)
            path = f"/etc/NetworkManager/system-connections/{ssid}.nmconnection"
            if not os.path.exists(path):
                self._insert(f"No es troba el perfil de '{ssid}'.\n")
                return
            try:
                subprocess.run(["nano", path])
            except:
                self._insert("No s'ha pogut obrir l'editor.\n")
        else:
            self._insert("Subcomanda Wi‑Fi desconeguda.\n")

    # ------------------------------------------------------------------
    # Execució de programes
    # ------------------------------------------------------------------
    def _execute_program(self, args):
        if not args:
            self._insert("Ús: execute <programa> [args...] [--secure]\n")
            return
        secure = False
        if "--secure" in args:
            secure = True
            args.remove("--secure")
        prog = args[0]
        pargs = args[1:]
        try:
            if secure:
                # intent amb firejail si existeix
                cmd = ["firejail", prog] + pargs
            else:
                cmd = [prog] + pargs
            subprocess.Popen(cmd, start_new_session=True,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self._insert(f"Executant {prog}...\n")
        except FileNotFoundError:
            self._insert(f"No s'ha trobat el programa '{prog}'.\n")
        except Exception as e:
            self._insert(f"Error: {e}\n")

    def _info_program(self, args):
        if not args:
            self._insert("Ús: info <programa>\n")
            return
        prog = args[0]
        try:
            # Intentar --version
            out = subprocess.check_output([prog, "--version"], stderr=subprocess.STDOUT,
                                         text=True, timeout=5)
            self._insert(out)
        except:
            try:
                # Alternativa: dpkg -s
                out = subprocess.check_output(["dpkg", "-s", prog], text=True, timeout=5)
                self._insert(out)
            except:
                self._insert(f"No s'ha pogut obtenir informació de '{prog}'.\n")

    def _check_program(self, args):
        if not args:
            self._insert("Ús: check <programa>\n")
            return
        prog = args[0]
        path = shutil.which(prog)
        if not path:
            self._insert(f"No s'ha trobat '{prog}' al PATH.\n")
            return
        try:
            # Verificació simple: sha256 i tipus
            import hashlib
            with open(path, "rb") as f:
                h = hashlib.sha256(f.read()).hexdigest()
            tipus = subprocess.check_output(["file", path], text=True).strip()
            self._insert(f"Ruta: {path}\n")
            self._insert(f"SHA256: {h}\n")
            self._insert(f"Tipus: {tipus}\n")
            # Missatge simbòlic
            self._insert("✅ El programa és segur (signatura no verificada).\n")
        except Exception as e:
            self._insert(f"Error en la comprovació: {e}\n")

    # ------------------------------------------------------------------
    # Maquinari
    # ------------------------------------------------------------------
    def _ram(self):
        if PSUTIL:
            mem = psutil.virtual_memory()
            swap = psutil.swap_memory()
            self._insert(f"Total RAM: {mem.total//(1024**2)} MB\n")
            self._insert(f"Usada: {mem.used//(1024**2)} MB\n")
            self._insert(f"Lliure: {mem.available//(1024**2)} MB\n")
            self._insert(f"Swap total: {swap.total//(1024**2)} MB\n")
        else:
            self._insert("psutil no instal·lat.\n")

    def _cpu(self):
        if PSUTIL:
            freq = psutil.cpu_freq()
            self._insert(f"Model: {platform.processor()}\n")
            self._insert(f"Nuclis: {psutil.cpu_count(logical=False)} físics, {psutil.cpu_count()} lògics\n")
            if freq:
                self._insert(f"Freqüència: {freq.current:.0f} MHz\n")
            self._insert(f"Càrrega: {psutil.getloadavg()}\n")
        else:
            self._insert("psutil no instal·lat.\n")

    def _reboot(self):
        self._insert("⚠️  Confirmació: reiniciar el sistema? (s/n) ")
        # Llegir resposta en la següent línia (simplificat, no implementem lector addicional)
        # En producció, un simple input no és possible. Aquí mostrarem l'ordre.
        self._insert("\nExecuteu 'sudo reboot' manualment si esteu segur.\n")

    def _poweroff(self):
        self._insert("⚠️  Confirmació: apagar el sistema? (s/n)\n")
        self._insert("Executeu 'sudo poweroff' manualment.\n")

    # ------------------------------------------------------------------
    # Ajuda
    # ------------------------------------------------------------------
    def _help(self):
        text = """
🐚 GUIA DE LA TERMINAL ARRELOS
================================
📂 Fitxers: dir [/h] [/s], cd, pwd, mkdir, rmdir, del [-f], copy, move, type/cat
📢 Sistema: echo, date, time, sysinfo [/v], clear/cls
⚙️ Processos: tasklist, taskkill /pid <id> | /im <nom>
🌐 Xarxa: ping <host> [-c N], ifconfig, curl <URL> [-o], wget <URL> [-O], nslookup <domini>
📶 Wi-Fi: wifi list | connect ssid="X" password="Y" [--hidden] | disconnect | show | edit <ssid>
🚀 Execució: execute <prog> [args] [--secure], info <prog>, check <prog>
🖥️ Maquinari: ram, cpu, reboot, poweroff
❓ Ajuda: help, ?

🔒 Ús intern · grup de confiança.
"""
        self._insert(text)

# ----------------------------------------------------------------------
# Arrencada
# ----------------------------------------------------------------------
if __name__ == "__main__":
    app = ArrelShell()
    app.mainloop()
