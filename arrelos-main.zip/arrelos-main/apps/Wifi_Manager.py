#!/usr/bin/env python3
"""
ArrelWifi.py – Gestor de xarxes Wi‑Fi per a ArrelOS (Raspberry Pi Zero 2 W)
Utilitza nmcli per escanejar i connectar. Interfície gràfica minimalista amb tkinter.
Compatible amb 512 MB de RAM. Comentaris en català.
Versió corregida: totes les crides a la GUI es fan des del fil principal.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import subprocess
import threading
import time

# ----------------------------------------------------------------------
# Colors i estils inspirats en macOS (platinum)
# ----------------------------------------------------------------------
BG_COLOR = "#ececec"
FG_COLOR = "#333333"
BTN_BG = "#d4d0c8"
BTN_ACTIVE = "#c0c0c0"
FONT = ("Lucida Grande", 11)
FONT_BOLD = ("Lucida Grande", 11, "bold")

# ----------------------------------------------------------------------
# Classe principal
# ----------------------------------------------------------------------
class ArrelWifi(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ArrelWifi")
        self.geometry("400x500")
        self.resizable(False, False)
        self.configure(bg=BG_COLOR)

        # Variable per al resultat de la connexió (selecció actual)
        self.selected_ssid = None
        self.selected_security = None
        self.connection_thread = None
        self.connecting = False

        # --- Centrar la finestra ---
        self.update_idletasks()
        w = self.winfo_width()
        h = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (w // 2)
        y = (self.winfo_screenheight() // 2) - (h // 2)
        self.geometry(f"+{x}+{y}")

        # Crear els widgets
        self._crear_interficie()
        # Començar l'escaneig inicial (segur al fil principal)
        self._escanejar_xarxes()

    # ------------------------------------------------------------------
    # Construcció de la interfície gràfica
    # ------------------------------------------------------------------
    def _crear_interficie(self):
        # Títol
        lbl_titol = tk.Label(self, text="Xarxes Wi‑Fi disponibles",
                             font=("Lucida Grande", 14, "bold"),
                             bg=BG_COLOR, fg=FG_COLOR)
        lbl_titol.pack(pady=(15, 10))

        # Treeview amb barra de desplaçament
        frame_tree = tk.Frame(self, bg=BG_COLOR)
        frame_tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))

        columns = ("Xarxa (SSID)", "Senyal", "Seguretat")
        self.tree = ttk.Treeview(frame_tree, columns=columns, show="headings",
                                 selectmode="browse", height=12)
        self.tree.heading("Xarxa (SSID)", text="Xarxa (SSID)")
        self.tree.heading("Senyal", text="Senyal")
        self.tree.heading("Seguretat", text="Seguretat")
        self.tree.column("Xarxa (SSID)", width=180)
        self.tree.column("Senyal", width=80, anchor=tk.CENTER)
        self.tree.column("Seguretat", width=100, anchor=tk.CENTER)

        scrollbar = ttk.Scrollbar(frame_tree, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Botons
        frame_botons = tk.Frame(self, bg=BG_COLOR)
        frame_botons.pack(fill=tk.X, padx=10, pady=(0, 5))

        self.btn_escan = tk.Button(frame_botons, text="Escanejar de nou",
                                   font=FONT, bg=BTN_BG, activebackground=BTN_ACTIVE,
                                   relief=tk.RAISED, command=self._escanejar_xarxes)
        self.btn_escan.pack(side=tk.LEFT, padx=(0, 5))

        self.btn_connectar = tk.Button(frame_botons, text="Connectar",
                                       font=FONT, bg=BTN_BG, activebackground=BTN_ACTIVE,
                                       relief=tk.RAISED, command=self._iniciar_connexio)
        self.btn_connectar.pack(side=tk.LEFT)

        # Barra d'estat
        self.status_var = tk.StringVar(value="Preparat")
        lbl_status = tk.Label(self, textvariable=self.status_var,
                              font=FONT, bg=BG_COLOR, fg=FG_COLOR,
                              anchor=tk.W, relief=tk.SUNKEN, bd=1)
        lbl_status.pack(side=tk.BOTTOM, fill=tk.X, padx=2, pady=2)

    # ------------------------------------------------------------------
    # Escaneig de xarxes amb nmcli (segur, al fil principal primer)
    # ------------------------------------------------------------------
    def _escanejar_xarxes(self):
        """Comprova l'estat del Wi‑Fi i, si està actiu, llança l'escaneig en segon pla."""
        self.btn_escan.config(state=tk.DISABLED)
        self._mostrar_estat("Comprovant Wi‑Fi...")
        # Comprovar ràpidament l'estat del Wi‑Fi en el fil principal
        try:
            wifi_status = subprocess.check_output(
                ["nmcli", "radio", "wifi"], text=True, stderr=subprocess.DEVNULL
            ).strip().lower()
        except FileNotFoundError:
            messagebox.showerror("Error", "nmcli no està instal·lat. Instal·leu network-manager.")
            self._habilitar_botons()
            return
        except subprocess.CalledProcessError:
            wifi_status = "unknown"

        if wifi_status != "enabled":
            self._mostrar_estat("Wi‑Fi desactivat")
            if messagebox.askyesno("Wi‑Fi desactivat",
                                   "El Wi‑Fi està desactivat. Voleu activar-lo?"):
                try:
                    subprocess.run(["nmcli", "radio", "wifi", "on"],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    # Donar temps a la targeta per activar-se
                    time.sleep(1.5)
                except Exception as e:
                    messagebox.showerror("Error", f"No s'ha pogut activar el Wi‑Fi:\n{e}")
                    self._habilitar_botons()
                    return
            else:
                self._habilitar_botons()
                return

        # Ara sí, llançar l'escaneig en un fil sense crides a la GUI directes
        self._mostrar_estat("Escanejant...")
        threading.Thread(target=self._executar_escaneig, daemon=True).start()

    def _executar_escaneig(self):
        """Tasca d'escaneig que s'executa en un fil secundari."""
        try:
            # Obtenir llista de xarxes en format màquina
            output = subprocess.check_output(
                ["nmcli", "-t", "-f", "SSID,BARS,SECURITY", "dev", "wifi", "list"],
                text=True, stderr=subprocess.DEVNULL
            )
        except subprocess.CalledProcessError as e:
            # Programar l'error al fil principal
            self.after(0, lambda: self._mostrar_estat(f"Error d'escaneig: {e}"))
            self.after(0, self._habilitar_botons)
            return

        # Processar les línies (sense tocar la GUI)
        xarxes = self._parsejar_sortida(output)
        # Actualitzar la taula i l'estat des del fil principal
        self.after(0, lambda: self._omplir_treeview(xarxes))

    def _parsejar_sortida(self, text):
        """
        Converteix la sortida de nmcli -t en un diccionari de xarxes.
        Format: SSID:BARS:SECURITY (pot haver-hi '\:' dins del SSID)
        Retorna una llista de tuples (ssid, bars, security).
        """
        resultats = {}
        lines = text.strip().split('\n')
        for linia in lines:
            if not linia:
                continue
            camps = self._split_escapat(linia, ':')
            if len(camps) != 3:
                continue
            ssid, bars, security = camps
            if not ssid:
                continue
            # Mantenir només l'entrada amb millor senyal
            if ssid in resultats:
                try:
                    bars_existent = int(resultats[ssid][0])
                    bars_nou = int(bars)
                    if bars_nou <= bars_existent:
                        continue
                except ValueError:
                    pass
            resultats[ssid] = (bars, security)
        return [(ssid, bars, security) for ssid, (bars, security) in resultats.items()]

    def _split_escapat(self, text, delim=':'):
        """
        Divideix una cadena pel delimitador, respectant els escapaments amb '\'.
        Exemple: 'Mi\:Red:80:WPA2' -> ['Mi:Red', '80', 'WPA2']
        """
        parts = []
        current = []
        esc = False
        for ch in text:
            if esc:
                current.append(ch)
                esc = False
            elif ch == '\\':
                esc = True
            elif ch == delim:
                parts.append(''.join(current))
                current = []
            else:
                current.append(ch)
        parts.append(''.join(current))
        return parts

    def _omplir_treeview(self, xarxes):
        """Omple el Treeview amb la llista de xarxes (ssid, bars, security)."""
        for item in self.tree.get_children():
            self.tree.delete(item)

        for ssid, bars, security in sorted(xarxes, key=lambda x: int(x[1]) if x[1].isdigit() else 0, reverse=True):
            try:
                signal_percent = int(bars)
                signal_text = f"{signal_percent}%"
            except ValueError:
                signal_text = bars
            self.tree.insert("", tk.END, values=(ssid, signal_text, security))

        self._mostrar_estat("Escaneig completat.")
        self._habilitar_botons()

    # ------------------------------------------------------------------
    # Gestió de connexió
    # ------------------------------------------------------------------
    def _iniciar_connexio(self):
        """Prepara la connexió a la xarxa seleccionada."""
        if self.connecting:
            messagebox.showwarning("En procés", "Ja s'està intentant connectar.")
            return

        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Selecció", "Seleccioneu una xarxa de la llista.")
            return

        item = self.tree.item(sel[0])
        ssid = item["values"][0]
        security = item["values"][2]

        # Xarxa oberta
        if security == "" or security == "--":
            self._connectar(ssid, "")
            return

        # Demanar contrasenya en una finestra filla
        self._demana_contrasenya(ssid)

    def _demana_contrasenya(self, ssid):
        """Crea una finestra filla per introduir la contrasenya (segura, fil principal)."""
        dialog = tk.Toplevel(self)
        dialog.title("Contrasenya")
        dialog.geometry("250x120")
        dialog.resizable(False, False)
        dialog.configure(bg=BG_COLOR)
        dialog.transient(self)
        dialog.grab_set()

        dialog.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() // 2) - (dialog.winfo_width() // 2)
        y = self.winfo_y() + (self.winfo_height() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")

        tk.Label(dialog, text=f"Contrasenya per a {ssid}:",
                 font=FONT, bg=BG_COLOR).pack(pady=(10, 0))

        entry_pass = tk.Entry(dialog, show="*", font=FONT, width=25)
        entry_pass.pack(pady=5)
        entry_pass.focus_set()

        def on_connect():
            pwd = entry_pass.get()
            dialog.destroy()
            self._connectar(ssid, pwd)

        def on_cancel():
            dialog.destroy()

        frame_btns = tk.Frame(dialog, bg=BG_COLOR)
        frame_btns.pack(pady=(5, 10))
        tk.Button(frame_btns, text="Cancel·lar", font=FONT, bg=BTN_BG,
                  command=on_cancel).pack(side=tk.LEFT, padx=5)
        tk.Button(frame_btns, text="Connectar", font=FONT_BOLD, bg=BTN_BG,
                  command=on_connect).pack(side=tk.LEFT, padx=5)

        dialog.bind("<Return>", lambda e: on_connect())
        dialog.bind("<Escape>", lambda e: on_cancel())

    def _connectar(self, ssid, password):
        """Llança la connexió en un fil secundari."""
        self.connecting = True
        self.btn_connectar.config(state=tk.DISABLED)
        self._mostrar_estat(f"Connectant a {ssid}...")

        self.connection_thread = threading.Thread(
            target=self._executar_connexio, args=(ssid, password), daemon=True
        )
        self.connection_thread.start()

    def _executar_connexio(self, ssid, password):
        """Executa la comanda nmcli per connectar (fil secundari)."""
        cmd = ["nmcli", "dev", "wifi", "connect", ssid]
        if password:
            cmd += ["password", password]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if result.returncode == 0:
                self.after(0, lambda: self._connexio_exitosa(ssid))
            else:
                error_msg = result.stderr.strip() or "Error desconegut"
                if "Secrets" in error_msg or "incorrect" in error_msg.lower():
                    error_msg = "Contrasenya incorrecta."
                self.after(0, lambda: self._connexio_fallada(error_msg))
        except subprocess.TimeoutExpired:
            self.after(0, lambda: self._connexio_fallada("Temps d'espera esgotat."))
        except Exception as e:
            self.after(0, lambda: self._connexio_fallada(str(e)))
        finally:
            self.after(0, self._restaurar_botons)

    def _connexio_exitosa(self, ssid):
        """Actualitza la interfície després d'una connexió correcta."""
        self._mostrar_estat(f"Connectat a: {ssid}")
        messagebox.showinfo("Connexió establerta",
                            f"Connectat correctament a «{ssid}».")

    def _connexio_fallada(self, missatge):
        """Mostra un error de connexió."""
        self._mostrar_estat("Error de connexió")
        messagebox.showerror("Error de connexió", missatge)

    def _restaurar_botons(self):
        """Torna a activar els botons després d'una connexió."""
        self.connecting = False
        self.btn_connectar.config(state=tk.NORMAL)
        self.btn_escan.config(state=tk.NORMAL)

    def _mostrar_estat(self, text):
        """Actualitza el text de la barra d'estat (fil principal)."""
        self.status_var.set(text)

    def _habilitar_botons(self):
        """Habilita el botó d'escaneig (fil principal)."""
        self.btn_escan.config(state=tk.NORMAL)

# ----------------------------------------------------------------------
# Punt d'entrada
# ----------------------------------------------------------------------
if __name__ == "__main__":
    # Comprovar que nmcli existeix
    try:
        subprocess.run(["nmcli", "--version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Error", "No s'ha trobat nmcli. Instal·leu Network Manager.")
        root.destroy()
        exit(1)

    app = ArrelWifi()
    app.mainloop()
