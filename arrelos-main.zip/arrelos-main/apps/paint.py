#!/usr/bin/env python3
"""
ArrelPaint.py – Flagship drawing application for ArrelOS.
Heavily inspired by MS Paint (98/2000) with platinum macOS aesthetic.
Requires Pillow: pip install Pillow
Uses a synchronized PIL image and Tkinter Canvas for all drawing operations.
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from collections import deque
from PIL import Image, ImageDraw, ImageTk

# ----------------------------------------------------------------------
# Platinum colour palette constants
# ----------------------------------------------------------------------
BG_MAIN = "#ececec"
BG_TOOLBOX = "#d4d0c8"
PAPER_BG = "#ffffff"
FG_DARK = "#000000"

# Standard 16 classic colours (Windows 98 style)
PALETTE_COLORS = [
    "#000000", "#ffffff", "#808080", "#c0c0c0",
    "#ff0000", "#00ff00", "#0000ff", "#ffff00",
    "#ff00ff", "#00ffff", "#800000", "#008000",
    "#000080", "#808000", "#800080", "#008080"
]

CANVAS_WIDTH = 640
CANVAS_HEIGHT = 480

# ----------------------------------------------------------------------
# Main Application
# ----------------------------------------------------------------------
class ArrelPaint(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ArrelPaint - Untitled")
        self.geometry("800x600")
        self.minsize(700, 500)
        self.configure(bg=BG_MAIN)

        # Drawing state
        self.current_tool = tk.StringVar(value="pencil")   # pencil, eraser, line, rect, oval, fill
        self.drawing_color = "#000000"
        self.brush_size = tk.IntVar(value=2)

        # PIL image and canvas reference
        self.pil_image = Image.new("RGB", (CANVAS_WIDTH, CANVAS_HEIGHT), PAPER_BG)
        self.draw = ImageDraw.Draw(self.pil_image)

        # Canvas shape preview
        self._preview_id = None
        self._start_x = None
        self._start_y = None
        self._last_x = None   # for pencil/eraser
        self._last_y = None

        # Build UI
        self._create_menu()
        self._create_toolbar()
        self._create_canvas_frame()
        self._create_bottom_bar()

        # Place the initial blank image on the canvas
        self._update_canvas_image()

    # ------------------------------------------------------------------
    # Menu bar (File operations)
    # ------------------------------------------------------------------
    def _create_menu(self):
        menubar = tk.Menu(self, bg=BG_TOOLBOX, fg=FG_DARK, font=("Lucida Grande", 10))
        self.config(menu=menubar)

        file_menu = tk.Menu(menubar, tearoff=0, bg=BG_MAIN, fg=FG_DARK)
        menubar.add_cascade(label="Fitxer", menu=file_menu)
        file_menu.add_command(label="Nou", command=self.new_document, accelerator="Ctrl+N")
        file_menu.add_command(label="Obrir...", command=self.open_document, accelerator="Ctrl+O")
        file_menu.add_command(label="Desar", command=self.save_document, accelerator="Ctrl+S")
        file_menu.add_separator()
        file_menu.add_command(label="Sortir", command=self.destroy, accelerator="Ctrl+Q")

        # Keyboard shortcuts
        self.bind_all("<Control-n>", lambda e: self.new_document())
        self.bind_all("<Control-o>", lambda e: self.open_document())
        self.bind_all("<Control-s>", lambda e: self.save_document())

    # ------------------------------------------------------------------
    # Left sidebar – Toolbox
    # ------------------------------------------------------------------
    def _create_toolbar(self):
        toolbox = tk.Frame(self, bg=BG_TOOLBOX, width=100, relief=tk.RAISED, borderwidth=1)
        toolbox.pack(side=tk.LEFT, fill=tk.Y, padx=(2, 2), pady=2)
        toolbox.pack_propagate(False)

        tk.Label(toolbox, text="Eines", bg=BG_TOOLBOX,
                 font=("Lucida Grande", 11, "bold")).pack(pady=(8, 2))

        tools = [
            ("Llapis", "pencil"),
            ("Goma", "eraser"),
            ("Línia", "line"),
            ("Rectangle", "rect"),
            ("Cercle", "oval"),
            ("Galleda", "fill"),
        ]
        self.tool_buttons = {}   # name -> button widget
        for text, tool_name in tools:
            btn = tk.Button(toolbox, text=text, font=("Lucida Grande", 10),
                            bg=BG_TOOLBOX, relief=tk.RAISED, width=10, anchor="w",
                            command=lambda t=tool_name: self._set_tool(t))
            btn.pack(pady=2, padx=6)
            self.tool_buttons[tool_name] = btn

        self._set_tool("pencil")  # initial selection

        # Separator
        ttk.Separator(toolbox, orient=tk.HORIZONTAL).pack(fill=tk.X, padx=6, pady=8)

        # Brush size control
        tk.Label(toolbox, text="Gruix:", bg=BG_TOOLBOX, font=("Lucida Grande", 10)).pack(anchor="w", padx=8)
        spin = tk.Spinbox(toolbox, from_=1, to=12, textvariable=self.brush_size,
                          width=4, font=("Lucida Grande", 10), bg="white", justify=tk.CENTER)
        spin.pack(pady=2, padx=6)

    def _set_tool(self, tool_name):
        """Activate a tool and update button reliefs."""
        self.current_tool.set(tool_name)
        for name, btn in self.tool_buttons.items():
            btn.config(relief=tk.SUNKEN if name == tool_name else tk.RAISED)

    # ------------------------------------------------------------------
    # Central canvas area (simulated digital sheet)
    # ------------------------------------------------------------------
    def _create_canvas_frame(self):
        # Outer frame with a border resembling a paper sheet
        outer = tk.Frame(self, bg="#b0b0b0", borderwidth=2, relief=tk.SUNKEN)
        outer.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.canvas = tk.Canvas(outer, width=CANVAS_WIDTH, height=CANVAS_HEIGHT,
                                bg=PAPER_BG, highlightthickness=0, cursor="cross")
        self.canvas.pack(padx=2, pady=2)

        # Bind mouse events for drawing
        self.canvas.bind("<Button-1>", self._on_mouse_down)
        self.canvas.bind("<B1-Motion>", self._on_mouse_move)
        self.canvas.bind("<ButtonRelease-1>", self._on_mouse_up)

    # ------------------------------------------------------------------
    # Bottom palette bar (colours + active colour preview)
    # ------------------------------------------------------------------
    def _create_bottom_bar(self):
        bottom = tk.Frame(self, bg=BG_MAIN, relief=tk.RAISED, borderwidth=1)
        bottom.pack(side=tk.BOTTOM, fill=tk.X, padx=2, pady=(0, 2))

        # Active colour preview
        preview_frame = tk.Frame(bottom, bg=BG_MAIN)
        preview_frame.pack(side=tk.LEFT, padx=8, pady=4)

        tk.Label(preview_frame, text="Color Actiu:", bg=BG_MAIN,
                 font=("Lucida Grande", 9)).pack(side=tk.LEFT)
        self.color_preview = tk.Canvas(preview_frame, width=24, height=24,
                                       bg=self.drawing_color,
                                       highlightthickness=1, highlightbackground="#888")
        self.color_preview.pack(side=tk.LEFT, padx=4)

        # Colour swatches
        swatch_frame = tk.Frame(bottom, bg=BG_MAIN)
        swatch_frame.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=4, pady=2)

        row, col = 0, 0
        for color in PALETTE_COLORS:
            sw = tk.Canvas(swatch_frame, width=22, height=22, bg=color,
                           highlightthickness=1, highlightbackground="#888",
                           cursor="hand2")
            sw.grid(row=row, column=col, padx=1, pady=1)
            sw.bind("<Button-1>", lambda e, c=color: self._select_color(c))
            col += 1
            if col >= 8:
                col = 0
                row += 1

    def _select_color(self, color):
        self.drawing_color = color
        self.color_preview.config(bg=color)

    # ------------------------------------------------------------------
    # PIL <-> Canvas synchronisation
    # ------------------------------------------------------------------
    def _update_canvas_image(self):
        """Re-create PhotoImage from the PIL image and display it on the canvas."""
        self._photo = ImageTk.PhotoImage(self.pil_image)
        if hasattr(self, "_image_id"):
            self.canvas.itemconfig(self._image_id, image=self._photo)
        else:
            self._image_id = self.canvas.create_image(0, 0, anchor=tk.NW, image=self._photo)

    # ------------------------------------------------------------------
    # Mouse event handlers (routing to tools)
    # ------------------------------------------------------------------
    def _on_mouse_down(self, event):
        tool = self.current_tool.get()
        if tool == "fill":
            self._flood_fill(event.x, event.y)
            return

        # Store starting point for shapes and continuous draw
        self._start_x = event.x
        self._start_y = event.y
        self._last_x = event.x
        self._last_y = event.y

        if tool == "pencil":
            # Draw a single dot so a click registers
            self._draw_pixel(event.x, event.y)
        elif tool == "eraser":
            self._erase_pixel(event.x, event.y)

    def _on_mouse_move(self, event):
        tool = self.current_tool.get()
        if tool in ("pencil", "eraser"):
            if self._last_x is not None:
                self._draw_line(self._last_x, self._last_y, event.x, event.y,
                                erase=(tool == "eraser"))
            self._last_x = event.x
            self._last_y = event.y
            return

        # Shape preview (rubber band)
        if tool in ("line", "rect", "oval"):
            if self._start_x is None or self._start_y is None:
                return
            # Remove previous preview
            if self._preview_id is not None:
                self.canvas.delete(self._preview_id)
                self._preview_id = None

            # Draw temporary shape on canvas (not on PIL)
            dash = (5, 2) if tool != "line" else None
            if tool == "line":
                self._preview_id = self.canvas.create_line(
                    self._start_x, self._start_y, event.x, event.y,
                    fill=self.drawing_color, width=self.brush_size.get(),
                    dash=dash, tags="preview")
            elif tool == "rect":
                self._preview_id = self.canvas.create_rectangle(
                    self._start_x, self._start_y, event.x, event.y,
                    outline=self.drawing_color, width=self.brush_size.get(),
                    dash=dash, tags="preview")
            elif tool == "oval":
                self._preview_id = self.canvas.create_oval(
                    self._start_x, self._start_y, event.x, event.y,
                    outline=self.drawing_color, width=self.brush_size.get(),
                    dash=dash, tags="preview")

    def _on_mouse_up(self, event):
        tool = self.current_tool.get()
        # Freehand tools – reset tracking
        self._last_x = None
        self._last_y = None

        # Shape tools: finalize
        if tool in ("line", "rect", "oval"):
            if self._preview_id is not None:
                self.canvas.delete(self._preview_id)
                self._preview_id = None

            if self._start_x is None or self._start_y is None:
                return

            x1, y1 = self._start_x, self._start_y
            x2, y2 = event.x, event.y
            if x1 == x2 and y1 == y2:
                # Zero-size shape – ignore
                pass
            else:
                # Draw on PIL
                width = self.brush_size.get()
                if tool == "line":
                    self.draw.line([x1, y1, x2, y2], fill=self.drawing_color, width=width)
                elif tool == "rect":
                    self.draw.rectangle([x1, y1, x2, y2], outline=self.drawing_color, width=width)
                elif tool == "oval":
                    self.draw.oval([x1, y1, x2, y2], outline=self.drawing_color, width=width)
                self._update_canvas_image()

        self._start_x = None
        self._start_y = None

    # ------------------------------------------------------------------
    # Low-level drawing helpers (commit to PIL and refresh canvas)
    # ------------------------------------------------------------------
    def _draw_pixel(self, x, y):
        """Draw a single dot (for pencil click)."""
        self.draw.point((x, y), fill=self.drawing_color)
        self._update_canvas_image()

    def _erase_pixel(self, x, y):
        """Draw a white dot (eraser)."""
        self.draw.point((x, y), fill=PAPER_BG)
        self._update_canvas_image()

    def _draw_line(self, x1, y1, x2, y2, erase=False):
        """Draw a line on PIL between two points (for freehand tools)."""
        color = PAPER_BG if erase else self.drawing_color
        width = self.brush_size.get()
        self.draw.line([x1, y1, x2, y2], fill=color, width=width)
        self._update_canvas_image()

    # ------------------------------------------------------------------
    # Flood fill (BFS on PIL image)
    # ------------------------------------------------------------------
    def _flood_fill(self, x, y):
        if x < 0 or x >= CANVAS_WIDTH or y < 0 or y >= CANVAS_HEIGHT:
            return
        target_color = self.pil_image.getpixel((x, y))
        if target_color == self.drawing_color:
            return   # already the same colour

        pixels = self.pil_image.load()  # faster access
        q = deque()
        q.append((x, y))
        while q:
            cx, cy = q.popleft()
            if cx < 0 or cx >= CANVAS_WIDTH or cy < 0 or cy >= CANVAS_HEIGHT:
                continue
            if pixels[cx, cy] != target_color:
                continue
            pixels[cx, cy] = self.drawing_color
            q.append((cx+1, cy))
            q.append((cx-1, cy))
            q.append((cx, cy+1))
            q.append((cx, cy-1))

        self._update_canvas_image()

    # ------------------------------------------------------------------
    # File operations (New, Open, Save)
    # ------------------------------------------------------------------
    def new_document(self):
        """Reset the drawing area to a blank white canvas."""
        self.pil_image = Image.new("RGB", (CANVAS_WIDTH, CANVAS_HEIGHT), PAPER_BG)
        self.draw = ImageDraw.Draw(self.pil_image)
        self._update_canvas_image()
        self.title("ArrelPaint - Untitled")

    def open_document(self):
        """Open an image file and place it as the background."""
        filetypes = [("Image files", "*.png *.jpg *.jpeg *.bmp"), ("All files", "*.*")]
        filename = filedialog.askopenfilename(title="Open Image", filetypes=filetypes)
        if not filename:
            return
        try:
            img = Image.open(filename).convert("RGB")
            # Resize to canvas dimensions (distortion allowed)
            img = img.resize((CANVAS_WIDTH, CANVAS_HEIGHT), Image.LANCZOS)
            self.pil_image = img
            self.draw = ImageDraw.Draw(self.pil_image)
            self._update_canvas_image()
            self.title(f"ArrelPaint - {os.path.basename(filename)}")
        except Exception as e:
            messagebox.showerror("Error", f"Could not open image:\n{e}")

    def save_document(self):
        """Save the current PIL image as a PNG or BMP file."""
        filetypes = [("PNG image", "*.png"), ("BMP image", "*.bmp")]
        filename = filedialog.asksaveasfilename(title="Save Image",
                                                defaultextension=".png",
                                                filetypes=filetypes)
        if not filename:
            return
        try:
            self.pil_image.save(filename)
            self.title(f"ArrelPaint - {os.path.basename(filename)}")
        except Exception as e:
            messagebox.showerror("Error", f"Could not save image:\n{e}")


# ----------------------------------------------------------------------
# Entry point
# ----------------------------------------------------------------------
if __name__ == "__main__":
    import os
    app = ArrelPaint()
    app.mainloop()