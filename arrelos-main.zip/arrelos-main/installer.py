#!/usr/bin/env python3
"""
ArrelSetup.py – Assistent gràfic d'instal·lació d'ArrelOS (Tiger 10.4 style).
Versió corregida i completament funcional.
Executa 'setup.sh' sense bloquejar la interfície, mostrant la sortida en temps real.
Cal executar-lo amb permisos de root (sudo) perquè setup.sh funcioni.
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import subprocess
import threading
import queue
import os
import sys

# ----------------------------------------------------------------------
# Paleta de colors Aqua/Platinum
# ----------------------------------------------------------------------
BG_MAIN = "#ececec"
BG_FRAME = "#d4d0c8"
FG_DARK = "#333333"
ACCENT_GREEN = "#4d9b4d"
ACCENT_RED = "#c05050"

# ----------------------------------------------------------------------
# Classe principal
# ----------------------------------------------------------------------
class ArrelSetup(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ArrelOS – Assistent d'instal·lació")
        self.geometry("800x600")
        self.resizable(False, False)
        self.configure(bg=BG_MAIN)

        # Variables d'estat (es guarden, però la instal·lació real les agafa del setup.sh)
        self.teclat = tk.StringVar(value="Català")
        self.volum = tk.IntVar(value=70)
        self.usuari = tk.StringVar()
        self.contrasenya = tk.StringVar()
        self.avatar_seleccionat = tk.IntVar(value=0)

        # Emmagatzemar totes les pantalles
        self.frames = {}
        self.current_frame = None

        # Crear les pantalles
        self._crear_pantalla_benvinguda()
        self._crear_pantalla_teclat()
        self._crear_pantalla_audio()
        self._crear_pantalla_usuari()
        self._crear_pantalla_progres()
        self._crear_pantalla_final()

        # Mostrar la primera pantalla
        self._mostrar_pantalla(0)

    # ------------------------------------------------------------------
    # Canvi de pantalla
    # ------------------------------------------------------------------
    def _mostrar_pantalla(self, index):
        """Amaga la pantalla actual i mostra la nova."""
        if self.current_frame:
            self.current_frame.pack_forget()
        frame_key = f"screen{index}"
        frame = self.frames[frame_key]
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        self.current_frame = frame

        # Si passem a la pantalla de progrés, iniciar la instal·lació automàticament
        if index == 4 and not hasattr(self, '_instalacio_iniciada'):
            self._instalacio_iniciada = True
            self._iniciar_instalacio()

    # ------------------------------------------------------------------
    # Barra de navegació comuna
    # ------------------------------------------------------------------
    def _afegir_navegacio(self, parent, index, total=6):
        """Barra inferior amb botons Enrere/Següent."""
        nav = tk.Frame(parent, bg=BG_MAIN)
        nav.pack(side=tk.BOTTOM, fill=tk.X, pady=15, padx=20)

        # Botó Enrere (excepte a la primera pantalla)
        if index > 0:
            btn_enrere = tk.Button(nav, text="Enrere", font=("Helvetica", 11, "bold"),
                                   bg=BG_FRAME, fg=FG_DARK, relief=tk.RAISED,
                                   command=lambda: self._mostrar_pantalla(index-1))
            btn_enrere.pack(side=tk.LEFT)

        # Botó Següent (excepte a la darrera)
        if index < total - 1:
            if index == 3:  # Pantalla d'usuari: validar camps
                btn_seguent = tk.Button(nav, text="Següent", font=("Helvetica", 11, "bold"),
                                        bg=BG_FRAME, fg=FG_DARK, relief=tk.RAISED,
                                        command=self._validar_i_avancar_usuari)
            else:
                btn_seguent = tk.Button(nav, text="Següent", font=("Helvetica", 11, "bold"),
                                        bg=BG_FRAME, fg=FG_DARK, relief=tk.RAISED,
                                        command=lambda: self._mostrar_pantalla(index+1))
            btn_seguent.pack(side=tk.RIGHT)

    # ------------------------------------------------------------------
    # Pantalla 0: Benvinguda
    # ------------------------------------------------------------------
    def _crear_pantalla_benvinguda(self):
        frame = tk.Frame(self, bg=BG_MAIN)
        self.frames["screen0"] = frame

        tk.Label(frame, text="Benvingut a la instal·lació d'ArrelOS",
                 font=("Helvetica", 22, "bold"), bg=BG_MAIN, fg=FG_DARK).pack(pady=(60, 10))
        tk.Label(frame, text="Aquest assistent configurarà el sistema,\n"
                              "instal·larà les aplicacions i aplicarà blindatge de seguretat.",
                 font=("Helvetica", 13), bg=BG_MAIN, fg=FG_DARK, justify=tk.CENTER).pack(pady=10)

        self._afegir_navegacio(frame, index=0)

    # ------------------------------------------------------------------
    # Pantalla 1: Teclat
    # ------------------------------------------------------------------
    def _crear_pantalla_teclat(self):
        frame = tk.Frame(self, bg=BG_MAIN)
        self.frames["screen1"] = frame

        tk.Label(frame, text="Disposició del teclat",
                 font=("Helvetica", 18, "bold"), bg=BG_MAIN, fg=FG_DARK).pack(pady=(30, 10))

        opcions = ["Català", "Espanyol", "English"]
        for opcio in opcions:
            tk.Radiobutton(frame, text=opcio, variable=self.teclat, value=opcio,
                           font=("Helvetica", 13), bg=BG_MAIN, fg=FG_DARK,
                           selectcolor=BG_MAIN, anchor="w").pack(pady=5, padx=40, fill=tk.X)

        self._afegir_navegacio(frame, index=1)

    # ------------------------------------------------------------------
    # Pantalla 2: Test d'àudio
    # ------------------------------------------------------------------
    def _crear_pantalla_audio(self):
        frame = tk.Frame(self, bg=BG_MAIN)
        self.frames["screen2"] = frame

        tk.Label(frame, text="Prova de so",
                 font=("Helvetica", 18, "bold"), bg=BG_MAIN, fg=FG_DARK).pack(pady=(30, 10))
        tk.Label(frame, text="Ajusteu el volum i feu clic a 'Provar':",
                 font=("Helvetica", 12), bg=BG_MAIN, fg=FG_DARK).pack(pady=5)

        ttk.Scale(frame, from_=0, to=100, variable=self.volum,
                  orient=tk.HORIZONTAL, length=350).pack(pady=10)

        def provar_so():
            try:
                subprocess.Popen(["speaker-test", "-t", "sine", "-f", "1000", "-l", "1", "-P", "2"],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except:
                messagebox.showinfo("Prova de so", "No s'ha pogut executar speaker-test. Verifiqueu ALSA.")

        tk.Button(frame, text="Provar so", font=("Helvetica", 12, "bold"),
                  bg=BG_FRAME, fg=FG_DARK, relief=tk.RAISED, command=provar_so).pack(pady=10)

        self._afegir_navegacio(frame, index=2)

    # ------------------------------------------------------------------
    # Pantalla 3: Usuari i avatar
    # ------------------------------------------------------------------
    def _crear_pantalla_usuari(self):
        frame = tk.Frame(self, bg=BG_MAIN)
        self.frames["screen3"] = frame

        tk.Label(frame, text="Credencials d'usuari",
                 font=("Helvetica", 18, "bold"), bg=BG_MAIN, fg=FG_DARK).pack(pady=(30, 10))

        # Formulari
        form = tk.Frame(frame, bg=BG_MAIN)
        form.pack(pady=5)

        tk.Label(form, text="Nom d'usuari:", font=("Helvetica", 11), bg=BG_MAIN, fg=FG_DARK).grid(row=0, column=0, sticky="e", pady=4)
        self.entry_usuari = tk.Entry(form, textvariable=self.usuari, font=("Helvetica", 12), width=22)
        self.entry_usuari.grid(row=0, column=1, padx=5, pady=4)

        tk.Label(form, text="Contrasenya:", font=("Helvetica", 11), bg=BG_MAIN, fg=FG_DARK).grid(row=1, column=0, sticky="e", pady=4)
        self.entry_pass = tk.Entry(form, textvariable=self.contrasenya, font=("Helvetica", 12),
                                   show="*", width=22)
        self.entry_pass.grid(row=1, column=1, padx=5, pady=4)

        # Selecció d'avatar
        tk.Label(frame, text="Escolliu un avatar:", font=("Helvetica", 11), bg=BG_MAIN, fg=FG_DARK).pack(pady=(15, 5))
        avatars_frame = tk.Frame(frame, bg=BG_MAIN)
        avatars_frame.pack()

        self.avatar_canvases = []
        formes = ["papallona", "bola8", "poma"]
        colors = ["#f0a0a0", "#a0a0f0", "#a0f0a0"]
        for i, (forma, color) in enumerate(zip(formes, colors)):
            canvas = tk.Canvas(avatars_frame, width=80, height=80, bg=BG_MAIN,
                               highlightthickness=1, highlightbackground="#aaa",
                               cursor="hand2")
            if forma == "papallona":
                canvas.create_oval(10,10,70,70, fill=color, outline="")
                canvas.create_text(40,40, text="A", font=("Helvetica", 20, "bold"), fill="white")
            elif forma == "bola8":
                canvas.create_oval(5,5,75,75, fill="black", outline="")
                canvas.create_oval(25,25,55,55, fill="white", outline="")
                canvas.create_text(40,40, text="8", font=("Helvetica", 16, "bold"), fill="black")
            else:
                canvas.create_oval(10,10,70,70, fill=color, outline="")
                canvas.create_text(40,40, text="M", font=("Helvetica", 20, "bold"), fill="white")
            canvas.grid(row=0, column=i, padx=8)
            canvas.bind("<Button-1>", lambda e, idx=i: self._seleccionar_avatar(idx))
            self.avatar_canvases.append(canvas)

        self._seleccionar_avatar(0)
        self._afegir_navegacio(frame, index=3)

    def _seleccionar_avatar(self, idx):
        for i, canvas in enumerate(self.avatar_canvases):
            canvas.config(highlightbackground="#aaa", highlightthickness=1)
        self.avatar_canvases[idx].config(highlightbackground="black", highlightthickness=3)
        self.avatar_seleccionat.set(idx)

    def _validar_i_avancar_usuari(self):
        """Comprova que usuari i contrasenya no estiguin buits."""
        usuari = self.usuari.get().strip()
        contrasenya = self.contrasenya.get().strip()
        if not usuari:
            messagebox.showerror("Error", "El nom d'usuari no pot estar buit.")
            return
        if not contrasenya:
            messagebox.showerror("Error", "La contrasenya no pot estar buida.")
            return
        self._mostrar_pantalla(4)

    # ------------------------------------------------------------------
    # Pantalla 4: Progrés de la instal·lació
    # ------------------------------------------------------------------
    def _crear_pantalla_progres(self):
        frame = tk.Frame(self, bg=BG_MAIN)
        self.frames["screen4"] = frame

        tk.Label(frame, text="Instal·lació en curs",
                 font=("Helvetica", 18, "bold"), bg=BG_MAIN, fg=FG_DARK).pack(pady=(20, 5))
        tk.Label(frame, text="S'estan aplicant les configuracions i els pegats de seguretat.\n"
                              "No apagueu l'ordinador.",
                 font=("Helvetica", 11), bg=BG_MAIN, fg=FG_DARK).pack(pady=5)

        self.progress = ttk.Progressbar(frame, orient=tk.HORIZONTAL, length=500, mode='indeterminate')
        self.progress.pack(pady=10)

        self.consola = scrolledtext.ScrolledText(frame, bg="black", fg="#00ff00",
                                                 font=("Courier New", 10), wrap=tk.WORD,
                                                 state=tk.DISABLED, height=15)
        self.consola.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

        # Barra de navegació desactivada durant la instal·lació
        self.nav_progres = tk.Frame(frame, bg=BG_MAIN)
        self.nav_progres.pack(side=tk.BOTTOM, fill=tk.X, pady=15, padx=20)

        self.btn_enrere4 = tk.Button(self.nav_progres, text="Enrere", font=("Helvetica", 11, "bold"),
                                     bg=BG_FRAME, fg=FG_DARK, relief=tk.RAISED,
                                     command=lambda: self._mostrar_pantalla(3))
        self.btn_enrere4.pack(side=tk.LEFT)
        self.btn_seguent4 = tk.Button(self.nav_progres, text="Següent", font=("Helvetica", 11, "bold"),
                                      bg=BG_FRAME, fg=FG_DARK, relief=tk.RAISED,
                                      state=tk.DISABLED,
                                      command=lambda: self._mostrar_pantalla(5))
        self.btn_seguent4.pack(side=tk.RIGHT)

    def _iniciar_instalacio(self):
        """Desactiva botons i executa setup.sh en un fil separat."""
        self.btn_enrere4.config(state=tk.DISABLED)
        self.btn_seguent4.config(state=tk.DISABLED)
        self.progress.start(10)

        script_dir = os.path.dirname(os.path.abspath(__file__))
        setup_path = os.path.join(script_dir, "setup.sh")

        if not os.path.exists(setup_path):
            self._escriure_consola("ERROR: No s'ha trobat 'setup.sh' al directori actual.\n")
            self.progress.stop()
            self.btn_enrere4.config(state=tk.NORMAL)
            return

        # Verificar que tenim permisos de root
        if os.geteuid() != 0:
            self._escriure_consola("ERROR: Es necessiten permisos de root. Executeu amb 'sudo'.\n")
            self.progress.stop()
            self.btn_enrere4.config(state=tk.NORMAL)
            messagebox.showerror("Permisos", "Aquest programa ha d'executar-se com a root (sudo).")
            return

        self._escriure_consola("Iniciant la instal·lació...\n")
        self.output_queue = queue.Queue()
        threading.Thread(target=self._executar_script, args=(setup_path,), daemon=True).start()
        self.after(100, self._comprovar_sortida)

    def _executar_script(self, setup_path):
        """Executa setup.sh i posa la sortida a la cua."""
        try:
            proc = subprocess.Popen(['bash', setup_path],
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT,
                                    text=True, bufsize=1)
            for line in iter(proc.stdout.readline, ''):
                self.output_queue.put(line)
            proc.stdout.close()
            retcode = proc.wait()
            self.output_queue.put(None)  # Senyal de finalització
            self.output_queue.put(retcode)
        except Exception as e:
            self.output_queue.put(f"ERROR: {str(e)}\n")
            self.output_queue.put(None)

    def _comprovar_sortida(self):
        """Llegeix la cua i actualitza la consola periòdicament."""
        try:
            while True:
                line = self.output_queue.get_nowait()
                if line is None:  # Fi del procés
                    retcode = self.output_queue.get_nowait()
                    self._escriure_consola(f"\nInstal·lació finalitzada amb codi: {retcode}\n")
                    self.progress.stop()
                    if retcode == 0:
                        self.btn_seguent4.config(state=tk.NORMAL, text="Següent")
                        self._escriure_consola("Podeu continuar amb la configuració final.\n")
                    else:
                        self._escriure_consola("S'han produït errors. Reviseu el registre.\n")
                        self.btn_enrere4.config(state=tk.NORMAL)
                    return
                else:
                    self._escriure_consola(line)
        except queue.Empty:
            pass
        self.after(100, self._comprovar_sortida)

    def _escriure_consola(self, text):
        """Insereix text a l'àrea de consola de manera segura."""
        self.consola.config(state=tk.NORMAL)
        self.consola.insert(tk.END, text)
        self.consola.see(tk.END)
        self.consola.config(state=tk.DISABLED)

    # ------------------------------------------------------------------
    # Pantalla 5: Finalització i reinici
    # ------------------------------------------------------------------
    def _crear_pantalla_final(self):
        frame = tk.Frame(self, bg=BG_MAIN)
        self.frames["screen5"] = frame

        tk.Label(frame, text="Instal·lació completada amb èxit!",
                 font=("Helvetica", 20, "bold"), bg=BG_MAIN, fg=ACCENT_GREEN).pack(pady=(60, 10))
        tk.Label(frame, text="ArrelOS està blindat i preparat per al primer ús.",
                 font=("Helvetica", 13), bg=BG_MAIN, fg=FG_DARK).pack(pady=10)

        btn_reiniciar = tk.Button(frame, text="Reiniciar", font=("Helvetica", 14, "bold"),
                                  bg=ACCENT_RED, fg="white", relief=tk.RAISED,
                                  command=self._reiniciar_sistema)
        btn_reiniciar.pack(pady=20)

        nav = tk.Frame(frame, bg=BG_MAIN)
        nav.pack(side=tk.BOTTOM, fill=tk.X, pady=15, padx=20)
        tk.Button(nav, text="Sortir sense reiniciar", font=("Helvetica", 11),
                  bg=BG_FRAME, fg=FG_DARK, relief=tk.RAISED,
                  command=self.destroy).pack(side=tk.RIGHT)

    def _reiniciar_sistema(self):
        if messagebox.askyesno("Reiniciar", "Esteu segur de reiniciar el sistema ara?"):
            subprocess.run(["reboot"])

# ----------------------------------------------------------------------
# Punt d'entrada
# ----------------------------------------------------------------------
if __name__ == "__main__":
    # Comprovar root abans de crear la GUI
    if os.geteuid() != 0:
        print("Aquest programa requereix permisos de root. Executeu-lo amb 'sudo'.")
        sys.exit(1)
    app = ArrelSetup()
    app.mainloop()
