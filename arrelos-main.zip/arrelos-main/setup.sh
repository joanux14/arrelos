#!/bin/bash
# ============================================================================
# setup.sh – Desplegament automatitzat d'ArrelOS (versió 2.0 compilada)
# Integra PyInstaller: compila automàticament si no trobo binaris
# Corregeix: D-Bus per xfconf-query, conflicte resolv.conf amb NM,
# persistència d'iptables, lleugeresa de memòria i inclusió d'ArrelWifi.
# Ha de ser executat amb permisos de root (sudo ./setup.sh).
# ============================================================================

# Colors per als missatges
R='\033[0;31m'
G='\033[0;32m'
Y='\033[1;33m'
B='\033[0;34m'
NC='\033[0m'

error_exit() { echo -e "${R}[ERROR]${NC} $1" >&2; exit 1; }
info()       { echo -e "${G}[INFO]${NC} $1"; }
warn()       { echo -e "${Y}[AVÍS]${NC} $1"; }
debug()      { echo -e "${B}[DEBUG]${NC} $1"; }

# ============================================================================
# 0. VERIFICACIÓ DE ROOT I DIRECTORIS
# ============================================================================
if [[ $EUID -ne 0 ]]; then
    error_exit "Aquest script ha de ser executat com a root (sudo ./setup.sh)."
fi

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
BIN_DIR="$SCRIPT_DIR/bin"
BUILD_SCRIPT="$SCRIPT_DIR/build.sh"

debug "Directori base: $SCRIPT_DIR"
debug "Directori de binaris: $BIN_DIR"

# ============================================================================
# 1. PRE-COMPILACIÓ: Verificar i compilar aplicacions si cal
# ============================================================================
info "1. Verificant aplicacions compilades..."

# Comprovar si existeix el directori bin amb binaris
if [[ ! -d "$BIN_DIR" ]] || [[ -z "$(find "$BIN_DIR" -maxdepth 1 -type f -executable 2>/dev/null)" ]]; then
    warn "No s'han trobat binaris compilats."
    
    # Comprovar si existeix build.sh
    if [[ ! -f "$BUILD_SCRIPT" ]]; then
        error_exit "No s'ha trobat build.sh. Descarga o crea'l des del repositori."
    fi
    
    info "Compilant aplicacions amb PyInstaller..."
    info "(Això pot tardar alguns minuts en funció del sistema...)"
    
    # Executar build.sh
    bash "$BUILD_SCRIPT" || error_exit "Ha fallat la compilació de les aplicacions. Revisa els errors anteriors."
    
    if [[ ! -d "$BIN_DIR" ]] || [[ -z "$(find "$BIN_DIR" -maxdepth 1 -type f -executable 2>/dev/null)" ]]; then
        error_exit "La compilació no va generar binaris correctament."
    fi
    
    info "✅ Compilació completada."
else
    info "✅ Binaris compilats detectats. Procedint amb la instal·lació."
fi

# ============================================================================
# 2. ACTUALITZACIÓ DE REPOSITORIS I PAQUETS
# ============================================================================
info "2. Actualitzant repositoris i instal·lant dependències..."
apt update -y || error_exit "Ha fallat l'actualització dels repositoris."

# Instal·lació bàsica + NetworkManager + iptables-persistent
apt install -y \
    xorg \
    xfce4-session \
    xfwm4 \
    xfdesktop4 \
    xfce4-panel \
    xfce4-settings \
    xfce4-terminal \
    lightdm \
    lightdm-gtk-greeter \
    python3-pip \
    python3-tk \
    vlc \
    alsa-utils \
    network-manager \
    iptables-persistent \
    || error_exit "Ha fallat la instal·lació dels paquets essencials."

# ============================================================================
# 3. CONFIGURACIÓ DE L'ARRENCADA GRÀFICA I XARXA
# ============================================================================
info "3. Configurant arrencada gràfica i NetworkManager..."
systemctl set-default graphical.target || warn "No s'ha pogut establir graphical.target."
systemctl enable lightdm || warn "No s'ha pogut habilitar LightDM."
systemctl enable NetworkManager || warn "No s'ha pogut habilitar NetworkManager."

# ============================================================================
# 4. DIRECTORIS I INSTAL·LACIÓ DE BINARIS COMPILATS
# ============================================================================
info "4. Creant l'estructura de directoris a /usr/share/arrelos/..."
mkdir -p /usr/share/arrelos/bin || error_exit "No s'ha pogut crear /usr/share/arrelos."

info "Copiant binaris compilats..."
if [[ -d "$BIN_DIR" ]]; then
    cp -r "$BIN_DIR"/* /usr/share/arrelos/bin/ || error_exit "No s'ha pogut copiar els binaris."
    chmod +x /usr/share/arrelos/bin/* 2>/dev/null
    info "✅ Binaris instal·lats a /usr/share/arrelos/bin/"
else
    error_exit "No s'ha trobat el directori de binaris compilats."
fi

# Fons de pantalla i tema
info "Copiant temes i wallpapers..."
if [[ -f "$SCRIPT_DIR/wallpaper.jpg" ]]; then
    cp "$SCRIPT_DIR/wallpaper.jpg" /usr/share/arrelos/
    WALLPAPER="/usr/share/arrelos/wallpaper.jpg"
    debug "Wallpaper instal·lat"
else
    WALLPAPER=""
    warn "No s'ha trobat wallpaper.jpg"
fi

if [[ -d "$SCRIPT_DIR/theme/McOS-XFCE-Edition" ]]; then
    mkdir -p /usr/share/themes/
    cp -r "$SCRIPT_DIR/theme/McOS-XFCE-Edition" /usr/share/themes/
    debug "Tema McOS instal·lat"
fi

# ============================================================================
# 5. CONFIGURACIÓ DE L'USUARI arreluser
# ============================================================================
info "5. Creant l'usuari 'arreluser'..."
if ! id "arreluser" &>/dev/null; then
    useradd -m -s /bin/bash arreluser || error_exit "No s'ha pogut crear l'usuari."
    info "✅ Usuari 'arreluser' creat."
else
    info "L'usuari 'arreluser' ja existeix."
fi

gpasswd -d arreluser sudo 2>/dev/null
gpasswd -d arreluser wheel 2>/dev/null
usermod -aG netdev arreluser  # Per poder fer nmcli sense sudo

# ============================================================================
# 6. AUTOSTART I ENTRY POINT (BINARIS)
# ============================================================================
info "6. Configurant autostart amb binaris compilats..."
AUTOSTART_DIR="/home/arreluser/.config/autostart"
mkdir -p "$AUTOSTART_DIR"

# Crear .desktop que executa el binari compilat, no el script Python
cat > "$AUTOSTART_DIR/arrelos.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=ArrelOS Explorer
Exec=/usr/share/arrelos/bin/explorer
X-GNOME-Autostart-enabled=true
Comment=Explorador de fitxers d'ArrelOS
Icon=folder
EOF

chown -R arreluser:arreluser /home/arreluser
chmod +x "$AUTOSTART_DIR/arrelos.desktop"
debug "Autostart configurat"

# ============================================================================
# 7. CREACIÓ DE LAUNCHERS AL MENÚ (OPCIONAL)
# ============================================================================
info "7. Creant launchers d'aplicacions..."
APPLICATIONS_DIR="/home/arreluser/.local/share/applications"
mkdir -p "$APPLICATIONS_DIR"

declare -a APP_NAMES=("explorer" "paint" "word" "terminal" "taskmanager" "reproductor" "Seguretat_Arrel" "Wifi_Manager")
declare -a APP_LABELS=("Explorador" "Paint" "Word" "Terminal" "Task Manager" "Reproductor" "Seguretat" "Gestor WiFi")
declare -a APP_ICONS=("folder" "applications-graphics" "text-editor" "utilities-terminal" "system-monitor" "media-player" "security-high" "network-wireless")

for i in "${!APP_NAMES[@]}"; do
    APP_NAME="${APP_NAMES[$i]}"
    APP_LABEL="${APP_LABELS[$i]}"
    APP_ICON="${APP_ICONS[$i]}"
    
    cat > "$APPLICATIONS_DIR/${APP_NAME}.desktop" <<EOFDESKTOP
[Desktop Entry]
Type=Application
Name=$APP_LABEL
Exec=/usr/share/arrelos/bin/$APP_NAME
Icon=$APP_ICON
Categories=Utility;
Terminal=false
EOFDESKTOP
    
    chmod +x "$APPLICATIONS_DIR/${APP_NAME}.desktop"
done

chown -R arreluser:arreluser "$APPLICATIONS_DIR"
debug "Launchers creats"

# ============================================================================
# 8. CONFIGURACIÓ VISUAL (amb dbus-launch per evitar errors)
# ============================================================================
info "8. Aplicant tema visual amb suport D‑Bus temporal..."
if command -v xfconf-query &>/dev/null; then
    # Crear una sessió D‑Bus temporal per poder usar xfconf-query
    dbus_launch="dbus-launch --exit-with-session"

    if [[ -d /usr/share/themes/McOS-XFCE-Edition ]]; then
        $dbus_launch xfconf-query -c xsettings -p /Net/ThemeName -s "McOS-XFCE-Edition" --create -t string || warn "No s'ha pogut aplicar el tema."
    fi

    $dbus_launch xfconf-query -c xfce4-panel -p /panels/panel-1/position -s top -t string --create || warn "No s'ha pogut posar el panell superior."

    if [[ -n "$WALLPAPER" ]] && [[ -f "$WALLPAPER" ]]; then
        $dbus_launch xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/workspace0/last-image -s "$WALLPAPER" --create -t string || warn "No s'ha pogut establir el fons de pantalla."
    fi
else
    warn "xfconf-query no està disponible."
fi

# ============================================================================
# 9. XARXA: Evitar que NM gestioni el DNS (per poder blindar resolv.conf)
# ============================================================================
info "9. Configurant NetworkManager per no modificar /etc/resolv.conf..."
mkdir -p /etc/NetworkManager/conf.d
cat > /etc/NetworkManager/conf.d/arrelos-dns.conf <<EOF
[main]
dns=none
EOF
# Reiniciar NM per aplicar la configuració
systemctl restart NetworkManager

# ============================================================================
# 10. BLINDATGE DE SEGURETAT
# ============================================================================
info "10. Aplicant blindatge de seguretat..."

# 10.1 TTY lock
info "    Creant fitxer de bloqueig TTY..."
mkdir -p /etc/X11/xorg.conf.d
cat > /etc/X11/xorg.conf.d/10-dontvtswitch.conf <<EOF
Section "ServerFlags"
    Option "DontVTSwitch" "true"
EndSection
EOF

# 10.2 Tallafocs (iptables)
info "    Aplicant regles estrictes d'iptables..."
iptables -F
iptables -X
iptables -t nat -F
iptables -t mangle -F
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT
iptables -A INPUT -i lo -j ACCEPT
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# Desar les regles perquè persisteixin després d'un reinici
netfilter-persistent save

# 10.3 DNS segur (Quad9) i immobilització (sense conflictes)
info "    Configurant DNS 9.9.9.9 i blindant fitxers..."
echo "nameserver 9.9.9.9" > /etc/resolv.conf
chattr +i /etc/resolv.conf || warn "No s'ha pogut immobilitzar resolv.conf."
chattr +i /etc/hosts || warn "No s'ha pogut immobilitzar hosts."

# ============================================================================
# FINALITZACIÓ
# ============================================================================
info ""
info "=============================================="
info "✅ Instal·lació d'ArrelOS completada amb èxit."
info "=============================================="
info ""
info "📊 Resum d'instal·lació:"
info "   • Sistema base: Debian 13 + XFCE4"
info "   • Aplicacions compilades: ${#APP_NAMES[@]} binaris"
info "   • Usuari estàndard: arreluser"
info "   • Blindatge: DNS segur, iptables, TTY lock"
info ""
info "🚀 Propers passos:"
info "   1. Reinicieu el sistema: sudo reboot"
info "   2. Accediu com a 'arreluser'"
info "   3. Obriu ArrelOS Explorer des del menú"
info ""
exit 0
