#!/usr/bin/env python3

################################################################################
# Script: apkg-client.py
# Propòsit: Client de gestió de paquets per ArrelOS
# Ús: ./apkg-client.py <paquet_name>
# Descripció: Descarrega, verifica SHA256 i instal·la paquets des del manifest
################################################################################

import json
import requests
import hashlib
import os
import sys
import subprocess

MANIFEST_URL = "https://raw.githubusercontent.com/joanux14/arrelos/main/manifest.json"
INSTALL_PATH = "/usr/local/bin"

def print_error(message):
    """Imprimeix missatges d'error en vermell."""
    print(f"\033[91m❌ {message}\033[0m")

def print_success(message):
    """Imprimeix missatges d'èxit en verd."""
    print(f"\033[92m✅ {message}\033[0m")

def print_info(message):
    """Imprimeix missatges informatius en blau."""
    print(f"\033[94m📦 {message}\033[0m")

def download_file(url, destination):
    """Descarrega un fitxer del repositori."""
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()
        
        total_size = int(response.headers.get('content-length', 0))
        downloaded = 0
        
        with open(destination, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        percent = (downloaded / total_size) * 100
                        print(f"   Descàrrega: {percent:.1f}%", end='\r')
        
        print("\n")
        print_success(f"Descarregat: {destination}")
        return True
    except Exception as e:
        print_error(f"Error descarregant: {e}")
        return False

def verify_sha256(file_path, expected_hash):
    """Verifica que el SHA256 del fitxer coincideix."""
    sha256 = hashlib.sha256()
    
    try:
        with open(file_path, 'rb') as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256.update(byte_block)
        
        calculated_hash = sha256.hexdigest()
        
        if calculated_hash == expected_hash:
            print_success("Verificació SHA256: OK")
            return True
        else:
            print_error("SHA256 no coincideix!")
            print(f"   Esperat:   {expected_hash}")
            print(f"   Calculat:  {calculated_hash}")
            return False
    except Exception as e:
        print_error(f"Error verificant SHA256: {e}")
        return False

def install_package(package_name):
    """Descarrega, verifica i instal·la un paquet."""
    
    # Obté el manifest
    try:
        response = requests.get(MANIFEST_URL, timeout=10)
        response.raise_for_status()
        manifest = response.json()
    except Exception as e:
        print_error(f"Error llegint manifest: {e}")
        return False
    
    # Busca el paquet
    package = None
    for pkg in manifest.get('packages', []):
        if pkg['name'] == package_name:
            package = pkg
            break
    
    if not package:
        print_error(f"Paquet no trobat: {package_name}")
        print("\nPaquets disponibles:")
        for pkg in manifest.get('packages', []):
            print(f"  - {pkg['name']} ({pkg['version']}): {pkg['description']}")
        return False
    
    print_info(f"Instal·lant: {package['name']} {package['version']}")
    print(f"   Descripció: {package['description']}")
    print(f"   Mida: {package['size_bytes'] / (1024*1024):.2f} MB")
    print("")
    
    # Descarrega
    temp_file = f"/tmp/{package_name}"
    if not download_file(package['download_url'], temp_file):
        return False
    
    # Verifica
    if not verify_sha256(temp_file, package['sha256']):
        os.remove(temp_file)
        return False
    
    # Instal·la
    try:
        # Verifica permisos de root
        if os.geteuid() != 0:
            print_error("Aquest script requereix privilegis de root (sudo)")
            os.remove(temp_file)
            return False
        
        os.makedirs(INSTALL_PATH, exist_ok=True)
        os.rename(temp_file, f"{INSTALL_PATH}/{package_name}")
        os.chmod(f"{INSTALL_PATH}/{package_name}", 0o755)
        print_success(f"Instal·lat a: {INSTALL_PATH}/{package_name}")
        return True
    except Exception as e:
        print_error(f"Error instal·lant: {e}")
        if os.path.exists(temp_file):
            os.remove(temp_file)
        return False

def list_packages():
    """Llista tots els paquets disponibles."""
    try:
        response = requests.get(MANIFEST_URL, timeout=10)
        response.raise_for_status()
        manifest = response.json()
        
        if not manifest.get('packages'):
            print_info("Cap paquet disponible")
            return
        
        print_info("Paquets disponibles:")
        print("")
        for pkg in manifest.get('packages', []):
            print(f"  📦 {pkg['name']} ({pkg['version']})")
            print(f"     {pkg['description']}")
            print(f"     SHA256: {pkg['sha256'][:16]}...")
            print("")
    except Exception as e:
        print_error(f"Error llegint manifest: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("ArrelOS Package Manager (apkg)")
        print("")
        print("Ús:")
        print("  ./apkg-client.py install <paquet_name>  - Instal·la un paquet")
        print("  ./apkg-client.py list                    - Llista paquets disponibles")
        print("")
        print("Exemple:")
        print("  sudo ./apkg-client.py install word")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "list":
        list_packages()
        sys.exit(0)
    elif command == "install":
        if len(sys.argv) < 3:
            print_error("Especifica el nom del paquet")
            print("Ús: ./apkg-client.py install <paquet_name>")
            sys.exit(1)
        
        package_name = sys.argv[2]
        
        if install_package(package_name):
            print_success("Paquet instal·lat correctament!")
            sys.exit(0)
        else:
            print_error("Error en la instal·lació")
            sys.exit(1)
    else:
        print_error(f"Comanda desconeguda: {command}")
        sys.exit(1)
