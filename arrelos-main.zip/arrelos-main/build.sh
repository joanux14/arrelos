#!/bin/bash
# ============================================================================
# build.sh – Compila tots els apps d'ArrelOS amb PyInstaller
# Generat per evitar distribucions amb scripts no compilats
# ============================================================================

# Colors
R='\033[0;31m'
G='\033[0;32m'
Y='\033[1;33m'
B='\033[0;34m'
NC='\033[0m'

error_exit() { echo -e "${R}[ERROR]${NC} $1" >&2; exit 1; }
info()       { echo -e "${G}[INFO]${NC} $1"; }
warn()       { echo -e "${Y}[AVÍS]${NC} $1"; }
debug()      { echo -e "${B}[DEBUG]${NC} $1"; }

# ============================================================================
# 0. VERIFICACIÓ DE REQUISITS
# ============================================================================
info "Verificant requisits de compilació..."

# Comprovar que Python3 i PyInstaller estan disponibles
if ! command -v python3 &>/dev/null; then
    error_exit "Python 3 no està instal·lat. Instal·la'l primer."
fi

if ! python3 -c "import PyInstaller" 2>/dev/null; then
    warn "PyInstaller no està instal·lat. Intent d'instal·lar..."
    pip3 install --upgrade pyinstaller || error_exit "No s'ha pogut instal·lar PyInstaller"
fi

# Obtenir el directori on es troba aquest script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APPS_DIR="$SCRIPT_DIR/apps"
BIN_DIR="$SCRIPT_DIR/bin"
BUILD_TEMP="/tmp/arrelos_build_$$"

info "Directori base: $SCRIPT_DIR"
info "Directori d'apps: $APPS_DIR"
info "Directori de binaris: $BIN_DIR"

# Comprovar que existeix la carpeta d'apps
if [[ ! -d "$APPS_DIR" ]]; then
    error_exit "No s'ha trobat la carpeta 'apps' a $APPS_DIR"
fi

# ============================================================================
# 1. PREPARACIÓ DE DIRECTORIS
# ============================================================================
info "Preparant directoris de compilació..."
rm -rf "$BIN_DIR" "$BUILD_TEMP"
mkdir -p "$BIN_DIR" "$BUILD_TEMP"

# ============================================================================
# 2. DEFINICIÓ D'APPS A COMPILAR
# ============================================================================
declare -A APPS_INFO

# Format: [nom_app]="fitxer.py|hidden_imports|extra_args"
APPS_INFO[explorer]="explorer.py|tkinter,tkinter.filedialog,tkinter.messagebox|"
APPS_INFO[paint]="paint.py|tkinter,tkinter.canvas,tkinter.colorchooser|"
APPS_INFO[word]="word.py|tkinter,tkinter.scrolledtext,tkinter.filedialog|"
APPS_INFO[terminal]="terminal.py|tkinter,tkinter.scrolledtext|"
APPS_INFO[taskmanager]="taskmanager.py|tkinter,tkinter.ttk|"
APPS_INFO[reproductor]="reproductor.py|tkinter,pygame|--hidden-import=pygame"
APPS_INFO[Seguretat_Arrel]="Seguretat_Arrel.py|tkinter,tkinter.messagebox|"
APPS_INFO[Wifi_Manager]="Wifi_Manager.py|tkinter,subprocess|"

# ============================================================================
# 3. COMPILACIÓ D'APPS
# ============================================================================
info "=========================================="
info "  Compilant aplicacions ArrelOS..."
info "=========================================="

COMPILED_COUNT=0
FAILED_COUNT=0

for APP_NAME in "${!APPS_INFO[@]}"; do
    APP_INFO="${APPS_INFO[$APP_NAME]}"
    APP_FILE=$(echo "$APP_INFO" | cut -d'|' -f1)
    HIDDEN_IMPORTS=$(echo "$APP_INFO" | cut -d'|' -f2)
    EXTRA_ARGS=$(echo "$APP_INFO" | cut -d'|' -f3)
    
    APP_PATH="$APPS_DIR/$APP_FILE"
    
    # Verificar que l'app existeix
    if [[ ! -f "$APP_PATH" ]]; then
        warn "⚠️  No s'ha trobat $APP_FILE. S'omet."
        FAILED_COUNT=$((FAILED_COUNT + 1))
        continue
    fi
    
    debug "Compilant: $APP_NAME ($APP_FILE)"
    
    # Construir la comanda PyInstaller
    PYINST_CMD="pyinstaller \
        --onefile \
        --windowed \
        --name='$APP_NAME' \
        --distpath='$BIN_DIR' \
        --workpath='$BUILD_TEMP/build_$APP_NAME' \
        --specpath='$BUILD_TEMP/spec_$APP_NAME' \
        --clean \
        --noconfirm"
    
    # Afegir hidden imports si existeixen
    if [[ -n "$HIDDEN_IMPORTS" ]]; then
        IFS=',' read -ra IMPORTS <<< "$HIDDEN_IMPORTS"
        for imp in "${IMPORTS[@]}"; do
            PYINST_CMD="$PYINST_CMD --hidden-import='$imp'"
        done
    fi
    
    # Afegir args extra si existeixen
    if [[ -n "$EXTRA_ARGS" ]]; then
        PYINST_CMD="$PYINST_CMD $EXTRA_ARGS"
    fi
    
    # Afegir el fitxer d'entrada
    PYINST_CMD="$PYINST_CMD '$APP_PATH'"
    
    # Executar PyInstaller
    echo ""
    echo -e "${B}▶${NC} Compilant: ${B}$APP_NAME${NC}"
    if eval "$PYINST_CMD" 2>&1 | tail -20; then
        info "✅ $APP_NAME compilat correctament"
        COMPILED_COUNT=$((COMPILED_COUNT + 1))
    else
        error_exit "❌ Error compilant $APP_NAME. Revisa els hidden imports o les dependències."
    fi
done

# ============================================================================
# 4. POST-COMPILACIÓ: PERMISOS I LIMPIESA
# ============================================================================
info "=========================================="
info "  Post-compilació..."
info "=========================================="

# Establir permisos executables
chmod +x "$BIN_DIR"/* 2>/dev/null
debug "Permisos executables establerts"

# Crear un manifest de binaris compilats
debug "Creant manifest de binaris..."
ls -lh "$BIN_DIR" > "$BIN_DIR/MANIFEST.txt"
echo "" >> "$BIN_DIR/MANIFEST.txt"
echo "Compilat el: $(date)" >> "$BIN_DIR/MANIFEST.txt"
echo "Sistema: $(uname -m)" >> "$BIN_DIR/MANIFEST.txt"

# Netejar directoris temporals
rm -rf "$BUILD_TEMP"
debug "Directoris temporals netejats"

# ============================================================================
# 5. RESUM FINAL
# ============================================================================
info "=========================================="
info "  Compilació completada"
info "=========================================="
info "✅ Apps compilades: $COMPILED_COUNT"
if [[ $FAILED_COUNT -gt 0 ]]; then
    warn "⚠️  Apps fallides o omet.: $FAILED_COUNT"
fi
info "📁 Binaris disponibles a: $BIN_DIR"
info "🔧 Permisos: $(stat -c '%A' "$BIN_DIR"/* 2>/dev/null | head -1)"
info ""
info "Pots instal·lar amb: sudo ./setup.sh"
info ""

exit 0
