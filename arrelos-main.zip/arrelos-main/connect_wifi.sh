#!/bin/bash

SSID="LAPTOP-OENQ0389 9813"
PASSWORD="LA_TEVA_CONTRASENYA"

echo "Activant la Wi-Fi..."
nmcli radio wifi on

echo "Esperant 3 segons..."
sleep 3

echo "Escanejant xarxes..."
nmcli device wifi rescan
sleep 2

echo "Connectant a '$SSID'..."
nmcli device wifi connect "$SSID" password "$PASSWORD"

echo "Estat de la connexió:"
nmcli device status
