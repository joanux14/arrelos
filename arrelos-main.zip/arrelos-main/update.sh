#!/bin/bash

################################################################################
# Script: update.sh
# Distribució: ArrelOS
# Propòsit: Gestor d'actualitzacions automatitzat per ArrelOS
# Descripció: Script de backend per a la comanda 'arrel-update' que es comunica
#             de forma segura amb el repositori remot de GitHub.
# 
# Característiques principals:
#   - Utilitza 'git fetch' previ a 'git pull' per detectar actualitzacions
#   - Compara commits locals i remots per optimització eficient
#   - Demana confirmació interactiva a l'usuari en català
#   - Implementa mecanismes de seguretat amb 'chattr' per a bloquejos inmutables
#   - Manege robusts d'errors sense usar 'set -e' blindament
#   - Restauració incondicional dels bloquejos de seguretat
#
# Autor: ArrelOS Release Automation Team
# Data de creació: 2026-07-13
# Versió: 1.0.0
#
################################################################################

# DEFINICIÓ DE CONSTANTS I VARIABLES GLOBALS
readonly ARRELOS_PATH="/usr/share/arrelos/"
readonly RESOLV_CONF="/etc/resolv.conf"
readonly HOSTS_FILE="/etc/hosts"
readonly GIT_BRANCH="main"
readonly GIT_REMOTE="origin"

# Codis de sortida
readonly EXIT_SUCCESS=0
readonly EXIT_ERROR=1

################################################################################
# FUNCIÓ: print_error
# Descripció: Imprimeix missatges d'error al flux de stderr
# Paràmetres: $1 - Missatge d'error
# Retorna: Cap (0)
################################################################################
print_error() {
    local message="$1"
    echo "[ERROR] $message" >&2
}

################################################################################
# FUNCIÓ: print_info
# Descripció: Imprimeix missatges informatius amb prefix [+]
# Paràmetres: $1 - Missatge d'informació
# Retorna: Cap (0)
################################################################################
print_info() {
    local message="$1"
    echo "[+] $message"
}

################################################################################
# FUNCIÓ: print_success
# Descripció: Imprimeix missatges de èxit amb prefix [✔]
# Paràmetres: $1 - Missatge d'èxit
# Retorna: Cap (0)
################################################################################
print_success() {
    local message="$1"
    echo "[✔] $message"
}

################################################################################
# FUNCIÓ: print_optimization
# Descripció: Imprimeix missatges d'optimització amb prefix [!]
# Paràmetres: $1 - Missatge d'optimització
# Retorna: Cap (0)
################################################################################
print_optimization() {
    local message="$1"
    echo "[!] OPTIMITZACIÓ: $message"
}

################################################################################
# FUNCIÓ: print_postponed
# Descripció: Imprimeix missatges de postergació amb prefix [-]
# Paràmetres: $1 - Missatge de postergació
# Retorna: Cap (0)
################################################################################
print_postponed() {
    local message="$1"
    echo "[-] $message"
}

################################################################################
# FUNCIÓ: print_ok
# Descripció: Imprimeix missatges d'èxit final amb prefix [OK]
# Paràmetres: $1 - Missatge d'èxit
# Retorna: Cap (0)
################################################################################
print_ok() {
    local message="$1"
    echo "[OK] $message"
}

################################################################################
# FUNCIÓ: check_root_privileges
# Descripció: Verifica que l'script s'executa amb privilegis de root (sudo)
# Paràmetres: Cap
# Retorna: 0 si és root, 1 en cas contrari
################################################################################
check_root_privileges() {
    if [[ $EUID -ne 0 ]]; then
        print_error "Aquest script requereix privilegis de root. Si us plau, executa'l amb 'sudo'."
        return 1
    fi
    return 0
}

################################################################################
# FUNCIÓ: check_arrelos_path
# Descripció: Verifica que la ruta d'ArrelOS existeix
# Paràmetres: Cap
# Retorna: 0 si el camí existeix, 1 en cas contrari
################################################################################
check_arrelos_path() {
    if [[ ! -d "$ARRELOS_PATH" ]]; then
        print_error "El camí d'ArrelOS no existeix: $ARRELOS_PATH"
        return 1
    fi
    return 0
}

################################################################################
# FUNCIÓ: unlock_security_system
# Descripció: Desbloqueja els fitxers de configuració de xarxa per permetre
#             la comunicació amb GitHub. Utilitza 'chattr -i' per eliminar
#             l'atribut d'immutabilitat.
# Paràmetres: Cap
# Retorna: 0 si té èxit, 1 si falla
################################################################################
unlock_security_system() {
    print_info "Connectant amb GitHub per buscar noves versions..."
    
    # Intenta desbloquejar resolv.conf
    if ! chattr -i "$RESOLV_CONF" 2>/dev/null; then
        print_error "No s'ha pogut desbloquejar $RESOLV_CONF. Verifica els permisos."
        return 1
    fi
    
    return 0
}

################################################################################
# FUNCIÓ: lock_security_system
# Descripció: Restaura incondiccionalment els bloquejos de seguretat als fitxers
#             de configuració de xarxa. Utilitza 'chattr +i' per afegir
#             l'atribut d'immutabilitat. AQUESTA FUNCIÓ HA D'EXECUTAR-SE SEMPRE.
# Paràmetres: Cap
# Retorna: 0 si té èxit, 1 si falla
################################################################################
lock_security_system() {
    local lock_failed=0
    
    # Intenta bloquejar resolv.conf
    if ! chattr +i "$RESOLV_CONF" 2>/dev/null; then
        print_error "No s'ha pogut bloquejar $RESOLV_CONF."
        lock_failed=1
    fi
    
    # Intenta bloquejar hosts file
    if ! chattr +i "$HOSTS_FILE" 2>/dev/null; then
        print_error "No s'ha pogut bloquejar $HOSTS_FILE."
        lock_failed=1
    fi
    
    return "$lock_failed"
}

################################################################################
# FUNCIÓ: fetch_remote_metadata
# Descripció: Obté les metadades del repositori remot de GitHub sense fer
#             un 'git pull' immediat. Executa 'git fetch' silenciosament
#             i captura els commits locals i remots.
# Paràmetres: Cap
# Retorna: 0 si té èxit, 1 si falla
################################################################################
fetch_remote_metadata() {
    # Executa git fetch silenciosament per evitar soroll a la consola
    if ! git -C "$ARRELOS_PATH" fetch "$GIT_REMOTE" "$GIT_BRANCH" >/dev/null 2>&1; then
        print_error "No s'ha pogut fer fetch del repositori remot. Verifica la connexió a GitHub."
        return 1
    fi
    
    return 0
}

################################################################################
# FUNCIÓ: get_local_commit
# Descripció: Captura l'identificador del commit local actual (HEAD)
# Paràmetres: Cap
# Retorna: 0 si té èxit, 1 si falla
################################################################################
get_local_commit() {
    local local_commit
    
    local_commit=$(git -C "$ARRELOS_PATH" rev-parse HEAD 2>/dev/null)
    
    if [[ -z "$local_commit" ]]; then
        print_error "No s'ha pogut obtenir el commit local."
        return 1
    fi
    
    echo "$local_commit"
    return 0
}

################################################################################
# FUNCIÓ: get_remote_commit
# Descripció: Captura l'identificador del commit remot (origin/main)
# Paràmetres: Cap
# Retorna: 0 si té èxit, 1 si falla
################################################################################
get_remote_commit() {
    local remote_commit
    
    remote_commit=$(git -C "$ARRELOS_PATH" rev-parse "@{u}" 2>/dev/null)
    
    if [[ -z "$remote_commit" ]]; then
        print_error "No s'ha pogut obtenir el commit remot."
        return 1
    fi
    
    echo "$remote_commit"
    return 0
}

################################################################################
# FUNCIÓ: compare_commits
# Descripció: Compara els commits locals i remots. Retorna 0 si són iguals,
#             1 si són diferents.
# Paràmetres: $1 - Commit local, $2 - Commit remot
# Retorna: 0 si iguals, 1 si diferents
################################################################################
compare_commits() {
    local local_commit="$1"
    local remote_commit="$2"
    
    if [[ "$local_commit" == "$remote_commit" ]]; then
        return 0  # Són iguals
    else
        return 1  # Són diferents
    fi
}

################################################################################
# FUNCIÓ: prompt_user_confirmation
# Descripció: Demana confirmació a l'usuari en català per procedir amb
#             l'actualització. Accepta "s" o "S" com afirmatiu.
# Paràmetres: Cap
# Retorna: 0 si l'usuari accepta, 1 en cas contrari
################################################################################
prompt_user_confirmation() {
    local response
    
    echo ""
    read -p "Vols descarregar l'actualització ara mateix? (s/n) " response
    echo ""
    
    case "$response" in
        s|S)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

################################################################################
# FUNCIÓ: apply_update
# Descripció: Baixa i aplica els nous fitxers del repositori remot. Executa
#             'git pull' i restaura els permisos d'execució als scripts Python.
# Paràmetres: Cap
# Retorna: 0 si té èxit, 1 si falla
################################################################################
apply_update() {
    print_info "Descarregant i aplicant els nous fitxers .py de la suite..."
    
    # Executa git pull per fusionar els nous fitxers
    if ! git -C "$ARRELOS_PATH" pull "$GIT_REMOTE" "$GIT_BRANCH" >/dev/null 2>&1; then
        print_error "No s'ha pogut fer pull dels canvis. Verifica l'estat del repositori."
        return 1
    fi
    
    # Restaura els permisos d'execució recursivament a tots els fitxers
    if ! chmod -R 755 "$ARRELOS_PATH" 2>/dev/null; then
        print_error "No s'ha pogut restaurar els permisos d'execució."
        return 1
    fi
    
    print_ok "ArrelOS s'ha actualitzat correctament a l'última versió."
    return 0
}

################################################################################
# FUNCIÓ: handle_postponed_update
# Descripció: Gestiona el cas en què l'usuari posposa l'actualització.
# Paràmetres: Cap
# Retorna: 0
################################################################################
handle_postponed_update() {
    print_postponed "Actualització postergada per l'usuari."
    return 0
}

################################################################################
# FUNCIÓ: handle_up_to_date
# Descripció: Gestiona el cas en què el sistema ja està actualitzat.
# Paràmetres: Cap
# Retorna: 0
################################################################################
handle_up_to_date() {
    print_success "El teu ArrelOS ja està actualitzat a l'última versió. No cal fer res!"
    return 0
}

################################################################################
# MAIN SCRIPT LOGIC
################################################################################

# Variable per controlar si cal fer cleanup
CLEANUP_REQUIRED=0

# Trap per assegurar que els bloquejos de seguretat es restaurin SEMPRE
trap 'lock_security_system; exit $?' EXIT

################################################################################
# PAS 1: Validació de Privilegis i Ruta
################################################################################

# Verifica que s'executa amb privilegis de root
if ! check_root_privileges; then
    exit $EXIT_ERROR
fi

# Verifica que el camí d'ArrelOS existeix
if ! check_arrelos_path; then
    exit $EXIT_ERROR
fi

# Canvia a la ruta d'ArrelOS
cd "$ARRELOS_PATH" || exit $EXIT_ERROR

################################################################################
# PAS 2: Desbloqueig del Sistema de Seguretat
################################################################################

# Desbloqueja els fitxers de configuració de xarxa
if ! unlock_security_system; then
    exit $EXIT_ERROR
fi

CLEANUP_REQUIRED=1

################################################################################
# PAS 3: Fetch Silenciós de Metadades i Comparació
################################################################################

# Obté les metadades del repositori remot
if ! fetch_remote_metadata; then
    exit $EXIT_ERROR
fi

# Captura el commit local
LOCAL=$(get_local_commit)
if [[ $? -ne 0 ]]; then
    exit $EXIT_ERROR
fi

# Captura el commit remot
REMOTE=$(get_remote_commit)
if [[ $? -ne 0 ]]; then
    exit $EXIT_ERROR
fi

################################################################################
# PAS 4: Lògica Condicional i Interacció amb l'Usuari
################################################################################

# Compara els commits
if compare_commits "$LOCAL" "$REMOTE"; then
    # CASE A: Sistema actualitzat
    handle_up_to_date
    exit $EXIT_SUCCESS
else
    # CASE B: Noves actualitzacions disponibles
    print_optimization "S'han detectat nous fitxers i millores a GitHub."
    
    # Demana confirmació a l'usuari
    if prompt_user_confirmation; then
        # L'usuari accepta: aplica l'actualització
        if ! apply_update; then
            exit $EXIT_ERROR
        fi
        exit $EXIT_SUCCESS
    else
        # L'usuari rebutja: posposa l'actualització
        handle_postponed_update
        exit $EXIT_SUCCESS
    fi
fi

################################################################################
# PAS 5: Restauració Incondicional dels Bloquejos de Seguretat
# (Aquest pas es garanteix que s'executarà gràcies al trap EXIT)
################################################################################

exit $EXIT_SUCCESS
