# 🌳 ArrelOS (By Joanux14)

![Base-Debian 13](https://img.shields.io/badge/Base-Debian%2013-blue?style=flat-flat)
![Arch-ARM | x86_64](https://img.shields.io/badge/Arch-ARM%20%7C%20x86__64-orange?style=flat-flat)
![License-GPL 3.0](https://img.shields.io/badge/License-GPL--3.0-green?style=flat-flat)

Benvinguts a **ArrelOS**, un sistema operatiu lleuger, segur i de codi obert dissenyat específicament per a equips amb pocs recursos, màquines antigues i plaques tipus **Raspberry Pi** (com la Pi Zero 2 WH). 

El sistema es basa en el robust kernel de **Debian 13** i utilitza un entorn visual basat en **XFCE** optimitzat al detall per consumir el mínim i tenir una estètica neta estil macOS.

---

## 🚀 Per què ArrelOS? (La nostra filosofia)

La majoria de sistemes moderns consumeixen recursos de manera innecessària. ArrelOS neix amb una idea clara: **crear un entorn "búnquer" immutable**. 

* **Aplicacions compilades, no scripts:** Tota la suite d'aplicacions està programada des de zero en Python i compilada a binaris executables natius mitjançant PyInstaller. L'usuari final no pot modificar ni "trencar" el codi dels programes.
* **Blindatge total:** El sistema utilitza polítiques restrictives de xarxa i bloqueja fitxers crítics del sistema com a immutables. Un cop s'instal·la, és pràcticament indestructible per a un usuari normal.

---

## 💻 La Suite d'Apps (Creada per Joanux14)

Totes les aplicacions principals han estat escrites de zero i compilades per a un rendiment òptim:

* 📂 **Explorador:** El gestor de fitxers central del sistema.
* 🎵 **Reproductor:** Escolta la teva música sense que el sistema es quedi sense RAM.
* 🎨 **Paint:** Dibuixa i edita de forma ràpida.
* 🔒 **Seguretat:** Mòdul encarregat de vigilar el búnquer.
* 📊 **Task Manager:** Monitoritza què està consumint recursos en temps real.
* 🐚 **Terminal:** Per quan necessitis el control total de la línia de comandes.
* 📝 **Word:** Un processador de text lleuger per treballar sense distraccions.

---

## 🛠️ Requisits del Sistema

ArrelOS està pensat per volar, fins i tot en una patata d'ordinador:

| Component | Mínim | Recomanat |
| :--- | :--- | :--- |
| **CPU** | 1 GHz (ARM o x86/x64) | Quad-Core 1.5 GHz+ |
| **RAM** | 500 MB (Ideal Pi Zero 2) | 1 GB o més |
| **Disc** | 8 GB lliures (targeta SD o SSD) | 16 GB |

---

## 💾 Com es munta i s'instal·la (Ràpid)

El desplegament s'ha automatitzat al màxim amb un script mestre (`setup.sh`).

### 1. Preparar el terreny (Recomanat Debian o Ubuntu Server net)
Primer, clona aquest repositori a la màquina on vulguis posar ArrelOS:

```bash
# Instal·la git si no el tens
sudo apt update && sudo apt install -y git

# Clona el projecte
git clone [https://github.com/Comfrey29/arrelos.git](https://github.com/Comfrey29/arrelos.git)
cd arrelos
chmod +x setup.sh
./setup.sh
